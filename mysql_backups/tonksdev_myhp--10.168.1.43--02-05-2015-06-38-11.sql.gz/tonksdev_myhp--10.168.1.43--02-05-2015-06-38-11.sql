-- MySQL dump 10.13  Distrib 5.6.24, for linux-glibc2.5 (x86_64)
--
-- Host: 10.168.1.43    Database: tonksdev_myhp
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `bannedword`
--

DROP TABLE IF EXISTS `bannedword`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bannedword` (
  `word` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Banned word',
  PRIMARY KEY (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds all banned words and phrases from the site';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bannedword`
--

LOCK TABLES `bannedword` WRITE;
/*!40000 ALTER TABLE `bannedword` DISABLE KEYS */;
/*!40000 ALTER TABLE `bannedword` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'The name of this category',
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Description of this category',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds details of all categories of happy things';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES ('Family','Happy things about my family'),('Work','Happy things from my work'),('School','Happy things from my school'),('Friends','Happy things about my Friends'),('Personal','happy things that i have done');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `happything`
--

DROP TABLE IF EXISTS `happything`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `happything` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Unique identifier',
  `text` varchar(160) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Description of happy thing',
  `user` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Owner of the happy thing',
  `postdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT 'Date time the happy thing was posted',
  `category` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Category of the happy thing',
  PRIMARY KEY (`id`),
  KEY `user` (`user`,`postdate`,`category`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `happything`
--

LOCK TABLES `happything` WRITE;
/*!40000 ALTER TABLE `happything` DISABLE KEYS */;
INSERT INTO `happything` VALUES (1,'Taught Aimee to use SQL','Mark','2014-08-02 12:39:33','family'),(2,'Had my nails done professionally','Aimz','2014-08-02 12:47:12','Personal'),(23,'Positive 121. Gives some clarity & purpose going forwards & more responsibility. ','mark','2014-09-01 16:58:01','Work'),(4,'I can now record happy things!!!','Mark','2014-08-16 17:55:04','Personal'),(7,'Aimee has summer school tomorrow','Mark','2014-08-17 15:11:12','Family'),(8,'Made a better format for recording happy things.','Mark','2014-08-17 15:44:09','Work'),(11,'Private happy thing that Aimee doesn\'t want Dad to know about (boys and stuff).','Aimz','2014-08-24 15:57:48','Personal'),(24,'Got the twitter feed working, with not very much effort! Also learned a few things about JSON & PHP along the way.','Mark','2014-09-02 22:45:55','Personal'),(22,'Cas won again! Second in the league with 2 games to go!!','mark','2014-09-01 16:57:30','Personal'),(14,'Felt ok doing a full(ish) day of work with no pain. ','Mark','2014-08-18 11:35:39','Work'),(15,'Made my way to London from Donny for the first time. Car park was a bit confusing, but I cracked it ;-)','Mark','2014-08-19 14:56:13','Work'),(16,'Picnic in the museum gardens ','Mark','2014-08-22 07:36:57','Personal'),(17,'Great day out at Wembley with my Dad. Didn\'t need to win the game to have a good time. ','Mark','2014-08-23 15:43:21','Family'),(19,'Did my \"ice bucket challenge\" along with Sam & the kids. ','Mark','2014-08-28 07:04:34','Family'),(20,'Restructured the site quickly & succesfully. ','Mark','2014-08-30 16:01:42','Personal'),(21,'Great day out with the kids at the York Maze.','Mark','2014-08-31 19:26:40','Family'),(26,'I told them so ;-)','mark','2014-09-05 22:11:32','Work'),(27,'Cas won again & still have a chance to win the league next week. ','mark','2014-09-08 06:19:46','Personal'),(28,'The NFL is back!!\'','mark','2014-09-08 06:21:02','Personal'),(29,'Just gave Dad his 65th birthday presents. He seemed very happy with the giant inflatable walking stick!','Mark','2014-09-11 19:24:25','Family'),(30,'Moved the myHP site onto Hostroute & it is much quicker & more reliable. Less stress!!!','Mark','2014-09-13 14:21:50','Personal'),(31,'Despite the loss, Cas still had an amazing season. Relegation favourites got to cup final and 90 mins of winning league. ','Mark','2014-09-14 09:48:25','Personal'),(32,'Dallas WIN!!!!','Mark','2014-09-14 22:10:37','Personal'),(33,'Looks like the man-flu is on its way out. Hopefully back to normal by Thursday. ','Mark','2014-09-16 20:55:32','Personal'),(34,'Another makeover for myHP. Starting to really take shape now. ','Mark','2014-09-20 14:30:45','Personal'),(35,'Nearly got my homework done, after spending all day on it!!!','Aimz','2014-09-20 16:30:46','School'),(36,'Utterly awesome comeback by Dallas to beat the Rams. Maybe they can make something out of this year. ','Mark','2014-09-21 21:11:45','Personal'),(37,'My presentation went really well. Great response. ','Mark','2014-09-25 22:05:46','Work'),(38,'A good week at work all-in. Feel much better about things this weekend than last. ','Mark','2014-09-27 07:56:41','Work'),(39,'Unbelievable win against the Saints!! This season has been the biggest surprise. ','Mark','2014-09-29 20:56:06','Personal'),(40,'Really making some inroads into governance. Plenty of recognition for the changes I\\\'m implementing. ','Mark','2014-09-30 19:39:08','Work'),(41,'Really busy at work but it\\\'s a good busy. I seem to be involved in everything at the moment. ','Mark','2014-10-02 18:57:40','Work'),(42,'I\'m very happy not to be involved with the simplification work. Sounds like a nightmare. Much happier doing what I\'m doing. ','Mark','2014-10-03 22:09:59','Work'),(43,'Sam has done a great job with Aimee\\\'s room so far. It\\\'s going to be great. ','Mark','2014-10-03 22:11:13','Family'),(44,'Another impressive win by the Cowboys against a good team. 4-1 on the season is way better than anyone predicted. ','Mark','2014-10-05 20:46:31','Personal'),(45,'Spent most of the day wallpapering Aimee\'s room. Hard work but it looks great. ','Mark','2014-10-05 20:47:33','Personal'),(46,'Aimee got a fantastic glowing report from her teacher. So proud of her. ','Mark','2014-10-09 20:04:15','Family'),(47,'The GAB pack is complete & distributed on time. Massive achievement with such a big agenda. ','Mark','2014-10-15 07:28:38','Work'),(48,'GAB went well & had great feedback on the meeting & materials from Monique. It is being noticed that I\'m doing a good job on this. ','Mark','2014-10-19 10:17:21','Work'),(49,'Decent 10 mile bike ride this morning. Good to get back to my Sunday exercise, after almost a year off. ','Mark','2014-10-19 10:18:28','Personal'),(50,'My PHP development skills are coming along, and I\'m really enjoying the challenge of building functional apps. ','Mark','2014-10-23 08:42:24','Personal'),(51,'I\'m happy to have found a fix for the magic quotes issue','Mark','2014-10-23 18:17:31','Personal'),(53,'lol how good am I this website is so cool','castiger468','2014-10-23 19:28:50','Personal'),(54,'ha IM going to be doing this all night','castiger468','2014-10-23 19:29:27','Personal'),(57,'watch castiger468 on youtube he has 11 subs\r\n','castiger468','2014-10-23 19:31:57','Personal'),(56,'Im soooooooooooooo happy','castiger468','2014-10-23 19:30:08','Personal'),(58,':) so who is happy I am because I\'m getting smash bros tommorow','castiger468','2014-10-23 19:33:00','Family'),(59,'who loves CHICKEN NUGGETS I DO GO ME','castiger468','2014-10-23 19:35:56','Family'),(60,'#yummy #happy','castiger468','2014-10-23 19:37:18','Personal'),(61,'I\'m so happy you already know #happy','castiger468','2014-10-23 19:37:40','Family'),(62,'goooooooooooooooooooooooooo me','castiger468','2014-10-23 19:39:35','Family'),(63,'I\'m very happy that Harvey is having fun with myHP :-D','Mark','2014-10-23 19:44:25','Family'),(64,'hi dooing my homework','castiger468','2014-11-03 19:21:23','Family'),(65,'happy that is how I am feeling because i have finished my homework yay so yea i rule over homework forever.','castiger468','2014-11-03 19:45:26','Family'),(66,'I got to see my team win, and win easily, live at Wembley. Once in a lifetime? Maybe. Loved it. ','Mark','2014-11-11 20:01:07','Personal'),(67,'Testing the site still works','Mark','2015-03-06 23:17:46','Personal');
/*!40000 ALTER TABLE `happything` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `hpgroup`
--

DROP TABLE IF EXISTS `hpgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `hpgroup` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Primary key for groups',
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Describes what this group is and who it is for',
  `password` char(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Password for group entry',
  `moderator` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'User who is the moderator of this group',
  `sortorder` int(11) NOT NULL COMMENT 'Sort order for groups.',
  PRIMARY KEY (`id`),
  KEY `sortorder` (`sortorder`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds details of all sharing groups for myHappyPlace';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `hpgroup`
--

LOCK TABLES `hpgroup` WRITE;
/*!40000 ALTER TABLE `hpgroup` DISABLE KEYS */;
INSERT INTO `hpgroup` VALUES ('Everyone','all users are in this group','','Mark',2),('Tonks','all tonks family are in this group','','Mark',3),('Aimee Friends','all Aimees friends are in this group','','Aimee',3),('Aimz','','','',1),('Mark','','','',1),('castiger468','castiger468 personal group','','castiger468',3);
/*!40000 ALTER TABLE `hpgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `link`
--

DROP TABLE IF EXISTS `link`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `link` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'Primary key for links',
  `link` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Holds the http link',
  `description` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Description of the link',
  `type` char(3) COLLATE utf8_unicode_ci NOT NULL COMMENT 'type of link (img, url, twt) etc.',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds all links to outside content';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `link`
--

LOCK TABLES `link` WRITE;
/*!40000 ALTER TABLE `link` DISABLE KEYS */;
/*!40000 ALTER TABLE `link` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `userid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `sessionid` char(32) COLLATE utf8_unicode_ci NOT NULL,
  `location` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`userid`,`sessionid`,`location`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds keep-me-logged-in session ids';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('castiger468','6bee33ea3aea817c33c470c53c54b756','86.140.153.0'),('castiger468','bc87bdf5582122c3c253b5ad700599a3','86.140.153.135'),('castiger468','ccebf16a7314704bdaaa357849b73b87','86.169.67.246'),('Mark','01bf4e2969313e15d904bd206f2a0869','86.140.153.0'),('Mark','05c5d53207d7ff7ff22c81d1e728b87e','86.129.180.14'),('Mark','3ccfa1359120d9be2c68424da3db1e76','31.52.202.179'),('mark','3d12a65b7899cd4dbe29b4df16b1a9a5','86.129.180.14'),('Mark','404acbc0c0249e6964ba7eb4c5cec536','31.53.140.21'),('Mark','42865fdd5629ae512237539b81f3c63f','86.185.20.119'),('Mark','46d6da9db61b751ddbbf5b8c809d9428','86.168.10.118'),('Mark','4a17a1cf3073c898fe55af174a8ffbaf','86.129.180.14'),('Mark','4e9b001ae056ac3d8bdfab755bd405dc','31.51.90.21'),('Mark','65a638b9e913083f2121589fa2ee0cdc','86.156.213.92'),('Mark','8091499a5aa97a12875f023bacd12757','188.29.165.91'),('mark','83837879c51abbc3f47779ad2ad41d5c','86.129.180.14'),('Mark','857c16bd5715261f2093c10776bbed32','81.157.140.100'),('Mark','89b40224ecdac82bc1b61e6da072514c','127.0.0.1'),('Mark','8d8d3b196cc63ec83ee2ab5abc509da7','86.169.67.246'),('Mark','8f0342da0d1d67c51a868f11f1dce7c0','188.29.164.237'),('Mark','92576c2aeaa29a9159b668051ab741cb','86.129.180.14'),('Mark','94747e370bb96061f4d9b8514b6fac7c','86.129.180.14'),('Mark','947b54b45c5c2c0f593e04ee041ad7ce','82.132.218.226'),('Mark','9ec74b9e0b012d510f5791cbc5a8101e','81.157.139.174'),('Mark','a2494d10849e6b9fcb17b86b625da096','86.163.153.56'),('Mark','ae9f16da875b8cbeaf78e892d172137b','86.129.180.14'),('Mark','b90390aab96af165156a3d0965dc2bab','86.129.180.14'),('Mark','cc5b4f923dc0c8f79e2182cde22583e0','86.169.67.246'),('Mark','f5cd3e72935bc9740e422b30d1d1278b','86.140.153.135');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `thinggroup`
--

DROP TABLE IF EXISTS `thinggroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `thinggroup` (
  `happythingid` int(11) NOT NULL COMMENT 'Links to the happy thing',
  `groupid` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Links to the group id',
  PRIMARY KEY (`happythingid`,`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds links between happy things and groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `thinggroup`
--

LOCK TABLES `thinggroup` WRITE;
/*!40000 ALTER TABLE `thinggroup` DISABLE KEYS */;
INSERT INTO `thinggroup` VALUES (1,'Everyone'),(1,'Tonks'),(2,'Everyone'),(4,'Everyone'),(7,'Everyone'),(8,'Everyone'),(11,'Aimee Friends'),(14,'Everyone'),(15,'Everyone'),(16,'Everyone'),(17,'Everyone'),(19,'Everyone'),(20,'Mark'),(21,'Everyone'),(22,'Everyone'),(23,'Mark'),(24,'Tonks'),(26,'Mark'),(27,'Everyone'),(28,'Everyone'),(29,'Everyone'),(30,'Tonks'),(31,'Everyone'),(32,'Everyone'),(33,'Tonks'),(34,'Tonks'),(35,'Everyone'),(36,'Everyone'),(37,'Mark'),(38,'Mark'),(39,'Everyone'),(40,'Mark'),(41,'Mark'),(42,'Mark'),(43,'Tonks'),(44,'Everyone'),(45,'Tonks'),(46,'Everyone'),(47,'Mark'),(48,'Mark'),(49,'Everyone'),(50,'Everyone'),(51,'Mark'),(53,'Everyone'),(54,'Everyone'),(56,'Everyone'),(57,'Everyone'),(58,'Everyone'),(59,'Everyone'),(60,'castiger468'),(61,'Tonks'),(62,'Tonks'),(63,'Everyone'),(64,'Tonks'),(65,'Everyone'),(66,'Everyone'),(67,'Everyone');
/*!40000 ALTER TABLE `thinggroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Primary key for user',
  `fullname` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Full name of the user',
  `Password` char(32) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Password of user',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Holds the email address for the user',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds details of all users of myHappyPlace';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('Aimz','Aimee Olivia Tonks','def4db7e24711d652bbe39dac22027d7','aimztonks@gmail.com'),('Mark','Mark Tonks','c10a3a5072c2bddc2b6e1be8462999be','marktonks75@gmail.com'),('Harvey','Harvey Tonks','17c360997307a50bdb03863d5e23245d','harveytonks1@gmail.com'),('Sam','Samantha Tonks','1f318cdb7dd0e31b7c7bc8b18a2c6d58','samtonks75@gmail.com'),('Homer','Homer J Simpson','8e3886e74f3ea26ebd7538d7aa6889aa',''),('Bob','Bob Mortimer','9dab09c41ba84259147225accfb83239',''),('Jimbob','James Robert Injustice','df35ddab2b2214e277c338a4d6c92268',''),('JamesBrown','James Brown','577e3add92f501ea96a4aa4cc4540d8a',''),('castiger468','harveymarktonks','b65c1a25d816e17904625812084f7563','marktonks75@gmail.com');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroup`
--

DROP TABLE IF EXISTS `usergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroup` (
  `userid` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Links to the user id',
  `groupid` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Links to the group id',
  PRIMARY KEY (`userid`,`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds links between users and groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroup`
--

LOCK TABLES `usergroup` WRITE;
/*!40000 ALTER TABLE `usergroup` DISABLE KEYS */;
INSERT INTO `usergroup` VALUES ('Aimz','Aimee Friends'),('Aimz','Aimz'),('Aimz','Everyone'),('Aimz','Tonks'),('castiger468','castiger468'),('castiger468','Everyone'),('castiger468','Tonks'),('Mark','Everyone'),('Mark','Mark'),('Mark','Tonks');
/*!40000 ALTER TABLE `usergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userrole` (
  `userid` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Links to the user id',
  `role` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'The role type',
  PRIMARY KEY (`userid`,`role`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds all user roles for all users';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userrole`
--

LOCK TABLES `userrole` WRITE;
/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
INSERT INTO `userrole` VALUES ('Mark','Admin');
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'tonksdev_myhp'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-02  6:38:13
