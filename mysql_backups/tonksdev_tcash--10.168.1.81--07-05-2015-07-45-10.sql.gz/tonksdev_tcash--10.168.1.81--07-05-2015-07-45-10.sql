-- MySQL dump 10.13  Distrib 5.6.24, for linux-glibc2.5 (x86_64)
--
-- Host: 10.168.1.81    Database: tonksdev_tcash
-- ------------------------------------------------------
-- Server version	5.6.21

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `name` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `type` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `bank` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `accountgroup` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  KEY `accountgroup` (`accountgroup`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds all accounts';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('FDMARK','First Direct Current Acc (Mark)','CURRENTACC','FIRST DIRECT','','TONKS'),('HXSAM','Halifax Current Acc (Sam)','CURRENTACC','HALIFAX','','TONKS'),('RAINYDAY','Halifax Savings Account (Rainy Day)','SAVINGSACC','HALIFAX','','TONKS'),('FORTHEFUTURE','First Direct Savings Account (For The Future)','SAVINGSACC','FIRST DIRECT','','TONKS'),('NEXTCARD','Store Card (Next)','STORECARD','NEXT','','TONKS'),('FDCREDIT','First Direct Credit Card','CREDITACC','FIRST DIRECT','','TONKS'),('SPENDACC','Spending Account','CURRENTACC',NULL,NULL,'TEST'),('BILLSACC','Billing Account','CURRENTACC',NULL,NULL,'TEST'),('SAVACC','Savings Account','SAVINGSACC',NULL,NULL,'TEST'),('CREDACC','Credit Card Account','CREDITACC',NULL,NULL,'TEST'),('NEXTACC','Next Card','STORECARD','NEXT',NULL,'TEST');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `accountgroup`
--

DROP TABLE IF EXISTS `accountgroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accountgroup` (
  `groupid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `password` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `owner` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Account groups for all users';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `accountgroup`
--

LOCK TABLES `accountgroup` WRITE;
/*!40000 ALTER TABLE `accountgroup` DISABLE KEYS */;
INSERT INTO `accountgroup` VALUES ('TONKS','Tonks Family Accounts','51c426ef72ca33a67dcda109bdf8df26fb75d0580af8cc52ed5212d0292290c4','marktonks75'),('TEST','Test Account Group','a8947f0f7e2341390492869a2bf158ed7665115ca0fab4e055373390cd9d72e4','Demo');
/*!40000 ALTER TABLE `accountgroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `id` varchar(100) COLLATE utf8_unicode_ci NOT NULL,
  `accountgroup` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`,`accountgroup`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES ('','TONKS'),('Adjustment','TONKS'),('Beauty','TONKS'),('Beauty:Haircut','TONKS'),('Bills: Energy','TEST'),('Bills: Telephone','TEST'),('Bills: Water','TEST'),('Bills:Banking','TONKS'),('Bills:Credit Card Payment','TONKS'),('Bills:Fines','TONKS'),('Bills:Insurance','TONKS'),('Bills:Loans','TONKS'),('Bills:Mobile Phones','TONKS'),('Bills:Mortgage','TONKS'),('Bills:Motor','TONKS'),('Bills:Postage','TONKS'),('Bills:Prescriptions','TONKS'),('Bills:Tax','TONKS'),('Bills:Transport','TONKS'),('Bills:TV','TONKS'),('Bills:Utilities','TONKS'),('Books','TONKS'),('Cash','TONKS'),('Cash:Regular','TONKS'),('Catalogue','TONKS'),('Charity','TONKS'),('Clothing','TONKS'),('Clothing : Aimee','TONKS'),('Clothing : Harvey','TONKS'),('Clothing : Sam','TONKS'),('Clothing:Kids','TONKS'),('Clothing:Mark','TONKS'),('Clothing:Sam','TONKS'),('Computer','TONKS'),('Danger Money','TONKS'),('Delivery Charge','TONKS'),('Entertainment','TONKS'),('Entertainment: Books','TEST'),('Entertainment: DVDs','TEST'),('Entertainment: Hobbies','TEST'),('Entertainment:Books','TONKS'),('Entertainment:Days Out','TONKS'),('Entertainment:Gambling','TONKS'),('Entertainment:Games','TONKS'),('Entertainment:Hobbies','TONKS'),('Entertainment:Holidays','TONKS'),('Entertainment:Kindle Books','TONKS'),('Entertainment:Lottery','TONKS'),('Entertainment:Music','TONKS'),('Food','TONKS'),('Food:Dining','TONKS'),('Food:Groceries','TONKS'),('Food:School Dinners','TONKS'),('Food:Snacks','TONKS'),('Garden','TONKS'),('Gifts','TEST'),('Gifts','TONKS'),('Hobbies','TONKS'),('Home','TONKS'),('Home:Appliances','TONKS'),('Home:Decorations','TONKS'),('Home:Furniture','TONKS'),('Household','TONKS'),('Insurance','TONKS'),('Insurance Gracie','TONKS'),('Insurance Rufus','TONKS'),('Interest','TONKS'),('Medical','TONKS'),('Medical:Opticians','TONKS'),('Miscellaneous','TONKS'),('Other Income','TONKS'),('Other Income:Refunds','TONKS'),('Other Income:Winnings','TONKS'),('Overdraft fee','TONKS'),('Personal:Spends','TONKS'),('Pets','TONKS'),('Pocket Money','TONKS'),('Refund','TONKS'),('Returned Clothing','TONKS'),('Returns','TONKS'),('Salary','TEST'),('Salary','TONKS'),('Savings','TONKS'),('Service Charge','TONKS'),('Subscriptions','TONKS'),('Test Transactions','TONKS'),('Transfer','TEST'),('Transfer','TONKS'),('Transfer:Monthly Spends','TONKS'),('Work:Expenses','TONKS');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `entry`
--

DROP TABLE IF EXISTS `entry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `entry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `date` date NOT NULL,
  `accountid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `payee` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `amountcr` decimal(10,2) NOT NULL,
  `notes` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `iscleared` tinyint(1) NOT NULL,
  `isplaceholder` tinyint(1) NOT NULL,
  `transfertxn` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`date`),
  KEY `account` (`accountid`),
  KEY `transfertxn` (`transfertxn`)
) ENGINE=MyISAM AUTO_INCREMENT=6890 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `entry`
--

LOCK TABLES `entry` WRITE;
/*!40000 ALTER TABLE `entry` DISABLE KEYS */;
INSERT INTO `entry` VALUES (5837,'2014-10-22','FDMARK','Terry Testdata','Test Transactions',111.11,'These are my notes',1,0,0),(5838,'2014-11-01','FDMARK','Terry Testdata','Test Transactions',222.22,'A second transaction! Yay!',1,0,0),(2923,'2012-11-22','HXSAM','Reconciled','Miscellaneous',11.59,'',1,0,0),(2924,'2012-11-22','HXSAM','Partylite','Home',-42.85,'',1,0,0),(2925,'2012-11-24','HXSAM','<Current Account MARK HALIFAX>','Transfer',35.00,'',1,0,0),(2926,'2012-11-24','NEXTCARD','Reconciled','Miscellaneous',-616.97,'',1,0,0),(2927,'2012-11-24','RAINYDAY','Reconciled','Miscellaneous',221.12,'',1,0,0),(2928,'2012-11-24','HXSAM','<Current Account MARK HALIFAX>','Transfer',50.00,'',1,0,0),(2929,'2012-11-26','HXSAM','Vision Value','Medical:Opticians',-5.00,'',1,0,0),(2930,'2012-11-26','HXSAM','Cheque','Miscellaneous',-14.00,'',1,0,0),(2931,'2012-11-26','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.49,'Pocket money app',1,0,0),(2932,'2012-11-27','HXSAM','Cash','Cash',-10.00,'',1,0,0),(2933,'2012-11-27','HXSAM','<Current Account MARK HALIFAX>','Transfer:Monthly Spends',500.00,'',1,0,0),(2934,'2012-11-27','HXSAM','Direct Debit - Dgs/Rpp dd','Bills:Insurance',-9.74,'Washing machine insurance',1,0,0),(2935,'2012-11-27','HXSAM','Apple ITunes','Entertainment:Hobbies',-2.99,'Pocket money app',1,0,0),(2936,'2012-11-27','HXSAM','Amazon','Gifts',-10.99,'',1,0,0),(2937,'2012-11-28','HXSAM','Chelle\'s Dancing','Entertainment:Hobbies',-32.50,'',1,0,0),(2938,'2012-11-28','HXSAM','Paypal','Gifts',-2.39,'',1,0,0),(2939,'2012-11-28','HXSAM','Paypal','Gifts',-4.35,'',1,0,0),(2940,'2012-11-28','HXSAM','Amazon','Gifts',-5.37,'',1,0,0),(2941,'2012-11-28','HXSAM','Amazon','Gifts',-8.96,'',1,0,0),(2942,'2012-11-29','HXSAM','Pets At Home','Pets',-12.06,'',1,0,0),(2943,'2012-11-29','HXSAM','Argos','Gifts',-13.98,'',1,0,0),(2944,'2012-11-30','HXSAM','B&M bargains','Gifts',-22.09,'',1,0,0),(2945,'2012-11-30','HXSAM','Selby College','Salary',484.14,'Sam salary',1,0,0),(2946,'2012-11-30','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(2947,'2012-11-30','HXSAM','Cash','Cash',-20.00,'',1,0,0),(2948,'2012-11-30','HXSAM','Paypal','Gifts',-4.95,'',1,0,0),(2949,'2012-11-30','HXSAM','North Yorkshire County Council','Hobbies',-42.08,'Aimee\'s piano lessons',1,0,0),(2950,'2012-11-30','HXSAM','Cash','Cash',-20.00,'',1,0,0),(2951,'2012-12-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(2952,'2012-12-01','HXSAM','Aimee\'s Savings','Savings',-10.00,'',1,0,0),(2953,'2012-12-01','HXSAM','Harvey\'s Savings','Savings',-10.00,'',1,0,0),(2954,'2012-12-01','HXSAM','<Savings FOR THE FUTURE>','Savings',-20.00,'',1,0,0),(2955,'2012-12-02','HXSAM','Next','Clothing:Mark',-38.00,'Xmas shirt',1,0,0),(2956,'2012-12-03','HXSAM','Tesco Mobile','Bills:Mobile Phones',-1.75,'',1,0,0),(2957,'2012-12-03','HXSAM','Wh Smith','Gifts',-3.20,'',1,0,0),(2958,'2012-12-03','HXSAM','Who Internet','Entertainment:Books',-10.00,'',1,0,0),(2959,'2012-12-03','HXSAM','Halifax','Overdraft fee',-3.50,'Minimum payment',1,0,0),(2960,'2012-12-03','RAINYDAY','<Current Account MARK HALIFAX>','Savings',50.00,'',1,0,0),(2961,'2012-12-04','HXSAM','Amazon','Entertainment:Books',-1.88,'',1,0,0),(2962,'2012-12-04','HXSAM','Hunters','Beauty:Haircut',-32.85,'',1,0,0),(2963,'2012-12-04','HXSAM','Amazon','Entertainment:Books',-3.67,'',1,0,0),(2964,'2012-12-04','HXSAM','Greenthumb','Garden',-16.00,'',1,0,0),(2965,'2012-12-04','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-132.65,'Minimum payment',1,0,0),(2966,'2012-12-04','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',132.65,'Minimum payment',1,0,0),(2967,'2012-12-04','HXSAM','Amazon','Gifts',-12.95,'',1,0,0),(2968,'2012-12-05','HXSAM','Hobby Craft','Home:Decorations',-7.57,'',1,0,0),(2969,'2012-12-05','HXSAM','Outfit','Clothing:Sam',-44.55,'Boots',1,0,0),(2970,'2012-12-05','HXSAM','Wh Smith','Gifts',-17.96,'',1,0,0),(2971,'2012-12-05','HXSAM','River Island','Gifts',-40.00,'',1,0,0),(2972,'2012-12-05','HXSAM','Paypal','Gifts',-14.98,'',1,0,0),(2973,'2012-12-06','HXSAM','Paypal','Clothing',-116.70,'',1,0,0),(2974,'2012-12-06','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(2975,'2012-12-06','HXSAM','Apple ITunes','Entertainment:Hobbies',-2.99,'',1,0,0),(2976,'2012-12-06','HXSAM','Amazon','Gifts',-10.18,'',1,0,0),(2977,'2012-12-06','HXSAM','Amazon','Entertainment:Books',-5.17,'',1,0,0),(2978,'2012-12-06','HXSAM','Rowlands Pharmacy','Bills:Prescriptions',-6.25,'',1,0,0),(2979,'2012-12-06','HXSAM','Amazon','Clothing:Sam',-35.22,'Boots',1,0,0),(2980,'2012-12-07','HXSAM','Weekly Cash - Sam','Cash:Regular',-10.00,'',1,0,0),(2981,'2012-12-07','HXSAM','The York Sweet Shop','Gifts',-13.47,'Choccy Santa & snowman ',1,0,0),(2982,'2012-12-10','HXSAM','Weekly Cash - Sam','Cash:Regular',-10.00,'',1,0,0),(2983,'2012-12-10','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-36.11,'Minimum payment',1,0,0),(2984,'2012-12-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(2985,'2012-12-10','HXSAM','Paypal','Gifts',-17.19,'',1,0,0),(2986,'2012-12-10','HXSAM','Boots','Gifts',-26.00,'Gift voucher',1,0,0),(2987,'2012-12-10','HXSAM','Child Benefit','Other Income',134.80,'',1,0,0),(2988,'2012-12-12','HXSAM','Love You Hair & Beauty','Beauty',-10.00,'',1,0,0),(2989,'2012-12-12','HXSAM','Cash','Cash',-20.00,'',1,0,0),(2990,'2012-12-13','HXSAM','Post Office Counters','Bills:Postage',-12.00,'',1,0,0),(2991,'2012-12-14','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(2992,'2012-12-14','HXSAM','Paypal','Gifts',-4.95,'Moshi monsters ',1,0,0),(2993,'2012-12-14','HXSAM','Next','Clothing',-25.00,'Jumper - mark',1,0,0),(2994,'2012-12-14','HXSAM','Animal','Clothing',-25.00,'Jumper - mark',1,0,0),(2995,'2012-12-17','HXSAM','Cineworld','Entertainment:Hobbies',-2.70,'Ice Age 4',1,0,0),(2996,'2012-12-17','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-0.20,'QI book',1,0,0),(2997,'2012-12-18','HXSAM','Cash','Cash',-10.00,'',1,0,0),(2998,'2012-12-20','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(2999,'2012-12-20','HXSAM','Direct Debit - Sky Digital','Bills:TV',-57.50,'',1,0,0),(3000,'2012-12-21','HXSAM','Selby College','Salary',484.14,'Sam salary',1,0,0),(3001,'2012-12-22','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.99,'',1,0,0),(3002,'2012-12-24','HXSAM','<Current Account MARK HALIFAX>','Transfer:Monthly Spends',500.00,'',1,0,0),(3003,'2012-12-27','HXSAM','Amazon','Books',-0.37,'Work book',1,0,0),(3004,'2012-12-27','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-3.99,'Book for aimee',1,0,0),(3005,'2012-12-27','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-0.99,'Book for aimee',1,0,0),(3006,'2012-12-27','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(3007,'2012-12-27','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3008,'2012-12-28','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.98,'Pocket money reports',1,0,0),(3009,'2012-12-28','HXSAM','Amazon','',-19.66,'Harvey\'s lego',1,0,0),(3010,'2012-12-28','HXSAM','Amazon','Clothing',-25.70,'Harvey\'s school shoes',1,0,0),(3011,'2012-12-28','NEXTCARD','Reconciled','Miscellaneous',-937.15,'',1,0,0),(3012,'2012-12-28','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(3013,'2012-12-28','NEXTCARD','Next','Delivery Charge',-3.99,'Minimum payment',1,0,0),(3014,'2012-12-28','NEXTCARD','Next','Clothing:Kids',-10.00,'Harvey trainers',1,0,0),(3015,'2012-12-28','NEXTCARD','Next','Clothing:Sam',-16.00,'SAMs jumper',1,0,0),(3016,'2012-12-28','NEXTCARD','Next','Clothing:Sam',-16.00,'SAMs jumper',1,0,0),(3017,'2012-12-28','NEXTCARD','Next','Clothing:Kids',-2.00,'Harvey\'s tshirt',1,0,0),(3018,'2012-12-28','NEXTCARD','Next','Home:Decorations',-12.00,'Bookends',1,0,0),(3019,'2012-12-28','NEXTCARD','Next','Clothing:Sam',-12.00,'SAMs sweater',1,0,0),(3020,'2012-12-28','NEXTCARD','Next','Clothing:Sam',-6.00,'Pants',1,0,0),(3021,'2012-12-28','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-55.00,'Minimum payment',1,0,0),(3022,'2012-12-28','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',55.00,'Minimum payment',1,0,0),(3023,'2012-12-29','NEXTCARD','Next','Clothing:Kids',-10.00,'Aimee trainers',1,0,0),(3024,'2012-12-29','NEXTCARD','Next','Clothing:Kids',-10.00,'Aimee joggers',1,0,0),(3025,'2012-12-29','NEXTCARD','Next','Clothing:Kids',-5.50,'Aimee hat',1,0,0),(3026,'2012-12-29','NEXTCARD','Next','Household',-14.00,'Sleepingbag',1,0,0),(3027,'2012-12-29','NEXTCARD','Next','Clothing:Kids',-15.00,'Aimee coat',1,0,0),(3028,'2012-12-31','HXSAM','North Yorkshire County Council','Hobbies',-42.08,'Aimee\'s piano',1,0,0),(3029,'2012-12-31','HXSAM','Paypal','Clothing',-43.66,'Boots - Aftershave & perfume',1,0,0),(3030,'2012-12-31','HXSAM','Love You Hair & Beauty','Beauty',-18.00,'',1,0,0),(3031,'2012-12-31','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.99,'',1,0,0),(3032,'2012-12-31','HXSAM','Home Bargains','Food:Groceries',-4.78,'',1,0,0),(3033,'2012-12-31','HXSAM','Amazon','Clothing',-22.00,'Aimee\'s boots - going back',1,0,0),(3034,'2012-12-31','HXSAM','ParentPay','Entertainment:Days Out',-5.50,'Yorvik trip',1,0,0),(3035,'2012-12-31','HXSAM','Expedia','Bills:Transport',-71.00,'Bristol hotel',1,0,0),(3036,'2012-12-31','HXSAM','Cash','Cash',-80.00,'New Year\'s Eve cash ',1,0,0),(3037,'2013-01-01','RAINYDAY','<Current Account MARK HALIFAX>','Savings',50.00,'',1,0,0),(3038,'2013-01-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(3039,'2013-01-01','HXSAM','<Savings FOR THE FUTURE>','Savings',-25.00,'',1,0,0),(3040,'2013-01-02','HXSAM','Paypal','Clothing',-4.95,'Moshi Monsters',1,0,0),(3041,'2013-01-02','HXSAM','<Savings FOR THE FUTURE>','Savings',-20.00,'',1,0,0),(3042,'2013-01-02','HXSAM','<Savings FOR THE FUTURE>','Transfer',20.00,'Correction',1,0,0),(3043,'2013-01-02','HXSAM','Boots','Medical',-6.99,'Ice pack for knee',1,0,0),(3044,'2013-01-02','HXSAM','Wh Smith','Books',-13.46,'Books & magazines',1,0,0),(3045,'2013-01-02','HXSAM','<Credit Card HALIFAX SAM>','Overdraft fee',-0.50,'',1,0,0),(3046,'2013-01-02','HXSAM','National Lottery','Entertainment:Lottery',-10.00,'',1,0,0),(3047,'2013-01-03','NEXTCARD','<Credit Card HALIFAX MARK>','Transfer',1350.00,'Balance transfer',1,0,0),(3048,'2013-01-03','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3049,'2013-01-03','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(3050,'2013-01-03','HXSAM','Amazon','Entertainment:Books',-5.99,'Book for mark',1,0,0),(3051,'2013-01-04','HXSAM','Amazon','Entertainment:Books',-6.74,'Books for mark',1,0,0),(3052,'2013-01-04','HXSAM','Cash','Cash',-10.00,'Cinema',1,0,0),(3053,'2013-01-04','HXSAM','Brantano','Clothing:Kids',-21.75,'Boots for Aimee ',1,0,0),(3054,'2013-01-04','HXSAM','Pets At Home','Pets',-6.99,'',1,0,0),(3055,'2013-01-04','HXSAM','Cineworld','Entertainment:Hobbies',-2.70,'',1,0,0),(3056,'2013-01-04','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.99,'',1,0,0),(3057,'2013-01-06','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-133.74,'Minimum payment',1,0,0),(3058,'2013-01-06','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',133.74,'Minimum payment',1,0,0),(3059,'2013-01-07','HXSAM','Child Benefit','Other Income',101.10,'',1,0,0),(3060,'2013-01-08','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-44.65,'Minimum payment',1,0,0),(3061,'2013-01-08','HXSAM','Post Office Counters','Bills:Postage',-6.55,'',1,0,0),(3062,'2013-01-09','HXSAM','Amazon','Clothing',-12.99,'Knee band',1,0,0),(3063,'2013-01-09','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-1.91,'',1,0,0),(3064,'2013-01-09','HXSAM','ParentPay','Food:School Dinners',-10.50,'',1,0,0),(3065,'2013-01-09','HXSAM','Weekly Cash - Mark','Cash:Regular',-10.00,'',1,0,0),(3066,'2013-01-09','HXSAM','York Marathon','Entertainment:Hobbies',-47.25,'Yorkshire Marathon',1,0,0),(3067,'2013-01-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(3068,'2013-01-10','HXSAM','Pets At Home','Pets',-10.48,'Fish',1,0,0),(3069,'2013-01-10','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3070,'2013-01-10','NEXTCARD','Next','Clothing',-15.00,'Neutral sweater',1,0,0),(3071,'2013-01-10','NEXTCARD','Next','Clothing',-18.00,'Navy joggers',1,0,0),(3072,'2013-01-10','HXSAM','National Rail','Bills:Transport',-6.90,'',1,0,0),(3073,'2013-01-10','HXSAM','National Rail','Bills:Transport',-12.20,'',1,0,0),(3074,'2013-01-10','HXSAM','National Rail','Bills:Transport',-8.30,'',1,0,0),(3075,'2013-01-11','HXSAM','McDonalds','Food:Dining',-8.25,'',1,0,0),(3076,'2013-01-14','HXSAM','Cineworld','Entertainment:Hobbies',-2.70,'',1,0,0),(3077,'2013-01-14','HXSAM','Stormfront York','Computer',-15.00,'iPhone charger',1,0,0),(3078,'2013-01-14','HXSAM','Wh Smith','Books',-7.99,'Marathon book',1,0,0),(3079,'2013-01-14','HXSAM','Tesco','Food:Groceries',-18.19,'',1,0,0),(3080,'2013-01-14','HXSAM','Love You Hair & Beauty','Beauty',-12.00,'Nails',1,0,0),(3081,'2013-01-14','HXSAM','Hunters','Beauty:Haircut',-27.00,'Sam hair cut',1,0,0),(3082,'2013-01-16','HXSAM','Amazon','Other Income:Refunds',22.00,'',1,0,0),(3083,'2013-01-16','HXSAM','Paypal','Hobbies',-4.95,'Moshi monsters',1,0,0),(3084,'2013-01-17','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3085,'2013-01-18','NEXTCARD','Next','Clothing',-6.00,'Harvey trousers',1,0,0),(3086,'2013-01-18','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3087,'2013-01-22','HXSAM','Sky','Bills:TV',-57.50,'',1,0,0),(3088,'2013-01-23','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3089,'2013-01-24','HXSAM','<Current Account MARK HALIFAX>','Transfer',35.00,'',1,0,0),(3090,'2013-01-24','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3091,'2013-01-24','HXSAM','Tesco Garage','Bills:Motor',-35.50,'Petrol - Golf',1,0,0),(3092,'2013-01-25','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3093,'2013-01-26','HXSAM','<Current Account MARK HALIFAX>','Transfer:Monthly Spends',700.00,'',1,0,0),(3094,'2013-01-28','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(3095,'2013-01-28','HXSAM','The Owl Hotel','Food:Dining',-58.54,'',1,0,0),(3096,'2013-01-28','HXSAM','Amazon','Gifts',-4.00,'Lego for Harvey ',1,0,0),(3097,'2013-01-28','HXSAM','Amazon','Entertainment',-5.59,'Book for aimee',1,0,0),(3098,'2013-01-28','HXSAM','Amazon','Entertainment',-24.76,'Chargers for tablets ',1,0,0),(3099,'2013-01-28','HXSAM','ParentPay','Hobbies',-106.00,'Robin Wood',1,0,0),(3100,'2013-01-29','HXSAM','Paypal','Hobbies',-20.00,'Just giving - Jeff',1,0,0),(3101,'2013-01-29','HXSAM','Amazon','Entertainment',-18.30,'Printer cartridges ',1,0,0),(3102,'2013-01-29','HXSAM','Amazon','Entertainment',-5.99,'Magnetic sheet ',1,0,0),(3103,'2013-01-29','HXSAM','Amazon','Entertainment',-6.53,'Magnetic labels',1,0,0),(3104,'2013-01-30','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3105,'2013-01-30','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3106,'2013-01-30','HXSAM','Morrisons','Food:Groceries',-14.49,'',1,0,0),(3107,'2013-01-30','HXSAM','Amazon','Entertainment',-1.63,'Hdmi cable',1,0,0),(3108,'2013-01-30','HXSAM','Amazon','Entertainment',-44.73,'36.08 Sam',9,0,0),(3109,'2013-01-30','HXSAM','Paypal','Clothing',-4.95,'FAB - earrings ',1,0,0),(3110,'2013-01-30','HXSAM','Paypal','Hobbies',-4.95,'Moshi monsters',1,0,0),(3111,'2013-01-31','HXSAM','Selby College','Salary',488.80,'Sam salary',1,0,0),(3112,'2013-01-31','HXSAM','Guides','Hobbies',-20.00,'',1,0,0),(3113,'2013-01-31','HXSAM','North Yorkshire County Council','Hobbies',-42.08,'Aimee\'s piano',1,0,0),(3114,'2013-01-31','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-1.97,'',1,0,0),(3115,'2013-01-31','HXSAM','The Book People','Books',-6.39,'',1,0,0),(3116,'2013-01-31','HXSAM','The Book People','Books',-22.96,'',1,0,0),(3117,'2013-02-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(3118,'2013-02-01','HXSAM','<Savings FOR THE FUTURE>','Savings',-25.00,'',1,0,0),(3119,'2013-02-01','RAINYDAY','<Current Account MARK HALIFAX>','Savings',50.00,'',1,0,0),(3120,'2013-02-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.37,'Dishwasher cover',1,0,0),(3121,'2013-02-02','HXSAM','Cash','Cash',-30.00,'',1,0,0),(3122,'2013-02-04','NEXTCARD','','Bills:Credit Card Payment',5.00,'Minimum payment',1,0,0),(3123,'2013-02-04','HXSAM','Homebase','Household',-9.58,'',1,0,0),(3124,'2013-02-04','NEXTCARD','Next','Service Charge',-1.27,'',1,0,0),(3125,'2013-02-04','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(3126,'2013-02-04','NEXTCARD','Next','Clothing',-14.00,'Bra',1,0,0),(3127,'2013-02-04','NEXTCARD','Next','Clothing',-14.00,'Mark shirt',1,0,0),(3128,'2013-02-04','NEXTCARD','Next','Clothing',-30.00,'Sam shoes',1,0,0),(3129,'2013-02-04','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(3130,'2013-02-04','NEXTCARD','Next','Catalogue',-3.75,'',1,0,0),(3131,'2013-02-04','HXSAM','Next','Clothing',-5.00,'',1,0,0),(3132,'2013-02-04','HXSAM','DW Fitness','Entertainment:Hobbies',-29.99,'Mark running kit ',1,0,0),(3133,'2013-02-05','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.69,'',1,0,0),(3134,'2013-02-05','HXSAM','Amazon Marketplace','Hobbies',-1.85,'Headphone extension',1,0,0),(3135,'2013-02-06','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3136,'2013-02-06','HXSAM','Paypal','Hobbies',-18.01,'',1,0,0),(3137,'2013-02-06','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3138,'2013-02-06','HXSAM','Partylite','Home',-28.80,'Candles',1,0,0),(3139,'2013-02-08','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3140,'2013-02-08','HXSAM','Argos','Home:Appliances',-18.48,'Blender & jug',1,0,0),(3141,'2013-02-08','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-8.39,'Marks books',1,0,0),(3142,'2013-02-09','FORTHEFUTURE','<Savings FOR THE FUTURE>','Transfer',10.00,'',1,0,0),(3143,'2013-02-09','FORTHEFUTURE','<Savings FOR THE FUTURE>','Transfer',1411.62,'',1,0,0),(3144,'2013-02-10','RAINYDAY','<Savings MARK ISA>','Transfer',13.68,'',1,0,0),(3145,'2013-02-11','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-47.34,'Minimum payment',1,0,0),(3146,'2013-02-11','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-6.62,'Book for Mark',1,0,0),(3147,'2013-02-11','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-6.30,'Books for Sam ',1,0,0),(3148,'2013-02-11','HXSAM','Love You Hair & Beauty','Beauty',-17.00,'',1,0,0),(3149,'2013-02-11','HXSAM','John Alexander Cards','Gifts',-6.24,'',1,0,0),(3150,'2013-02-11','HXSAM','Tesco','Clothing:Kids',-65.00,'',1,0,0),(3151,'2013-02-11','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(3152,'2013-02-11','HXSAM','Amazon','Entertainment',-4.46,'',1,0,0),(3153,'2013-02-11','HXSAM','Amazon','Clothing',-70.56,'Marks trainers',1,0,0),(3154,'2013-02-12','HXSAM','Hotel Chocolat','Gifts',-23.40,'',1,0,0),(3155,'2013-02-13','HXSAM','Paypal','Clothing',-7.25,'Jeans for Sam',1,0,0),(3156,'2013-02-13','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3157,'2013-02-13','HXSAM','Paypal','Hobbies',-6.95,'',1,0,0),(3158,'2013-02-13','HXSAM','Paypal','Hobbies',-7.99,'',1,0,0),(3159,'2013-02-13','HXSAM','Paypal','Hobbies',-8.76,'',1,0,0),(3160,'2013-02-13','HXSAM','Paypal','Hobbies',-17.98,'',1,0,0),(3161,'2013-02-13','HXSAM','The Wishing Well','Food:Dining',-16.38,'',1,0,0),(3162,'2013-02-14','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3163,'2013-02-14','HXSAM','Cash','Cash',-10.00,'',1,0,0),(3164,'2013-02-15','HXSAM','Cash','Cash',-40.00,'Cash for oven ',1,0,0),(3165,'2013-02-15','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.69,'',1,0,0),(3166,'2013-02-16','HXSAM','<Savings PAY FOR IT>','Transfer',500.00,'To load currency card',1,0,0),(3167,'2013-02-16','NEXTCARD','Next ','Returns',-153.00,'',1,0,0),(3168,'2013-02-16','NEXTCARD','Returns','',153.00,'',1,0,0),(3169,'2013-02-18','HXSAM','Fair Fx','Entertainment:Holidays',-500.00,'',1,0,0),(3170,'2013-02-18','HXSAM','Wickes','Home:Appliances',-30.51,'Radiator',1,0,0),(3171,'2013-02-19','HXSAM','Paypal','Hobbies',-23.00,'The bag hut ',1,0,0),(3172,'2013-02-19','HXSAM','Pets At Home','Pets',-9.49,'',1,0,0),(3173,'2013-02-20','HXSAM','TGI Fridays','Food:Dining',-63.61,'Cinema & meal',1,0,0),(3174,'2013-02-20','HXSAM','Sky','Bills:TV',-57.50,'',1,0,0),(3175,'2013-02-20','HXSAM','Cineworld','Entertainment:Hobbies',-7.90,'',1,0,0),(3176,'2013-02-20','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.49,'',1,0,0),(3177,'2013-02-20','HXSAM','<Current Account MARK HALIFAX>','Transfer',150.00,'',1,0,0),(3178,'2013-02-20','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3179,'2013-02-21','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-1.90,'',1,0,0),(3180,'2013-02-23','HXSAM','Cash','Cash',-30.00,'',1,0,0),(3181,'2013-02-24','NEXTCARD','Next','Service Charge',-3.51,'',1,0,0),(3182,'2013-02-24','NEXTCARD','Next','Clothing:Kids',-10.20,'Aimee shorts',1,0,0),(3183,'2013-02-24','NEXTCARD','Next','Clothing:Kids',-9.77,'Aimee cropped trousers',1,0,0),(3184,'2013-02-24','NEXTCARD','Next','Clothing:Kids',-11.90,'Aimee tshirts',1,0,0),(3185,'2013-02-24','NEXTCARD','Next','Clothing:Sam',-11.90,'Top',1,0,0),(3186,'2013-02-24','NEXTCARD','Next','Clothing:Sam',-10.20,'Tshirt',1,0,0),(3187,'2013-02-24','NEXTCARD','Next','Clothing:Kids',-5.95,'',1,0,0),(3188,'2013-02-24','NEXTCARD','Next','Clothing:Kids',-9.35,'',1,0,0),(3189,'2013-02-25','HXSAM','Weekly Cash - Mark','Cash:Regular',-10.00,'',1,0,0),(3190,'2013-02-25','HXSAM','Weekly Cash - Sam','Cash:Regular',-10.00,'',1,0,0),(3191,'2013-02-25','RAINYDAY','Halifax','Interest',0.24,'',1,0,0),(3192,'2013-02-25','HXSAM','Hunters','Beauty:Haircut',-62.00,'',1,0,0),(3193,'2013-02-25','HXSAM','Marks & Spencer','Food:Groceries',-9.20,'',1,0,0),(3194,'2013-02-25','HXSAM','Marks & Spencer','Cash',-10.00,'',1,0,0),(3195,'2013-02-26','HXSAM','Paypal','Other Income',30.00,'',1,0,0),(3196,'2013-02-26','HXSAM','<Savings PAY FOR IT>','Entertainment:Holidays',800.00,'',1,0,0),(3197,'2013-02-26','HXSAM','<RAINYDAY>','Entertainment:Holidays',200.00,'',1,0,0),(3198,'2013-02-26','RAINYDAY','<HXSAM>','Entertainment:Holidays',-200.00,'',1,0,0),(3199,'2013-02-26','HXSAM','Paypal','Other Income',18.23,'',1,0,0),(3200,'2013-02-26','HXSAM','Boots','Medical',-7.74,'',1,0,0),(3201,'2013-02-26','HXSAM','Market Lane Dental','Bills:Prescriptions',-35.00,'',1,0,0),(3202,'2013-02-27','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3203,'2013-02-27','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(3204,'2013-02-27','HXSAM','Fair Fx','Entertainment:Holidays',-1000.74,'Transfer to currency card',1,0,0),(3205,'2013-02-27','HXSAM','Post Office Counters','Bills:Postage',-14.30,'',1,0,0),(3206,'2013-02-28','HXSAM','<Current Account MARK HALIFAX>','Transfer:Monthly Spends',900.00,'',1,0,0),(3207,'2013-02-28','HXSAM','Selby College','Salary',488.80,'Sam salary',1,0,0),(3208,'2013-02-28','FORTHEFUTURE','First Direct','Interest',0.17,'',1,0,0),(3209,'2013-02-28','FORTHEFUTURE','First Direct','Interest',0.60,'',1,0,0),(3210,'2013-02-28','HXSAM','North Yorkshire County Council','Hobbies',-42.08,'Aimee\'s piano lessons',1,0,0),(3211,'2013-03-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(3212,'2013-03-01','HXSAM','<Savings FOR THE FUTURE>','Savings',-25.00,'',1,0,0),(3213,'2013-03-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(3214,'2013-03-01','RAINYDAY','<Current Account MARK HALIFAX>','Savings',50.00,'',1,0,0),(3215,'2013-03-01','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3216,'2013-03-01','HXSAM','Post Office Counters','Bills:Postage',-5.50,'',1,0,0),(3217,'2013-03-02','HXSAM','Weekly Cash - Mark','Cash:Regular',-10.00,'',1,0,0),(3218,'2013-03-02','HXSAM','Cash','Food:Dining',-70.00,'Thai ',1,0,0),(3219,'2013-03-02','HXSAM','Argos','Entertainment:Holidays',-99.87,'Suitcases',1,0,0),(3220,'2013-03-04','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-26.06,'Minimum payment',1,0,0),(3221,'2013-03-04','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',26.06,'Minimum payment',1,0,0),(3222,'2013-03-04','HXSAM','MandMDirect.com','Clothing:Mark',-188.33,'',1,0,0),(3223,'2013-03-04','HXSAM','Outfit','Clothing:Sam',-87.80,'',1,0,0),(3224,'2013-03-04','HXSAM','Cafe Del Amis','Food:Dining',-14.00,'',1,0,0),(3225,'2013-03-04','HXSAM','Debenhams','Clothing:Sam',-103.00,'',1,0,0),(3226,'2013-03-04','HXSAM','Asda','Gifts',-19.50,'',1,0,0),(3227,'2013-03-04','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.49,'',1,0,0),(3228,'2013-03-04','HXSAM','B&M bargains','Food:Groceries',-8.23,'',1,0,0),(3229,'2013-03-04','HXSAM','Home Bargains','Entertainment:Holidays',-27.75,'Sun cream, etc',1,0,0),(3230,'2013-03-05','HXSAM','Chelle\'s Dancing','Entertainment:Hobbies',-8.00,'',1,0,0),(3231,'2013-03-05','HXSAM','Cash','Cash',-10.00,'',1,0,0),(3232,'2013-03-06','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3233,'2013-03-06','HXSAM','Paypal','Clothing:Kids',-7.85,'Aimee tracksuit',1,0,0),(3234,'2013-03-06','HXSAM','Outfit','Other Income',25.00,'',1,0,0),(3235,'2013-03-06','HXSAM','Debenhams','Clothing:Sam',-102.64,'',1,0,0),(3236,'2013-03-06','HXSAM','Boots','Medical',-42.19,'',1,0,0),(3237,'2013-03-07','FDMARK','<Current Account MARK HALIFAX>','Transfer',10.00,'Test transfer to new current account',1,0,0),(3238,'2013-03-07','HXSAM','Misc','Gifts',-12.95,'',1,0,0),(3239,'2013-03-07','FDMARK','<Current Account MARK HALIFAX>','Transfer',1000.00,'',1,0,0),(3240,'2013-03-08','FORTHEFUTURE','<Savings FOR THE FUTURE>','Transfer',25.00,'',1,0,0),(3241,'2013-03-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(3242,'2013-03-11','FDMARK','Tesco Garage','Bills:Motor',-66.44,'Petrol - BMW',1,0,0),(3243,'2013-03-11','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(3244,'2013-03-11','HXSAM','Amazon','Gifts',-15.86,'',1,0,0),(3245,'2013-03-11','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-10.00,'',1,0,0),(3246,'2013-03-11','FDMARK','Tesco','Food:Groceries',-6.95,'',1,0,0),(3247,'2013-03-11','FDMARK','Tesco','Food:Groceries',-108.95,'',1,0,0),(3248,'2013-03-12','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-46.12,'Minimum payment',1,0,0),(3249,'2013-03-12','HXSAM','Amazon','Miscellaneous',-9.05,'',1,0,0),(3250,'2013-03-12','HXSAM','Amazon','Miscellaneous',-46.56,'',1,0,0),(3251,'2013-03-12','HXSAM','Animal','Clothing',-49.00,'',1,0,0),(3252,'2013-03-12','HXSAM','Amazon','Miscellaneous',-9.88,'',1,0,0),(3253,'2013-03-12','HXSAM','Next','Clothing',-24.98,'',1,0,0),(3254,'2013-03-13','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3255,'2013-03-13','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(3256,'2013-03-13','HXSAM','Cash','Cash',-10.00,'',1,0,0),(3257,'2013-03-13','HXSAM','Amazon','Miscellaneous',-8.09,'',1,0,0),(3258,'2013-03-13','FDMARK','BT','Bills:Utilities',-35.11,'House phone & broadband',1,0,0),(3259,'2013-03-13','HXSAM','<Current Account MARK HALIFAX>','Entertainment:Holidays',700.00,'Holiday spends',1,0,0),(3260,'2013-03-13','HXSAM','Kids Savings','Entertainment:Holidays',200.00,'Holiday spends',1,0,0),(3261,'2013-03-14','HXSAM','Gap','Clothing',-46.15,'',1,0,0),(3262,'2013-03-14','HXSAM','MandMDirect.com','Other Income:Refunds',16.98,'',1,0,0),(3263,'2013-03-14','HXSAM','Wh Smith','Books',-22.26,'',1,0,0),(3264,'2013-03-14','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'',1,0,0),(3265,'2013-03-15','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(3266,'2013-03-15','FDMARK','O2','Bills:Mobile Phones',-21.50,'Sam\'s iPhone ',1,0,0),(3267,'2013-03-15','HXSAM','Fair Fx','Entertainment:Holidays',-700.00,'Holiday spends',1,0,0),(3268,'2013-03-16','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3269,'2013-03-16','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-17.00,'Minimum payment ',1,0,0),(3270,'2013-03-18','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-16.06,'',1,0,0),(3271,'2013-03-18','HXSAM','Debenhams','Other Income:Refunds',23.04,'',1,0,0),(3272,'2013-03-18','HXSAM','Collectables','Miscellaneous',-14.96,'',1,0,0),(3273,'2013-03-18','HXSAM','Cineworld','Entertainment:Hobbies',-13.14,'',1,0,0),(3274,'2013-03-18','FDMARK','Tesco Garage','Food:Groceries',-22.47,'',1,0,0),(3275,'2013-03-19','FDMARK','Tesco Garage','Food:Groceries',-7.22,'',1,0,0),(3276,'2013-03-19','HXSAM','ParentPay','Hobbies',-4.00,'',1,0,0),(3277,'2013-03-19','HXSAM','Love You Hair & Beauty','Beauty',-35.00,'',1,0,0),(3278,'2013-03-19','HXSAM','Hallmark Cards','Gifts',-7.46,'',1,0,0),(3279,'2013-03-20','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3280,'2013-03-20','HXSAM','Sky','Bills:TV',-60.99,'',1,0,0),(3281,'2013-03-20','FDMARK','Tesco','Food:Groceries',-103.50,'Weekly shopping',1,0,0),(3282,'2013-03-20','FDMARK','Lovefilm.com','Entertainment:Hobbies',-14.99,'',1,0,0),(3283,'2013-03-20','HXSAM','Cash','Cash',-10.00,'',1,0,0),(3284,'2013-03-20','HXSAM','6th Selby Scouts','Hobbies',-8.00,'',1,0,0),(3285,'2013-03-20','HXSAM','Paypal','Miscellaneous',-8.24,'',1,0,0),(3286,'2013-03-20','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3287,'2013-03-20','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-7.31,'',1,0,0),(3288,'2013-03-22','HXSAM','Argos','Gifts',-16.99,'Aimee\'s doll',1,0,0),(3289,'2013-03-22','HXSAM','B&M bargains','Food:Groceries',-12.72,'',1,0,0),(3290,'2013-03-23','FDMARK','Tesco','Food:Groceries',-128.71,'Weekly shopping',1,0,0),(3291,'2013-03-23','FDMARK','Direct Debit - Camelot Group','Entertainment:Gambling',-18.00,'Lottery subscription',1,0,0),(3292,'2013-03-25','FDMARK','O2','Bills:Mobile Phones',-37.15,'Mark\'s iPhone ',1,0,0),(3293,'2013-03-25','FDMARK','ParentPay','Food:School Dinners',-8.60,'',1,0,0),(3294,'2013-03-25','HXSAM','Homebase','Household',-21.71,'',1,0,0),(3295,'2013-03-25','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-0.99,'',1,0,0),(3296,'2013-03-25','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-1.99,'',1,0,0),(3297,'2013-03-25','HXSAM','Claire\'s Accessories','Clothing:Kids',-5.00,'',1,0,0),(3298,'2013-03-25','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-6.94,'',1,0,0),(3299,'2013-03-25','HXSAM','McDonalds','Food:Dining',-9.55,'',1,0,0),(3300,'2013-03-25','HXSAM','Love You Hair & Beauty','Beauty',-20.00,'',1,0,0),(3301,'2013-03-25','HXSAM','Animal','Clothing',-40.00,'',1,0,0),(3302,'2013-03-25','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3303,'2013-03-26','HXSAM','Paypal','Miscellaneous',-0.67,'',1,0,0),(3304,'2013-03-26','HXSAM','Paypal','Miscellaneous',-0.67,'',1,0,0),(3305,'2013-03-26','HXSAM','<Current Account MARK HALIFAX>','Transfer',40.00,'',1,0,0),(3306,'2013-03-26','FDMARK','<Current Account MARK HALIFAX>','Transfer',40.00,'',1,0,0),(3307,'2013-03-26','FDMARK','Tesco Garage','Food:Groceries',-15.99,'',1,0,0),(3308,'2013-03-27','FDMARK','Aviva','Salary',6538.00,'',1,0,0),(3309,'2013-03-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',1400.00,'',1,0,0),(3310,'2013-03-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1400.00,'',1,0,0),(3311,'2013-03-27','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(3312,'2013-03-27','HXSAM','<FDMARK>','Transfer',10.00,'',1,0,0),(3313,'2013-03-27','FDMARK','<HXSAM>','Transfer',-10.00,'',1,0,0),(3314,'2013-03-27','HXSAM','Paypal','Miscellaneous',-0.67,'',1,0,0),(3315,'2013-03-27','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3316,'2013-03-27','FDMARK','Market Lane Dental','Bills:Prescriptions',-30.50,'',1,0,0),(3317,'2013-03-27','HXSAM','Starbucks','Food:Dining',-5.45,'',1,0,0),(3318,'2013-03-27','HXSAM','Collectables','Miscellaneous',-5.98,'',1,0,0),(3319,'2013-03-27','HXSAM','Marks & Spencer','Miscellaneous',-24.00,'',1,0,0),(3320,'2013-03-27','HXSAM','Gap','Clothing',-25.57,'',1,0,0),(3321,'2013-03-27','HXSAM','Trespass','Clothing',-70.43,'',1,0,0),(3322,'2013-03-28','HXSAM','Selby College','Salary',488.80,'Sam salary',1,0,0),(3323,'2013-03-28','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3324,'2013-03-28','HXSAM','Pets At Home','Pets',-8.00,'',1,0,0),(3325,'2013-03-28','HXSAM','Rowlands Pharmacy','Bills:Prescriptions',-15.30,'',1,0,0),(3326,'2013-03-28','HXSAM','Holmefield Vets','Pets',-33.79,'',1,0,0),(3327,'2013-03-28','HXSAM','Travel Money','Entertainment:Holidays',-700.05,'',1,0,0),(3328,'2013-03-29','FDMARK','Tesco Garage','Food:Groceries',-12.35,'',1,0,0),(3329,'2013-03-30','FDMARK','Tesco Garage','Bills:Motor',-73.67,'BMW',1,0,0),(3330,'2013-03-30','HXSAM','Cash','Cash',-40.00,'Sam eyebrows & tan',1,0,0),(3331,'2013-03-30','HXSAM','Cash','Cash',-50.00,'',1,0,0),(3332,'2013-03-31','FORTHEFUTURE','First Direct','Interest',0.25,'',1,0,0),(3333,'2013-03-31','FORTHEFUTURE','First Direct','Interest',0.98,'',1,0,0),(3334,'2013-04-01','FDMARK','Cash','Cash',-60.00,'',1,0,0),(3335,'2013-04-01','FDMARK','Tesco Garage','Food:Groceries',-7.81,'',1,0,0),(3336,'2013-04-01','FDMARK','Next','Clothing:Mark',-15.00,'',1,0,0),(3337,'2013-04-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(3338,'2013-04-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(3339,'2013-04-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(3340,'2013-04-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(3341,'2013-04-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(3342,'2013-04-01','HXSAM','<Savings FOR THE FUTURE>','Savings',-25.00,'',1,0,0),(3343,'2013-04-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(3344,'2013-04-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(3345,'2013-04-01','NEXTCARD','Next','Clothing',-10.00,'',1,0,0),(3346,'2013-04-01','HXSAM','North Yorkshire County Council','Hobbies',-42.08,'Aimee\'s piano lessons',1,0,0),(3347,'2013-04-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(3348,'2013-04-02','HXSAM','Paypal','Miscellaneous',-50.83,'',1,0,0),(3349,'2013-04-02','HXSAM','Boots','Medical',-32.15,'',1,0,0),(3350,'2013-04-02','HXSAM','Amazon','Miscellaneous',-5.94,'',1,0,0),(3351,'2013-04-02','HXSAM','Amazon','Miscellaneous',-5.49,'',1,0,0),(3352,'2013-04-02','HXSAM','Halifax','Bills:Banking',-2.00,'Overdraft fee',1,0,0),(3353,'2013-04-02','FDMARK','T-Mobile','Bills:Mobile Phones',-20.00,'',1,0,0),(3354,'2013-04-02','FDMARK','Tesco Garage','Food:Groceries',-13.45,'',1,0,0),(3355,'2013-04-02','HXSAM','Love You Hair & Beauty','Beauty',-23.00,'',1,0,0),(3356,'2013-04-03','HXSAM','Debenhams','Other Income:Refunds',16.78,'',1,0,0),(3357,'2013-04-03','HXSAM','Amazon','Miscellaneous',-0.49,'',1,0,0),(3358,'2013-04-03','NEXTCARD','Next','Clothing',-22.00,'',1,0,0),(3359,'2013-04-03','NEXTCARD','Next','Clothing',-24.00,'',1,0,0),(3360,'2013-04-03','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(3361,'2013-04-03','NEXTCARD','Next','Clothing',-5.95,'',1,0,0),(3362,'2013-04-03','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-16.11,'Mark sunglasses',1,0,0),(3363,'2013-04-03','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',16.11,'Mark sunglasses',1,0,0),(3364,'2013-04-04','FDMARK','Aviva Healthcare','Bills:Insurance',-58.51,'Health insurance',1,0,0),(3365,'2013-04-05','FDMARK','Aviva Household','Bills:Insurance',-25.25,'',1,0,0),(3366,'2013-04-08','HXSAM','Paypal','Miscellaneous',-3.89,'',1,0,0),(3367,'2013-04-08','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.69,'',1,0,0),(3368,'2013-04-08','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-3.80,'',1,0,0),(3369,'2013-04-08','FDMARK','O2','Bills:Mobile Phones',-22.84,'Sam\'s iPhone ',1,0,0),(3370,'2013-04-08','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-12.51,'',1,0,0),(3371,'2013-04-08','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-21.83,'Minimum payment',1,0,0),(3372,'2013-04-08','FDMARK','G C Diggins','Home',-125.00,'Boiler service',1,0,0),(3373,'2013-04-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(3374,'2013-04-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(3375,'2013-04-10','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-2.49,'',1,0,0),(3376,'2013-04-10','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3377,'2013-04-11','FDMARK','First Direct','Other Income',100.00,'Joining incentive',1,0,0),(3378,'2013-04-11','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(3379,'2013-04-12','FDMARK','BT','Bills:Utilities',-53.02,'House phone & broadband',1,0,0),(3380,'2013-04-12','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(3381,'2013-04-15','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3382,'2013-04-15','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-15.75,'',1,0,0),(3383,'2013-04-15','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(3384,'2013-04-16','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-35.00,'',1,0,0),(3385,'2013-04-16','FDMARK','Tesco','Food:Groceries',-41.66,'',1,0,0),(3386,'2013-04-17','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3387,'2013-04-17','FDMARK','ParentPay','Food:School Dinners',-14.70,'',1,0,0),(3388,'2013-04-17','FDMARK','Park & Ride','Bills:Transport',-30.00,'Bus monthly fee',1,0,0),(3389,'2013-04-17','HXSAM','<Current Account MARK HALIFAX>','Transfer',4.38,'',1,0,0),(3390,'2013-04-17','HXSAM','<Current Account MARK HALIFAX>','Transfer',-7.00,'',1,0,0),(3391,'2013-04-17','FORTHEFUTURE','<Savings FOR THE FUTURE>','Transfer',25.00,'',1,0,0),(3392,'2013-04-17','RAINYDAY','<Savings PAY FOR IT>','Transfer',11.19,'',1,0,0),(3393,'2013-04-17','FDMARK','Aviva Motor','Bills:Insurance',-428.80,'',1,0,0),(3394,'2013-04-18','HXSAM','Weekly Cash - Mark','Cash:Regular',-30.00,'',1,0,0),(3395,'2013-04-18','FDMARK','First/Keolis Trans','Bills:Transport',-6.90,'',1,0,0),(3396,'2013-04-18','FDMARK','Layerthorpe','Bills:Motor',-313.69,'Golf door lock',1,0,0),(3397,'2013-04-18','FDMARK','Aldi','Food:Groceries',-22.62,'',1,0,0),(3398,'2013-04-19','FDMARK','Tesco Garage','Food:Groceries',-13.69,'',1,0,0),(3399,'2013-04-19','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-4.94,'',1,0,0),(3400,'2013-04-19','FDMARK','Lovefilm.com','Entertainment:Hobbies',-14.99,'',1,0,0),(3401,'2013-04-19','HXSAM','CPC','Entertainment:Hobbies',-54.53,'Raspberry Pi',1,0,0),(3402,'2013-04-19','FDMARK','Jean Tonks','Bills:Motor',-125.00,'Golf MOT',1,0,0),(3403,'2013-04-22','FDMARK','Tesco','Food:Groceries',-136.38,'',1,0,0),(3404,'2013-04-22','HXSAM','Sky','Bills:TV',-57.50,'',1,0,0),(3405,'2013-04-22','HXSAM','Argos','Home',-6.49,'',1,0,0),(3406,'2013-04-22','HXSAM','B&M bargains','Food:Groceries',-9.99,'',1,0,0),(3407,'2013-04-22','HXSAM','Snapfish','Entertainment:Holidays',-3.94,'',1,0,0),(3408,'2013-04-22','HXSAM','Amazon Marketplace','Hobbies',-6.90,'',1,0,0),(3409,'2013-04-22','HXSAM','The Owl Hotel','Food:Dining',-62.07,'',1,0,0),(3410,'2013-04-22','HXSAM','Snapfish','Entertainment:Holidays',-40.87,'',1,0,0),(3411,'2013-04-22','FDMARK','National Rail','Bills:Transport',-25.20,'Railcard ',1,0,0),(3412,'2013-04-22','FDMARK','National Rail','Bills:Transport',-101.40,'Tickets to London ',1,0,0),(3413,'2013-04-23','FDMARK','Direct Debit - Camelot Group','Entertainment:Gambling',-18.00,'Lottery subscription',1,0,0),(3414,'2013-04-23','HXSAM','Amazon','Gifts',-103.20,'',1,0,0),(3415,'2013-04-24','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3416,'2013-04-24','HXSAM','Amazon Marketplace','Gifts',-14.41,'',1,0,0),(3417,'2013-04-24','HXSAM','Amazon Marketplace','Gifts',-21.50,'',1,0,0),(3418,'2013-04-25','FDMARK','O2','Bills:Mobile Phones',-39.95,'Mark\'s iPhone ',1,0,0),(3419,'2013-04-25','HXSAM','Paypal','Miscellaneous',-0.66,'',1,0,0),(3420,'2013-04-25','HXSAM','Paypal','Miscellaneous',-0.66,'',1,0,0),(3421,'2013-04-25','HXSAM','Paypal','Miscellaneous',-1.26,'',1,0,0),(3422,'2013-04-25','HXSAM','Cash','Cash',-30.00,'',1,0,0),(3423,'2013-04-25','HXSAM','CPC','Entertainment:Hobbies',-10.58,'USB hub',1,0,0),(3424,'2013-04-26','FDMARK','Aviva','Salary',3890.00,'',1,0,0),(3425,'2013-04-26','FDMARK','Tesco Garage','Food:Groceries',-12.22,'',1,0,0),(3426,'2013-04-26','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3427,'2013-04-27','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(3428,'2013-04-29','RAINYDAY','<FDMARK>','Savings',1990.00,'',1,0,0),(3429,'2013-04-29','FDMARK','<RAINYDAY>','Savings',-1990.00,'',1,0,0),(3430,'2013-04-29','RAINYDAY','<FDMARK>','Transfer',10.00,'',1,0,0),(3431,'2013-04-29','FDMARK','<RAINYDAY>','Transfer',-10.00,'',1,0,0),(3432,'2013-04-29','HXSAM','<FDMARK>','Transfer:Monthly Spends',700.00,'',1,0,0),(3433,'2013-04-29','FDMARK','<HXSAM>','Transfer:Monthly Spends',-700.00,'',1,0,0),(3434,'2013-04-29','HXSAM','Hunters','Beauty:Haircut',-37.00,'',1,0,0),(3435,'2013-04-29','HXSAM','Wilkinsons','Household',-29.78,'',1,0,0),(3436,'2013-04-29','HXSAM','B&M bargains','Food:Groceries',-16.21,'',1,0,0),(3437,'2013-04-29','HXSAM','Homebase','Household',-17.47,'',1,0,0),(3438,'2013-04-29','HXSAM','Argos','Home',-29.99,'',1,0,0),(3439,'2013-04-30','FDMARK','Tesco','Food:Groceries',-102.61,'',1,0,0),(3440,'2013-04-30','FDMARK','Park & Ride','Bills:Transport',-45.00,'Bus monthly fee',1,0,0),(3441,'2013-04-30','HXSAM','Selby College','Salary',610.94,'Sam salary',1,0,0),(3442,'2013-04-30','FORTHEFUTURE','First Direct','Interest',0.24,'',1,0,0),(3443,'2013-04-30','FORTHEFUTURE','First Direct','Interest',0.96,'',1,0,0),(3444,'2013-04-30','HXSAM','Paypal','Miscellaneous',-0.66,'',1,0,0),(3445,'2013-04-30','HXSAM','North Yorkshire County Council','Hobbies',-42.08,'',1,0,0),(3446,'2013-04-30','HXSAM','Amazon','Gifts',-34.11,'',1,0,0),(3447,'2013-05-01','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3448,'2013-05-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(3449,'2013-05-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(3450,'2013-05-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(3451,'2013-05-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(3452,'2013-05-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-154.02,'',1,0,0),(3453,'2013-05-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(3454,'2013-05-01','HXSAM','<Savings FOR THE FUTURE>','Savings',-25.00,'',1,0,0),(3455,'2013-05-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(3456,'2013-05-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(3457,'2013-05-01','NEXTCARD','Next','Service Charge',-3.95,'',1,0,0),(3458,'2013-05-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(3459,'2013-05-01','HXSAM','Greenthumb','Garden',-16.00,'',1,0,0),(3460,'2013-05-01','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3461,'2013-05-01','HXSAM','Amazon','Entertainment:Books',-1.95,'',1,0,0),(3462,'2013-05-01','HXSAM','Amazon','Entertainment:Books',-3.00,'',1,0,0),(3463,'2013-05-01','HXSAM','Amazon','Entertainment:Books',-5.86,'',1,0,0),(3464,'2013-05-01','HXSAM','<Credit Card HALIFAX SAM>','Overdraft fee',-1.00,'',1,0,0),(3465,'2013-05-02','FDMARK','ParentPay','Food:School Dinners',-53.00,'',1,0,0),(3466,'2013-05-02','HXSAM','Fair Fx','Other Income',809.80,'',1,0,0),(3467,'2013-05-02','HXSAM','B&M bargains','Food:Groceries',-11.94,'',1,0,0),(3468,'2013-05-02','HXSAM','Blacksmiths Arms','Food:Dining',-29.35,'',1,0,0),(3469,'2013-05-02','HXSAM','Cash','Cash',-10.00,'',1,0,0),(3470,'2013-05-03','FDMARK','AA','Bills:Insurance',-62.13,'',1,0,0),(3471,'2013-05-03','FDMARK','Tesco','Food:Groceries',-36.33,'',1,0,0),(3472,'2013-05-03','FDMARK','Tesco Garage','Food:Groceries',-8.39,'',1,0,0),(3473,'2013-05-03','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3474,'2013-05-03','HXSAM','Tesco Garage','Food:Groceries',-8.00,'',1,0,0),(3475,'2013-05-03','FDMARK','Aviva Accounts Rec','Work:Expenses',214.80,'',1,0,0),(3476,'2013-05-05','FDMARK','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-400.00,'',1,0,0),(3477,'2013-05-05','FORTHEFUTURE','<Savings FOR THE FUTURE>','Transfer',25.00,'',1,0,0),(3478,'2013-05-05','NEXTCARD','Next','Clothing',-65.00,'',1,0,0),(3479,'2013-05-05','NEXTCARD','Next','Clothing',-18.50,'',1,0,0),(3480,'2013-05-05','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(3481,'2013-05-05','FDMARK','<Credit Card BARCLAYCARD>','Work:Expenses',-414.80,'',1,0,0),(3482,'2013-05-05','HXSAM','<RAINYDAY>','Transfer',-800.00,'',1,0,0),(3483,'2013-05-05','RAINYDAY','<HXSAM>','Transfer',800.00,'',1,0,0),(3484,'2013-05-06','NEXTCARD','Next','Service Charge',-5.52,'',1,0,0),(3485,'2013-05-07','FDMARK','Tesco','Food:Groceries',-118.29,'',1,0,0),(3486,'2013-05-07','FDMARK','Aviva Healthcare','Bills:Insurance',-58.51,'Health insurance',1,0,0),(3487,'2013-05-07','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-21.16,'Minimum payment',1,0,0),(3488,'2013-05-07','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',21.16,'Minimum payment',1,0,0),(3489,'2013-05-07','HXSAM','Frankie & Benny\'s','Food:Dining',-68.95,'',1,0,0),(3490,'2013-05-07','HXSAM','<NEXTCARD>','Clothing',-150.00,'',1,0,0),(3491,'2013-05-07','NEXTCARD','<HXSAM>','Clothing',150.00,'',1,0,0),(3492,'2013-05-07','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-12.38,'',1,0,0),(3493,'2013-05-07','HXSAM','Cash','Cash',-40.00,'Cash in brid',1,0,0),(3494,'2013-05-07','HXSAM','Amazon','Gifts',-16.99,'',1,0,0),(3495,'2013-05-07','HXSAM','ParentPay','Food:School Dinners',-18.80,'',1,0,0),(3496,'2013-05-08','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3497,'2013-05-08','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.69,'',1,0,0),(3498,'2013-05-08','HXSAM','Amazon','Gifts',-5.99,'',1,0,0),(3499,'2013-05-08','HXSAM','Amazon Marketplace','Gifts',-29.88,'',1,0,0),(3500,'2013-05-08','FDMARK','Aviva Household','Bills:Insurance',-25.25,'',1,0,0),(3501,'2013-05-08','HXSAM','Amazon','Gifts',-116.60,'',1,0,0),(3502,'2013-05-08','HXSAM','Weekly Cash - Sam','Cash:Regular',-10.00,'',1,0,0),(3503,'2013-05-08','FDMARK','Big Bus Tour','Entertainment:Days Out',-64.00,'Bus tour in London ',1,0,0),(3504,'2013-05-09','FDMARK','Prize Payment ','Other Income:Winnings',10.00,'',1,0,0),(3505,'2013-05-09','HXSAM','Paypal','Miscellaneous',-22.96,'',1,0,0),(3506,'2013-05-09','FDMARK','O2','Bills:Mobile Phones',-42.00,'Sam\'s iPhone ',1,0,0),(3507,'2013-05-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(3508,'2013-05-09','HXSAM','Paypal','Miscellaneous',-7.50,'Gutter brackets',1,0,0),(3509,'2013-05-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(3510,'2013-05-10','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.69,'',1,0,0),(3511,'2013-05-10','HXSAM','Love You Hair & Beauty','Beauty',-16.00,'',1,0,0),(3512,'2013-05-11','FDMARK','Cash','Cash',-100.00,'',1,0,0),(3513,'2013-05-13','FDMARK','Tesco','Food:Groceries',-107.87,'',1,0,0),(3514,'2013-05-13','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(3515,'2013-05-13','FDMARK','BT','Bills:Utilities',-48.22,'House phone & broadband',1,0,0),(3516,'2013-05-13','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-20.39,'Minimum payment',1,0,0),(3517,'2013-05-13','FDMARK','Tesco Garage','Bills:Motor',-65.27,'BMW ',1,0,0),(3518,'2013-05-13','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(3519,'2013-05-13','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3520,'2013-05-13','FDMARK','Tower Of London ','Entertainment:Days Out',-42.90,'',1,0,0),(3521,'2013-05-14','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(3522,'2013-05-14','HXSAM','Amazon Marketplace','Gifts',-3.15,'',1,0,0),(3523,'2013-05-14','HXSAM','Amazon Marketplace','Gifts',-27.90,'',1,0,0),(3524,'2013-05-15','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3525,'2013-05-15','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(3526,'2013-05-15','HXSAM','Aldi','Food:Groceries',-15.20,'',1,0,0),(3527,'2013-05-15','FDMARK','Prize Payment ','Other Income:Winnings',10.00,'',1,0,0),(3528,'2013-05-15','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-25.73,'',1,0,0),(3529,'2013-05-15','HXSAM','Amazon','Gifts',-8.39,'',1,0,0),(3530,'2013-05-15','HXSAM','Amazon','Gifts',-30.27,'',1,0,0),(3531,'2013-05-16','FDMARK','Morrisons','Food:Groceries',-18.01,'',1,0,0),(3532,'2013-05-18','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-16.02,'',1,0,0),(3533,'2013-05-18','HXSAM','<RAINYDAY>','Transfer',150.00,'Telly table & meal ',1,0,0),(3534,'2013-05-18','RAINYDAY','<HXSAM>','Transfer',-150.00,'Telly table & meal ',1,0,0),(3535,'2013-05-20','FDMARK','Tesco','Food:Groceries',-130.58,'',1,0,0),(3536,'2013-05-20','FDMARK','Lovefilm.com','Entertainment:Hobbies',-14.99,'',1,0,0),(3537,'2013-05-20','HXSAM','Cash','Cash',-80.00,'',1,0,0),(3538,'2013-05-20','HXSAM','Rachel Hall','Other Income',44.00,'',1,0,0),(3539,'2013-05-20','HXSAM','Sainsbury\'s','Food:Groceries',-28.31,'',1,0,0),(3540,'2013-05-21','FDMARK','Morrisons','Food:Groceries',-18.28,'',1,0,0),(3541,'2013-05-22','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3542,'2013-05-22','HXSAM','Paypal','Home:Furniture',-95.00,'Telly table',1,0,0),(3543,'2013-05-22','HXSAM','Sky','Bills:TV',-57.50,'',1,0,0),(3544,'2013-05-22','FDMARK','Tesco Garage','Bills:Motor',-51.77,'Petrol - Golf',1,0,0),(3545,'2013-05-22','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3546,'2013-05-23','FDMARK','Direct Debit - Camelot Group','Entertainment:Gambling',-16.00,'Lottery subscription',1,0,0),(3547,'2013-05-23','HXSAM','Cash','Cash',-10.00,'',1,0,0),(3548,'2013-05-23','HXSAM','Love You Hair & Beauty','Beauty',-19.00,'',1,0,0),(3549,'2013-05-24','FDMARK','Aviva','Salary',3867.00,'',1,0,0),(3550,'2013-05-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',700.00,'',1,0,0),(3551,'2013-05-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-700.00,'',1,0,0),(3552,'2013-05-28','HXSAM','Dietchef','Food:Dining',-97.50,'',1,0,0),(3553,'2013-05-28','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.78,'',1,0,0),(3554,'2013-05-28','HXSAM','Banardos','Entertainment:Books',-14.87,'',1,0,0),(3555,'2013-05-28','FDMARK','Tesco','Food:Groceries',-126.76,'',1,0,0),(3556,'2013-05-28','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(3557,'2013-05-28','FDMARK','O2','Bills:Mobile Phones',-61.23,'Mark\'s iPhone ',1,0,0),(3558,'2013-05-28','FDMARK','Tesco Garage','Food:Groceries',-8.97,'',1,0,0),(3559,'2013-05-28','HXSAM','Homebase','Household',-56.95,'Plants',1,0,0),(3560,'2013-05-29','HXSAM','Weatherspoons','Food:Dining',-13.48,'',1,0,0),(3561,'2013-05-29','HXSAM','Homebase','Household',-27.51,'Plants & paint',1,0,0),(3562,'2013-05-29','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3563,'2013-05-29','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(3564,'2013-05-30','HXSAM','Paypal','Entertainment:Games',-0.67,'',1,0,0),(3565,'2013-05-30','HXSAM','Paypal','Entertainment:Games',-0.74,'',1,0,0),(3566,'2013-05-30','HXSAM','Paypal','Gifts',-33.00,'',1,0,0),(3567,'2013-05-30','HXSAM','Cineworld','Entertainment:Days Out',-12.28,'',1,0,0),(3568,'2013-05-30','HXSAM','Pets At Home','Pets',-46.08,'',1,0,0),(3569,'2013-05-31','FDMARK','Marks & Spencer','Clothing:Kids',-16.15,'',1,0,0),(3570,'2013-05-31','FDMARK','Tesco Garage','Pets',-7.01,'',1,0,0),(3571,'2013-05-31','FORTHEFUTURE','First Direct','Interest',0.26,'',1,0,0),(3572,'2013-05-31','FORTHEFUTURE','First Direct','Interest',1.03,'',1,0,0),(3573,'2013-05-31','HXSAM','Paypal','Gifts',-0.67,'',1,0,0),(3574,'2013-05-31','HXSAM','Jean Tonks','Clothing:Kids',-26.00,'',1,0,0),(3575,'2013-05-31','HXSAM','Asda','Clothing:Kids',-80.50,'',1,0,0),(3576,'2013-05-31','HXSAM','Selby College','Salary',610.94,'Sam salary',1,0,0),(3577,'2013-05-31','HXSAM','North Yorkshire County Council','Hobbies',-42.08,'Aimee\'s piano lessons',1,0,0),(3578,'2013-06-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(3579,'2013-06-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(3580,'2013-06-03','HXSAM','Pet\'s Pad','Pets',-52.65,'',1,0,0),(3581,'2013-06-03','HXSAM','Holmefield Vets','Pets',-9.99,'',1,0,0),(3582,'2013-06-03','HXSAM','Holmefield Vets','Pets',-9.02,'',1,0,0),(3583,'2013-06-03','FDMARK','Tesco','Food:Groceries',-124.75,'',1,0,0),(3584,'2013-06-03','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(3585,'2013-06-03','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(3586,'2013-06-03','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(3587,'2013-06-03','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(3588,'2013-06-03','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(3589,'2013-06-03','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-151.00,'',1,0,0),(3590,'2013-06-03','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(3591,'2013-06-03','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(3592,'2013-06-03','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(3593,'2013-06-03','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(3594,'2013-06-03','HXSAM','Minecraft','Entertainment:Hobbies',-17.95,'',1,0,0),(3595,'2013-06-04','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-13.81,'Minimum payment',1,0,0),(3596,'2013-06-04','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',13.81,'Minimum payment',1,0,0),(3597,'2013-06-04','HXSAM','Amazon Marketplace','Gifts',-14.49,'',1,0,0),(3598,'2013-06-05','HXSAM','Amazon','Gifts',-33.28,'Father\'s Day gifts ',1,0,0),(3599,'2013-06-05','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3600,'2013-06-05','FDMARK','Aviva Healthcare','Bills:Insurance',-58.51,'Health insurance',1,0,0),(3601,'2013-06-05','FDMARK','Aviva Household','Bills:Insurance',-25.25,'',1,0,0),(3602,'2013-06-05','FDMARK','Prize Payment ','Other Income:Winnings',10.00,'',1,0,0),(3603,'2013-06-05','FDMARK','CPC','Entertainment:Hobbies',-66.23,'',1,0,0),(3604,'2013-06-05','HXSAM','Tempest Photos','Entertainment',-16.00,'School photos',1,0,0),(3605,'2013-06-05','HXSAM','Tempest Photos','Entertainment',-16.00,'School photos',1,0,0),(3606,'2013-06-05','HXSAM','The Oaks Golf Club','Entertainment:Days Out',-10.00,'',1,0,0),(3607,'2013-06-05','HXSAM','Jolleys Pet Food','Pets',-27.96,'',1,0,0),(3608,'2013-06-06','FDMARK','Tesco Garage','Food:Groceries',-17.91,'',1,0,0),(3609,'2013-06-06','HXSAM','Weekly Cash - Sam','Cash:Regular',-50.00,'',1,0,0),(3610,'2013-06-07','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(3611,'2013-06-07','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-11.03,'',1,0,0),(3612,'2013-06-10','FDMARK','Tesco','Food:Groceries',-102.33,'',1,0,0),(3613,'2013-06-10','FDMARK','O2','Bills:Mobile Phones',-22.34,'Sam\'s iPhone ',1,0,0),(3614,'2013-06-10','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(3615,'2013-06-10','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-17.72,'Minimum payment',1,0,0),(3616,'2013-06-10','FDMARK','Tesco Garage','Bills:Motor',-66.31,'BMW ',1,0,0),(3617,'2013-06-10','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3618,'2013-06-10','FDMARK','Morrisons','Food:Groceries',-19.97,'',1,0,0),(3619,'2013-06-10','FDMARK','Tesco Garage','Bills:Motor',-32.37,'',1,0,0),(3620,'2013-06-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(3621,'2013-06-10','HXSAM','Rachel Hall','Other Income',25.00,'Mark\'s birthday money',1,0,0),(3622,'2013-06-10','HXSAM','Love You Hair & Beauty','Beauty',-5.00,'',1,0,0),(3623,'2013-06-10','HXSAM','Cineworld','Entertainment:Days Out',-3.00,'',1,0,0),(3624,'2013-06-10','HXSAM','Banardos','Entertainment:Books',-10.43,'',1,0,0),(3625,'2013-06-11','NEXTCARD','Next','Service Charge',-3.84,'',1,0,0),(3626,'2013-06-11','NEXTCARD','Next','Clothing',-299.78,'',1,0,0),(3627,'2013-06-11','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(3628,'2013-06-11','FDMARK','BT','Bills:Utilities',-43.22,'House phone & broadband',1,0,0),(3629,'2013-06-11','HXSAM','Amazon Marketplace','Gifts',-41.30,'',1,0,0),(3630,'2013-06-12','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3631,'2013-06-12','FDMARK','Park & Ride','Bills:Transport',-20.00,'',1,0,0),(3632,'2013-06-12','FDMARK','Aldi','Food:Groceries',-13.83,'',1,0,0),(3633,'2013-06-12','HXSAM','Pets At Home','Pets',-15.50,'',1,0,0),(3634,'2013-06-13','FDMARK','ParentPay','Food:School Dinners',-25.20,'',1,0,0),(3635,'2013-06-13','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-0.62,'',1,0,0),(3636,'2013-06-13','HXSAM','Harvey Tonks','Other Income',50.00,'',1,0,0),(3637,'2013-06-13','HXSAM','Aimee Tonks','Other Income',70.00,'',1,0,0),(3638,'2013-06-13','HXSAM','Cash','Cash',-20.00,'Aimee dancing exam',1,0,0),(3639,'2013-06-13','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(3640,'2013-06-14','FDMARK','Sainsbury\'s','Food:Groceries',-12.58,'',1,0,0),(3641,'2013-06-14','HXSAM','<RAINYDAY>','Transfer',150.00,'Much needed cash',1,0,0),(3642,'2013-06-14','RAINYDAY','<HXSAM>','Transfer',-150.00,'Much needed cash',1,0,0),(3643,'2013-06-14','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(3644,'2013-06-14','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(3645,'2013-06-14','HXSAM','Paypal','Gifts',-4.95,'',1,0,0),(3646,'2013-06-14','HXSAM','Cash','Cash',-30.00,'',1,0,0),(3647,'2013-06-17','FDMARK','Tesco','Food:Groceries',-93.26,'',1,0,0),(3648,'2013-06-17','HXSAM','Sweatshop','Hobbies',-110.00,'Marks trainers',1,0,0),(3649,'2013-06-17','HXSAM','Moss Bros','Clothing:Mark',-229.00,'Marks suit ',1,0,0),(3650,'2013-06-17','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-15.87,'',1,0,0),(3651,'2013-06-17','HXSAM','Cash','Cash',-50.00,'',1,0,0),(3652,'2013-06-17','HXSAM','Starbucks','Food:Dining',-6.40,'',1,0,0),(3653,'2013-06-17','HXSAM','The Works','Gifts',-6.99,'',1,0,0),(3654,'2013-06-17','HXSAM','Monsoon','Clothing:Sam',-11.00,'',1,0,0),(3655,'2013-06-19','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3656,'2013-06-19','FDMARK','Lovefilm.com','Entertainment:Hobbies',-14.99,'',1,0,0),(3657,'2013-06-20','HXSAM','Sky','Bills:TV',-60.99,'',1,0,0),(3658,'2013-06-20','HXSAM','Post Office Counters','Bills:Postage',-19.92,'',1,0,0),(3659,'2013-06-21','HXSAM','Cash','Cash',-30.00,'',1,0,0),(3660,'2013-06-24','FDMARK','Tesco','Food:Groceries',-146.35,'',1,0,0),(3661,'2013-06-24','HXSAM','Paypal','Miscellaneous',-11.69,'',1,0,0),(3662,'2013-06-24','HXSAM','Hunters','Beauty:Haircut',-54.00,'',1,0,0),(3663,'2013-06-24','FDMARK','Tesco Garage','Bills:Motor',-70.01,'Petrol - Golf',1,0,0),(3664,'2013-06-24','FDMARK','Direct Debit - Camelot Group','Entertainment:Gambling',-18.00,'Lottery subscription',1,0,0),(3665,'2013-06-24','FDMARK','Aviva','Work:Expenses',456.60,'',1,0,0),(3666,'2013-06-24','FDMARK','Tesco Garage','Food:Groceries',-10.32,'',1,0,0),(3667,'2013-06-24','FDMARK','Tesco Garage','Food:Groceries',-10.04,'',1,0,0),(3668,'2013-06-24','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(3669,'2013-06-24','FDMARK','Nick Summerton','Home:Furniture',-439.00,'',1,0,0),(3670,'2013-06-25','FDMARK','O2','Bills:Mobile Phones',-37.84,'Mark\'s iPhone ',1,0,0),(3671,'2013-06-25','HXSAM','Amazon','Books',-0.02,'',1,0,0),(3672,'2013-06-25','HXSAM','Dietchef','Other Income:Refunds',97.50,'',1,0,0),(3673,'2013-06-26','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3674,'2013-06-26','HXSAM','Paypal','Miscellaneous',-14.00,'Shoes',1,0,0),(3675,'2013-06-26','HXSAM','New Look','Clothing:Sam',-10.98,'',1,0,0),(3676,'2013-06-26','HXSAM','Boots','Medical',-20.61,'',1,0,0),(3677,'2013-06-26','HXSAM','Outfit','Clothing:Sam',-88.00,'',1,0,0),(3678,'2013-06-26','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3679,'2013-06-27','FDMARK','Aviva','Salary',3867.00,'',1,0,0),(3680,'2013-06-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',700.00,'',1,0,0),(3681,'2013-06-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-700.00,'',1,0,0),(3682,'2013-06-27','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(3683,'2013-06-28','FDMARK','Tesco Garage','Food:Groceries',-13.83,'',1,0,0),(3684,'2013-06-28','HXSAM','Paypal','Clothing:Sam',-17.73,'Shoes',1,0,0),(3685,'2013-06-28','HXSAM','Paypal','Clothing:Sam',-103.00,'Dress',1,0,0),(3686,'2013-06-28','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3687,'2013-06-28','HXSAM','Amazon Marketplace','Hobbies',-6.50,'',1,0,0),(3688,'2013-06-28','HXSAM','Amazon Marketplace','Hobbies',-3.56,'',1,0,0),(3689,'2013-06-28','HXSAM','Aldi','Food:Groceries',-14.38,'',1,0,0),(3690,'2013-06-28','FDMARK','Aviva','Work:Expenses',277.69,'',1,0,0),(3691,'2013-06-28','HXSAM','Selby College','Salary',610.94,'Sam salary',1,0,0),(3692,'2013-06-28','HXSAM','Amazon Marketplace','Entertainment:Hobbies',-2.13,'',1,0,0),(3693,'2013-06-29','HXSAM','Cash','Cash',-50.00,'Theatre sam',1,0,0),(3694,'2013-06-30','FORTHEFUTURE','First Direct','Interest',0.25,'',1,0,0),(3695,'2013-06-30','FORTHEFUTURE','First Direct','Interest',1.01,'',1,0,0),(3696,'2013-07-01','FDMARK','Tesco','Food:Groceries',-134.57,'',1,0,0),(3697,'2013-07-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(3698,'2013-07-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(3699,'2013-07-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(3700,'2013-07-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(3701,'2013-07-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(3702,'2013-07-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-151.00,'',1,0,0),(3703,'2013-07-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(3704,'2013-07-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(3705,'2013-07-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(3706,'2013-07-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(3707,'2013-07-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(3708,'2013-07-01','FDMARK','B&M bargains','Food:Groceries',-23.39,'',1,0,0),(3709,'2013-07-01','HXSAM','North Yorkshire County Council','Hobbies',-42.08,'Aimee\'s piano lessons',1,0,0),(3710,'2013-07-01','HXSAM','Pet Health Plan','Pets',-15.00,'',1,0,0),(3711,'2013-07-01','HXSAM','Jolleys Pet Food','Pets',-33.98,'',1,0,0),(3712,'2013-07-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(3713,'2013-07-01','HXSAM','Amazon','Entertainment:Hobbies',-15.94,'',1,0,0),(3714,'2013-07-01','HXSAM','Home Bargains','Food:Groceries',-8.48,'',1,0,0),(3715,'2013-07-01','HXSAM','Dorothy Perkins','Clothing:Sam',-23.00,'',1,0,0),(3716,'2013-07-01','FDMARK','Tesco Garage','Bills:Motor',-70.20,'Petrol - BMW',1,0,0),(3717,'2013-07-01','HXSAM','Love You Hair & Beauty','Beauty',-16.00,'',1,0,0),(3718,'2013-07-01','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(3719,'2013-07-02','FDMARK','ParentPay','Food:School Dinners',-34.00,'',1,0,0),(3720,'2013-07-02','HXSAM','Apple ITunes','Entertainment:Hobbies',-2.18,'',1,0,0),(3721,'2013-07-02','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-949.29,'',1,0,0),(3722,'2013-07-02','HXSAM','CPC','Entertainment:Hobbies',-43.78,'',1,0,0),(3723,'2013-07-02','HXSAM','Weekly Cash - Sam','Cash:Regular',-40.00,'',1,0,0),(3724,'2013-07-03','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3725,'2013-07-03','FDMARK','Tesco Garage','Food:Groceries',-5.61,'',1,0,0),(3726,'2013-07-03','HXSAM','TGI Fridays','Food:Dining',-11.06,'',1,0,0),(3727,'2013-07-04','NEXTCARD','Next','Service Charge',-5.43,'',1,0,0),(3728,'2013-07-04','FDMARK','Aviva Healthcare','Bills:Insurance',-58.51,'Health insurance',1,0,0),(3729,'2013-07-04','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-41.07,'Minimum payment',1,0,0),(3730,'2013-07-04','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',41.07,'Minimum payment',1,0,0),(3731,'2013-07-04','FDMARK','Cash','Cash',-10.00,'',1,0,0),(3732,'2013-07-04','FDMARK','Wh Smith','Books',-16.22,'',1,0,0),(3733,'2013-07-04','FDMARK','Tesco Garage','Food:Groceries',-16.21,'',1,0,0),(3734,'2013-07-04','HXSAM','Blacksmiths Arms','Food:Dining',-23.00,'',1,0,0),(3735,'2013-07-04','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(3736,'2013-07-05','HXSAM','Cash','Cash',-10.00,'',1,0,0),(3737,'2013-07-06','FDMARK','Aviva Household','Bills:Insurance',-25.25,'',1,0,0),(3738,'2013-07-06','NEXTCARD','<FDMARK>','Bills:Credit Card Payment',120.00,'',1,0,0),(3739,'2013-07-06','FDMARK','<NEXTCARD>','Bills:Credit Card Payment',-120.00,'',1,0,0),(3740,'2013-07-08','FDMARK','Tesco','Food:Groceries',-142.67,'',1,0,0),(3741,'2013-07-08','FDMARK','O2','Bills:Mobile Phones',-24.44,'Sam\'s iPhone ',1,0,0),(3742,'2013-07-08','HXSAM','Cash','Cash',-30.00,'Mother shipton\'s cave cash',1,0,0),(3743,'2013-07-08','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(3744,'2013-07-08','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3745,'2013-07-08','FDMARK','Tesco Garage','Food:Groceries',-20.94,'',1,0,0),(3746,'2013-07-09','NEXTCARD','Next','Returns',39.01,'',1,0,0),(3747,'2013-07-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(3748,'2013-07-09','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-14.24,'Minimum payment',1,0,0),(3749,'2013-07-10','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3750,'2013-07-10','FDMARK','Hotel Chocolat','Gifts',-14.00,'',1,0,0),(3751,'2013-07-10','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-1.14,'',1,0,0),(3752,'2013-07-10','HXSAM','The Works','Gifts',-7.57,'',1,0,0),(3753,'2013-07-10','HXSAM','Mountain Warehouse','Clothing:Kids',-49.44,'',1,0,0),(3754,'2013-07-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(3755,'2013-07-11','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(3756,'2013-07-11','FDMARK','BT','Bills:Utilities',-44.43,'House phone & broadband',1,0,0),(3757,'2013-07-11','HXSAM','Paypal','Miscellaneous',-1.26,'',1,0,0),(3758,'2013-07-11','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3759,'2013-07-11','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3760,'2013-07-11','HXSAM','2nd Brayton Guides','Hobbies',-45.00,'',1,0,0),(3761,'2013-07-12','HXSAM','Cash','Cash',-20.00,'',1,0,0),(3762,'2013-07-15','FDMARK','Tesco','Food:Groceries',-131.47,'',1,0,0),(3763,'2013-07-15','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(3764,'2013-07-15','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-16.44,'',1,0,0),(3765,'2013-07-15','FDMARK','Homebase','Household',-209.39,'Shed stuff',1,0,0),(3766,'2013-07-15','HXSAM','Love You Hair & Beauty','Beauty',-16.00,'',1,0,0),(3767,'2013-07-15','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(3768,'2013-07-16','FDMARK','Park & Ride','Bills:Transport',-40.00,'Bus monthly fee',1,0,0),(3769,'2013-07-16','HXSAM','Argos','Gifts',-19.99,'Stuart\'s birthday',1,0,0),(3770,'2013-07-16','FDMARK','Homebase','Household',-33.27,'',1,0,0),(3771,'2013-07-16','FDMARK','Homebase','Household',-50.47,'',1,0,0),(3772,'2013-07-16','FDMARK','B&M bargains','Food:Groceries',-10.12,'',1,0,0),(3773,'2013-07-16','HXSAM','Paypal','Miscellaneous',-4.95,'',1,0,0),(3774,'2013-07-16','HXSAM','Homesense','Household',-13.99,'',1,0,0),(3775,'2013-07-17','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3776,'2013-07-17','HXSAM','6th Selby Scouts','Hobbies',-30.00,'Camp',1,0,0),(3777,'2013-07-17','HXSAM','Cheque','Miscellaneous',-8.00,'',1,0,0),(3778,'2013-07-18','FDMARK','Aldi','Food:Groceries',-13.65,'',1,0,0),(3779,'2013-07-18','FDMARK','Argos','Gifts',-23.98,'',1,0,0),(3780,'2013-07-18','FDMARK','Argos','Gifts',-24.98,'',1,0,0),(3781,'2013-07-18','HXSAM','Apple ITunes','Entertainment:Hobbies',-12.99,'',1,0,0),(3782,'2013-07-18','HXSAM','McDonalds','Food:Dining',-11.33,'',1,0,0),(3783,'2013-07-19','FDMARK','Lovefilm.com','Entertainment:Hobbies',-13.27,'',1,0,0),(3784,'2013-07-19','HXSAM','Mrs V Kelly','Hobbies',-42.95,'',1,0,0),(3785,'2013-07-20','HXSAM','Sky','Bills:TV',-57.50,'',1,0,0),(3786,'2013-07-22','FDMARK','Tesco','Food:Groceries',-123.05,'',1,0,0),(3787,'2013-07-22','FDMARK','Tesco  ','Food:Groceries',-42.02,'',1,0,0),(3788,'2013-07-22','FDMARK','Tesco Garage','Bills:Motor',-79.68,'BMW ',1,0,0),(3789,'2013-07-22','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.69,'',1,0,0),(3790,'2013-07-22','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-4.59,'',1,0,0),(3791,'2013-07-23','FDMARK','Direct Debit - Camelot Group','Entertainment:Gambling',-18.00,'Lottery subscription',1,0,0),(3792,'2013-07-23','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-8.51,'',1,0,0),(3793,'2013-07-23','HXSAM','Barratts','Clothing:Mark',-43.00,'',1,0,0),(3794,'2013-07-24','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3795,'2013-07-24','HXSAM','Greenthumb','Garden',-16.00,'',1,0,0),(3796,'2013-07-24','HXSAM','The Works','Gifts',-5.96,'',1,0,0),(3797,'2013-07-24','HXSAM','Marks & Spencer','Food',-12.00,'',1,0,0),(3798,'2013-07-25','FDMARK','O2','Bills:Mobile Phones',-37.15,'Mark\'s iPhone ',1,0,0),(3799,'2013-07-25','HXSAM','Weekly Cash - Sam','Cash:Regular',-50.00,'',1,0,0),(3800,'2013-07-26','FDMARK','Aviva','Salary',3867.00,'',1,0,0),(3801,'2013-07-26','FDMARK','Rowlands Pharmacy','Bills:Prescriptions',-14.65,'',1,0,0),(3802,'2013-07-26','HXSAM','Rock One','Miscellaneous',-30.00,'',1,0,0),(3803,'2013-07-26','HXSAM','Love You Hair & Beauty','Beauty',-31.50,'',1,0,0),(3804,'2013-07-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',800.00,'',1,0,0),(3805,'2013-07-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-800.00,'',1,0,0),(3806,'2013-07-29','FDMARK','Tesco','Food:Groceries',-109.55,'',1,0,0),(3807,'2013-07-29','FDMARK','Tesco Garage','Food:Groceries',-18.11,'',1,0,0),(3808,'2013-07-29','HXSAM','Amazon Marketplace','Entertainment:Hobbies',-13.72,'',1,0,0),(3809,'2013-07-29','HXSAM','Jolleys Pet Food','Pets',-14.37,'',1,0,0),(3810,'2013-07-29','HXSAM','Amazon','Entertainment:Hobbies',-14.99,'',1,0,0),(3811,'2013-07-29','HXSAM','Tesco Garage','Food:Groceries',-5.90,'Pancake toppings',1,0,0),(3812,'2013-07-29','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(3813,'2013-07-29','HXSAM','Fit Camp ','Entertainment:Holidays',-669.30,'Balance',1,0,0),(3814,'2013-07-29','FDMARK','Tesco Garage','Bills:Motor',-59.50,'Petrol - Golf',1,0,0),(3815,'2013-07-29','HXSAM','Cash','Cash',-50.00,'Maze',1,0,0),(3816,'2013-07-30','HXSAM','Cineworld','Entertainment:Days Out',-17.91,'',1,0,0),(3817,'2013-07-30','HXSAM','Cineworld','Entertainment:Days Out',-11.59,'',1,0,0),(3818,'2013-07-30','HXSAM','<FDMARK>','Entertainment:Holidays',670.00,'Pay Balance for fit camp',1,0,0),(3819,'2013-07-30','FDMARK','<HXSAM>','Entertainment:Holidays',-670.00,'Pay Balance for fit camp',1,0,0),(3820,'2013-07-31','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3821,'2013-07-31','FDMARK','Tesco Garage','Food:Groceries',-12.75,'Spuds & dishwasher tabs',1,0,0),(3822,'2013-07-31','FDMARK','Tesco Garage','Food:Groceries',-4.35,'Medicine for kids',1,0,0),(3823,'2013-07-31','HXSAM','Amazon','Entertainment:Hobbies',-3.67,'Battery boxes',1,0,0),(3824,'2013-07-31','FORTHEFUTURE','First Direct','Interest',0.27,'',1,0,0),(3825,'2013-07-31','FORTHEFUTURE','First Direct','Interest',1.06,'',1,0,0),(3826,'2013-07-31','HXSAM','Selby College','Salary',630.87,'Sam salary',1,0,0),(3827,'2013-08-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(3828,'2013-08-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(3829,'2013-08-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(3830,'2013-08-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(3831,'2013-08-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(3832,'2013-08-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-151.00,'',1,0,0),(3833,'2013-08-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(3834,'2013-08-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(3835,'2013-08-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(3836,'2013-08-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(3837,'2013-08-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(3838,'2013-08-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(3839,'2013-08-01','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(3840,'2013-08-02','HXSAM','Neulion/NFL','Hobbies',-33.49,'NFL game pass',1,0,0),(3841,'2013-08-02','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-3.99,'',1,0,0),(3842,'2013-08-02','HXSAM','Chatsworth House','Gifts',-20.58,'',1,0,0),(3843,'2013-08-02','HXSAM','Chatsworth House','Gifts',-25.48,'',1,0,0),(3844,'2013-08-05','FDMARK','Tesco','Food:Groceries',-93.58,'',1,0,0),(3845,'2013-08-05','FDMARK','Sainsbury\'s','Food:Groceries',-73.44,'',1,0,0),(3846,'2013-08-05','HXSAM','Wilkinsons','Household',-73.05,'',1,0,0),(3847,'2013-08-05','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-22.72,'',1,0,0),(3848,'2013-08-05','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-22.76,'',1,0,0),(3849,'2013-08-05','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',22.76,'',1,0,0),(3850,'2013-08-05','HXSAM','Owl Hotel','Food:Dining',-53.72,'',1,0,0),(3851,'2013-08-05','FDMARK','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-330.00,'Pay deposit for fit camp',1,0,0),(3852,'2013-08-05','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(3853,'2013-08-05','FDMARK','Aldi','Food:Groceries',-17.82,'',1,0,0),(3854,'2013-08-06','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(3855,'2013-08-06','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(3856,'2013-08-06','HXSAM','Subway','Food:Dining',-8.40,'',1,0,0),(3857,'2013-08-06','HXSAM','The Works','Gifts',-10.95,'',1,0,0),(3858,'2013-08-06','HXSAM','Holland & Barrett','Food:Snacks',-16.14,'',1,0,0),(3859,'2013-08-06','HXSAM','Cineworld','Entertainment:Days Out',-19.90,'',1,0,0),(3860,'2013-08-07','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3861,'2013-08-07','HXSAM','Paypal','Miscellaneous',-4.95,'',1,0,0),(3862,'2013-08-07','HXSAM','Paypal','Miscellaneous',-4.95,'',1,0,0),(3863,'2013-08-07','FDMARK','Aviva Household','Bills:Insurance',-25.25,'',1,0,0),(3864,'2013-08-07','HXSAM','Amazon','Entertainment:Hobbies',-79.25,'Apple TV',1,0,0),(3865,'2013-08-08','FDMARK','Aviva Accounts Rec','Work:Expenses',1243.26,'',1,0,0),(3866,'2013-08-08','FDMARK','O2','Bills:Mobile Phones',-21.99,'Sam\'s iPhone ',1,0,0),(3867,'2013-08-08','FDMARK','Sainsbury\'s','Food:Groceries',-27.96,'',1,0,0),(3868,'2013-08-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(3869,'2013-08-09','HXSAM','Hearst Magazines Uk','Entertainment:Hobbies',-14.00,'',1,0,0),(3870,'2013-08-09','HXSAM','Tesco Garage','Food:Groceries',-10.54,'',1,0,0),(3871,'2013-08-11','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-15.34,'Minimum payment',1,0,0),(3872,'2013-08-12','FDMARK','Tesco','Food:Groceries',-103.84,'',1,0,0),(3873,'2013-08-12','HXSAM','Hunters','Beauty:Haircut',-37.00,'',1,0,0),(3874,'2013-08-12','HXSAM','Wh Smith','Books',-31.98,'',1,0,0),(3875,'2013-08-12','HXSAM','Sainsbury\'s','Food:Groceries',-118.20,'',1,0,0),(3876,'2013-08-12','HXSAM','Pizza Hut','Food:Dining',-33.31,'',1,0,0),(3877,'2013-08-12','HXSAM','Love You Hair & Beauty','Beauty',-16.00,'',1,0,0),(3878,'2013-08-12','HXSAM','Debenhams','Other Income:Refunds',-57.50,'',1,0,0),(3879,'2013-08-12','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-1243.26,'',1,0,0),(3880,'2013-08-12','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(3881,'2013-08-12','FDMARK','BT','Bills:Utilities',-44.94,'House phone & broadband',1,0,0),(3882,'2013-08-12','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(3883,'2013-08-12','HXSAM','Holmefield Vets','Pets',-6.93,'',1,0,0),(3884,'2013-08-12','HXSAM','National Lottery','Entertainment:Lottery',-10.00,'',1,0,0),(3885,'2013-08-12','HXSAM','Thai Sushine','Food:Dining',-62.75,'',1,0,0),(3886,'2013-08-12','HXSAM','Weekly Cash - Mark','Cash:Regular',-30.00,'',1,0,0),(3887,'2013-08-13','HXSAM','<NEXTCARD>','Clothing:Mark',-60.00,'Repay marks shirts',1,0,0),(3888,'2013-08-13','NEXTCARD','<HXSAM>','Clothing:Mark',60.00,'Repay marks shirts',1,0,0),(3889,'2013-08-13','FDMARK','Tesco Garage','Bills:Motor',-61.56,'BMW ',1,0,0),(3890,'2013-08-14','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3891,'2013-08-14','FDMARK','Park & Ride','Bills:Transport',-30.00,'Bus monthly fee',1,0,0),(3892,'2013-08-14','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(3893,'2013-08-14','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(3894,'2013-08-14','HXSAM','Paypal','Miscellaneous',-4.95,'',1,0,0),(3895,'2013-08-14','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.99,'',1,0,0),(3896,'2013-08-15','HXSAM','Cineworld','Entertainment:Days Out',-19.36,'',1,0,0),(3897,'2013-08-16','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-17.57,'',1,0,0),(3898,'2013-08-16','HXSAM','Frankie & Benny\'s','Food:Dining',-26.25,'',1,0,0),(3899,'2013-08-16','HXSAM','Holland & Barrett','Food:Snacks',-10.87,'',1,0,0),(3900,'2013-08-16','HXSAM','Argos','Gifts',-159.98,'',1,0,0),(3901,'2013-08-16','HXSAM','<RAINYDAY>','Transfer',200.00,'',1,0,0),(3902,'2013-08-16','RAINYDAY','<HXSAM>','Transfer',-200.00,'',1,0,0),(3903,'2013-08-16','FDMARK','Tesco','Food:Groceries',-30.38,'',1,0,0),(3904,'2013-08-16','HXSAM','Toyz+','Gifts',-6.98,'',1,0,0),(3905,'2013-08-16','HXSAM','Cineworld','Entertainment:Days Out',-10.05,'',1,0,0),(3906,'2013-08-17','FDMARK','Cash','Cash',-50.00,'Drayton manor park',1,0,0),(3907,'2013-08-19','FDMARK','Tesco','Food:Groceries',-105.59,'',1,0,0),(3908,'2013-08-19','FDMARK','Home Bargains','Food:Groceries',-10.41,'',1,0,0),(3909,'2013-08-19','HXSAM','Boots','Medical',-13.91,'',1,0,0),(3910,'2013-08-19','HXSAM','TSL Clothing','Clothing',-21.00,'',1,0,0),(3911,'2013-08-19','HXSAM','Apple ITunes','Entertainment:Hobbies',-12.99,'Ancestry.com',1,0,0),(3912,'2013-08-19','FDMARK','Lovefilm.com','Entertainment:Hobbies',-13.27,'',1,0,0),(3913,'2013-08-19','HXSAM','Corner Pin','Food:Dining',-7.39,'',1,0,0),(3914,'2013-08-20','FDMARK','B&M bargains','Food:Groceries',-5.95,'',1,0,0),(3915,'2013-08-20','FDMARK','Aldi','Food:Groceries',-11.72,'',1,0,0),(3916,'2013-08-21','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3917,'2013-08-21','HXSAM','Sky','Bills:TV',-59.19,'',1,0,0),(3918,'2013-08-21','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(3919,'2013-08-21','FDMARK','Tesco','Food:Groceries',-14.48,'',1,0,0),(3920,'2013-08-22','FDMARK','Aviva CS UK Ltd','Work:Expenses',244.60,'',1,0,0),(3921,'2013-08-22','HXSAM','B&M bargains','Food:Groceries',-9.47,'',1,0,0),(3922,'2013-08-23','HXSAM','Paypal','Miscellaneous',-5.32,'',1,0,0),(3923,'2013-08-23','HXSAM','Homebase','Household',-20.14,'',1,0,0),(3924,'2013-08-23','FDMARK','Direct Debit - Camelot Group','Entertainment:Gambling',-16.00,'Lottery subscription',1,0,0),(3925,'2013-08-25','NEXTCARD','Next ','Clothing',-254.57,'',1,0,0),(3926,'2013-08-26','HXSAM','Weekly Cash - Mark','Cash:Regular',-30.00,'',1,0,0),(3927,'2013-08-27','FDMARK','<Credit Card BARCLAYCARD>','Work:Expenses',-362.90,'',1,0,0),(3928,'2013-08-27','FDMARK','Tesco','Food:Groceries',-137.72,'',1,0,0),(3929,'2013-08-27','RAINYDAY','<FDMARK>','Transfer',-415.00,'',1,0,0),(3930,'2013-08-27','FDMARK','<RAINYDAY>','Transfer',415.00,'',1,0,0),(3931,'2013-08-27','FDMARK','Aviva','Salary',3867.00,'',1,0,0),(3932,'2013-08-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',800.00,'',1,0,0),(3933,'2013-08-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-800.00,'',1,0,0),(3934,'2013-08-27','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(3935,'2013-08-27','FDMARK','<Credit Card HALIFAX MARK>','Transfer',-515.00,'',1,0,0),(3936,'2013-08-27','FDMARK','O2','Bills:Mobile Phones',-37.15,'Mark\'s iPhone ',1,0,0),(3937,'2013-08-27','FDMARK','Tesco Garage','Bills:Motor',-71.00,'BMW ',1,0,0),(3938,'2013-08-27','HXSAM','Love You Hair & Beauty','Beauty',-16.00,'',1,0,0),(3939,'2013-08-28','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3940,'2013-08-28','FDMARK','Pinn Insure Plc','Insurance',-7.47,'Cat insurance ',1,0,0),(3941,'2013-08-28','HXSAM','First/Keolis Trans','Bills:Transport',-29.70,'Train tix for NFL',1,0,0),(3942,'2013-08-28','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.99,'',1,0,0),(3943,'2013-08-28','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(3944,'2013-08-29','FDMARK','Tesco Garage','Bills:Motor',-28.23,'',1,0,0),(3945,'2013-08-30','HXSAM','Amazon','Entertainment:Hobbies',-85.90,'Mark\'s trainers',1,0,0),(3946,'2013-08-31','FORTHEFUTURE','First Direct','Interest',0.28,'',1,0,0),(3947,'2013-08-31','FORTHEFUTURE','First Direct','Interest',1.08,'',1,0,0),(3948,'2013-08-31','HXSAM','Selby College','Salary',652.44,'Sam salary',1,0,0),(3949,'2013-09-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(3950,'2013-09-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(3951,'2013-09-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(3952,'2013-09-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(3953,'2013-09-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(3954,'2013-09-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-151.00,'',1,0,0),(3955,'2013-09-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(3956,'2013-09-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(3957,'2013-09-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(3958,'2013-09-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(3959,'2013-09-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(3960,'2013-09-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(3961,'2013-09-01','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(3962,'2013-09-02','HXSAM','DW Fitness','Clothing',-62.38,'',1,0,0),(3963,'2013-09-02','HXSAM','Owl Hotel','Food:Dining',-56.02,'',1,0,0),(3964,'2013-09-02','FDMARK','Tesco','Food:Groceries',-157.65,'',1,0,0),(3965,'2013-09-02','FDMARK','Tesco Garage','Bills:Motor',-68.26,'Petrol - Golf',1,0,0),(3966,'2013-09-02','FDMARK','Jolleys Pet Food','Pets',-20.98,'',1,0,0),(3967,'2013-09-02','HXSAM','Weekly Cash - Mark','Cash:Regular',-40.00,'',1,0,0),(3968,'2013-09-02','HXSAM','Holmefield Vets','Pets',-20.99,'',1,0,0),(3969,'2013-09-02','HXSAM','Tesco','Food:Groceries',-29.00,'',1,0,0),(3970,'2013-09-02','HXSAM','Pets At Home','Pets',-7.65,'',1,0,0),(3971,'2013-09-02','HXSAM','McDonalds','Food:Dining',-9.95,'',1,0,0),(3972,'2013-09-02','HXSAM','B&M bargains','Food:Groceries',-20.44,'',1,0,0),(3973,'2013-09-02','HXSAM','Neulion/NFL','Hobbies',-34.99,'',1,0,0),(3974,'2013-09-03','FDMARK','Centerparcs','Entertainment:Holidays',-177.80,'Activities for cp',1,0,0),(3975,'2013-09-03','FDMARK','Centerparcs','Entertainment:Holidays',-268.80,'',1,0,0),(3976,'2013-09-04','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(3977,'2013-09-04','FDMARK','ParentPay','Food:School Dinners',-10.50,'',1,0,0),(3978,'2013-09-04','HXSAM','TSL Clothing','Clothing',-31.50,'',1,0,0),(3979,'2013-09-04','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(3980,'2013-09-04','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-38.92,'Minimum payment',1,0,0),(3981,'2013-09-04','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',38.92,'Minimum payment',1,0,0),(3982,'2013-09-04','FDMARK','Tesco Garage','Food:Groceries',-12.57,'',1,0,0),(3983,'2013-09-05','HXSAM','Paypal','Miscellaneous',-4.95,'',1,0,0),(3984,'2013-09-05','HXSAM','Paypal','Miscellaneous',-4.95,'',1,0,0),(3985,'2013-09-05','HXSAM','Paypal','Miscellaneous',-1.68,'',1,0,0),(3986,'2013-09-06','HXSAM','Tesco Garage','Food:Groceries',-9.29,'',1,0,0),(3987,'2013-09-06','FDMARK','Aviva Household','Bills:Insurance',-25.25,'',1,0,0),(3988,'2013-09-06','HXSAM','Weekly Cash - Sam','Cash:Regular',-40.00,'',1,0,0),(3989,'2013-09-08','FDMARK','O2','Bills:Mobile Phones',-21.99,'Sam\'s iPhone ',1,0,0),(3990,'2013-09-09','HXSAM','Tesco Garage','Food:Groceries',-23.69,'',1,0,0),(3991,'2013-09-09','HXSAM','Weatherills','Clothing:Sam',-25.00,'',1,0,0),(3992,'2013-09-09','HXSAM','Love You Hair & Beauty','Beauty',-19.00,'',1,0,0),(3993,'2013-09-09','HXSAM','Wilkinsons','Household',-8.48,'',1,0,0),(3994,'2013-09-09','HXSAM','Neulion/NFL','Hobbies',1.50,'',1,0,0),(3995,'2013-09-09','HXSAM','Amazon','Gifts',-18.02,'Game',1,0,0),(3996,'2013-09-09','HXSAM','Amazon','Gifts',-5.75,'SAMs book',1,0,0),(3997,'2013-09-09','HXSAM','Amazon','Gifts',-4.35,'Character',1,0,0),(3998,'2013-09-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(3999,'2013-09-09','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-16.77,'Minimum payment',1,0,0),(4000,'2013-09-09','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4001,'2013-09-10','FDMARK','Tesco','Food:Groceries',-107.26,'',1,0,0),(4002,'2013-09-10','HXSAM','Amazon','Gifts',-20.56,'Ukelele',1,0,0),(4003,'2013-09-10','HXSAM','Amazon','Entertainment:Hobbies',-67.49,'Sam\'s trainers',1,0,0),(4004,'2013-09-10','FDMARK','Morrisons','Food:Groceries',-13.49,'',1,0,0),(4005,'2013-09-10','FDMARK','Park & Ride','Bills:Transport',-25.00,'Bus monthly fee',1,0,0),(4006,'2013-09-10','FDMARK','ParentPay','Food:School Dinners',-31.50,'',1,0,0),(4007,'2013-09-10','FDMARK','Tesco Garage','Food:Groceries',-13.81,'',1,0,0),(4008,'2013-09-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(4009,'2013-09-10','HXSAM','Amazon','Gifts',-5.99,'',1,0,0),(4010,'2013-09-11','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4011,'2013-09-11','HXSAM','Amazon','Gifts',-62.20,'Aimee\'s birthday presents',1,0,0),(4012,'2013-09-11','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(4013,'2013-09-11','HXSAM','<RAINYDAY>','Transfer',220.00,'',1,0,0),(4014,'2013-09-11','RAINYDAY','<HXSAM>','Transfer',-220.00,'',1,0,0),(4015,'2013-09-12','FDMARK','Tesco Garage','Food:Groceries',-10.19,'',1,0,0),(4016,'2013-09-12','HXSAM','Paypal','Miscellaneous',-10.00,'',1,0,0),(4017,'2013-09-12','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.99,'',1,0,0),(4018,'2013-09-12','HXSAM','Cash','Cash',-30.00,'',1,0,0),(4019,'2013-09-12','FDMARK','BT','Bills:Utilities',-45.22,'House phone & broadband',1,0,0),(4020,'2013-09-12','HXSAM','Amazon','Gifts',-14.99,'Book',1,0,0),(4021,'2013-09-12','HXSAM','Amazon Marketplace','Entertainment',-219.95,'Freesat box',1,0,0),(4022,'2013-09-13','HXSAM','The Giant Bellflower','Food:Dining',-20.80,'',1,0,0),(4023,'2013-09-16','FDMARK','Tesco','Food:Groceries',-120.90,'',1,0,0),(4024,'2013-09-16','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-18.76,'',1,0,0),(4025,'2013-09-16','HXSAM','Paypal','Miscellaneous',-4.95,'',1,0,0),(4026,'2013-09-16','HXSAM','Paypal','Miscellaneous',-18.49,'',1,0,0),(4027,'2013-09-16','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(4028,'2013-09-16','HXSAM','Weekly Cash - Mark','Cash:Regular',-40.00,'',1,0,0),(4029,'2013-09-16','HXSAM','Sainsbury\'s','Food:Groceries',-16.98,'',1,0,0),(4030,'2013-09-17','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(4031,'2013-09-17','FDMARK','Market Lane Dental','Bills:Prescriptions',-18.00,'',1,0,0),(4032,'2013-09-17','HXSAM','Chelle\'s Dancing','Entertainment:Hobbies',-8.00,'',1,0,0),(4033,'2013-09-17','HXSAM','Paypal','Miscellaneous',-18.90,'Dancing shoes',1,0,0),(4034,'2013-09-17','HXSAM','Wh Smith','Books',-8.99,'',1,0,0),(4035,'2013-09-17','HXSAM','The Swan','Food:Dining',-9.35,'',1,0,0),(4036,'2013-09-17','HXSAM','The Swan','Food:Dining',-23.25,'',1,0,0),(4037,'2013-09-18','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4038,'2013-09-18','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4039,'2013-09-18','HXSAM','Paypal','Miscellaneous',-11.98,'',1,0,0),(4040,'2013-09-18','HXSAM','Paypal','Miscellaneous',-38.00,'',1,0,0),(4041,'2013-09-18','HXSAM','Hotel Chocolat','Gifts',-12.50,'',1,0,0),(4042,'2013-09-18','HXSAM','Apple ITunes','Entertainment:Hobbies',-14.97,'',1,0,0),(4043,'2013-09-18','HXSAM','ParentPay','Food:School Dinners',-4.00,'',1,0,0),(4044,'2013-09-18','HXSAM','Jolleys Pet Food','Pets',-17.98,'',1,0,0),(4045,'2013-09-18','HXSAM','Selby Library','Bills:Fines',-5.00,'',1,0,0),(4046,'2013-09-18','FDMARK','Home Bargains','Food:Groceries',-14.27,'',1,0,0),(4047,'2013-09-19','FDMARK','Lovefilm.com','Entertainment:Hobbies',-13.27,'',1,0,0),(4048,'2013-09-19','HXSAM','Classroom Clothing','Clothing',-18.00,'',1,0,0),(4049,'2013-09-19','HXSAM','Cash','Cash',-10.00,'',1,0,0),(4050,'2013-09-19','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-5.99,'',1,0,0),(4051,'2013-09-19','FDMARK','Tesco Garage','Food:Groceries',-8.73,'',1,0,0),(4052,'2013-09-23','HXSAM','Paypal','Other Income',60.00,'',1,0,0),(4053,'2013-09-23','HXSAM','Moss Bros','Clothing:Mark',-50.00,'',1,0,0),(4054,'2013-09-23','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4055,'2013-09-23','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4056,'2013-09-23','HXSAM','Holmefield Vets','Pets',-11.93,'',1,0,0),(4057,'2013-09-23','HXSAM','Banardos','Entertainment:Books',-5.97,'',1,0,0),(4058,'2013-09-23','HXSAM','Love You Hair & Beauty','Beauty',-17.50,'',1,0,0),(4059,'2013-09-23','FDMARK','Direct Debit - Camelot Group','Entertainment:Gambling',-2.00,'Lottery subscription',1,0,0),(4060,'2013-09-23','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(4061,'2013-09-24','HXSAM','Pizza Hut','Food:Dining',-14.95,'',1,0,0),(4062,'2013-09-24','HXSAM','Pret A Manger','Food',-5.00,'',1,0,0),(4063,'2013-09-24','HXSAM','Apple ITunes','Entertainment:Hobbies',-3.56,'',1,0,0),(4064,'2013-09-24','FDMARK','Tesco Garage','Food:Groceries',-12.10,'',1,0,0),(4065,'2013-09-24','FDMARK','Tesco','Food:Groceries',-126.02,'',1,0,0),(4066,'2013-09-24','HXSAM','Sky','Bills:TV',-58.24,'',1,0,0),(4067,'2013-09-25','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4068,'2013-09-25','NEXTCARD','Next','Clothing',-29.15,'',1,0,0),(4069,'2013-09-25','FDMARK','O2','Bills:Mobile Phones',-37.15,'Mark\'s iPhone ',1,0,0),(4070,'2013-09-25','HXSAM','ParentPay','Food:School Dinners',-4.00,'',1,0,0),(4071,'2013-09-26','FDMARK','Aviva Accounts Rec','Work:Expenses',430.99,'',1,0,0),(4072,'2013-09-26','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.79,'',1,0,0),(4073,'2013-09-27','FDMARK','Aviva','Salary',3867.00,'',1,0,0),(4074,'2013-09-27','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(4075,'2013-09-29','HXSAM','Cash','Cash',-70.00,'',1,0,0),(4076,'2013-09-29','HXSAM','Cash','Cash',-50.00,'',1,0,0),(4077,'2013-09-29','HXSAM','<FDMARK>','Transfer:Monthly Spends',800.00,'',1,0,0),(4078,'2013-09-29','FDMARK','<HXSAM>','Transfer:Monthly Spends',-800.00,'',1,0,0),(4079,'2013-09-30','FDMARK','<Credit Card BARCLAYCARD>','Transfer',-430.99,'',1,0,0),(4080,'2013-09-30','FDMARK','Tesco','Food:Groceries',-125.81,'',1,0,0),(4081,'2013-09-30','HXSAM','Cedar Court','Entertainment:Days Out',-65.00,'',1,0,0),(4082,'2013-09-30','HXSAM','Toby Carvery','Food:Dining',-16.83,'',1,0,0),(4083,'2013-09-30','HXSAM','Bags, Etc','Household',-35.00,'Suitcases',1,0,0),(4084,'2013-09-30','HXSAM','Moss Bros','Clothing:Mark',-7.00,'',1,0,0),(4085,'2013-09-30','HXSAM','Hunters','Beauty:Haircut',-27.00,'',1,0,0),(4086,'2013-09-30','HXSAM','Cash','Cash',-100.00,'',1,0,0),(4087,'2013-09-30','HXSAM','Flame Homeware','Household',-13.00,'Xmas noddies!!',1,0,0),(4088,'2013-09-30','HXSAM','Market Lane Dental','Bills:Prescriptions',-18.00,'',1,0,0),(4089,'2013-09-30','HXSAM','Holmefield Vets','Pets',-38.11,'',1,0,0),(4090,'2013-09-30','FDMARK','Market Lane Dental','Bills:Prescriptions',-31.00,'',1,0,0),(4091,'2013-09-30','FDMARK','Tesco Garage','Bills:Motor',-17.11,'',1,0,0),(4092,'2013-09-30','FORTHEFUTURE','First Direct','Interest',0.27,'',1,0,0),(4093,'2013-09-30','FORTHEFUTURE','First Direct','Interest',1.06,'',1,0,0),(4094,'2013-09-30','HXSAM','Selby College','Salary',694.31,'Sam salary',1,0,0),(4095,'2013-09-30','FDMARK','Tesco Garage','Bills:Motor',-54.56,'BMW ',1,0,0),(4096,'2013-09-30','FDMARK','Pinn Insure Plc','Insurance',-7.47,'Cat insurance ',1,0,0),(4097,'2013-10-01','FDMARK','DVLA','Bills:Motor',-140.00,'',1,0,0),(4098,'2013-10-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(4099,'2013-10-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(4100,'2013-10-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(4101,'2013-10-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(4102,'2013-10-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(4103,'2013-10-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-151.00,'',1,0,0),(4104,'2013-10-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(4105,'2013-10-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(4106,'2013-10-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(4107,'2013-10-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(4108,'2013-10-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(4109,'2013-10-01','HXSAM','Cheque','Miscellaneous',-23.00,'Aimee dancing stuff',1,0,0),(4110,'2013-10-01','HXSAM','Paypal','Other Income',75.00,'',1,0,0),(4111,'2013-10-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(4112,'2013-10-01','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(4113,'2013-10-02','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4114,'2013-10-03','FDMARK','ParentPay','Food:School Dinners',-42.00,'',1,0,0),(4115,'2013-10-03','HXSAM','Deposit','Cash',114.00,'',1,0,0),(4116,'2013-10-03','HXSAM','Apple ITunes','Entertainment:Hobbies',-3.99,'Mythbusters series 1',1,0,0),(4117,'2013-10-03','HXSAM','Neulion/NFL','Hobbies',-33.49,'',1,0,0),(4118,'2013-10-03','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.99,'',1,0,0),(4119,'2013-10-03','HXSAM','Amazon Marketplace','Entertainment',-1.47,'',1,0,0),(4120,'2013-10-03','HXSAM','Centerparcs','Entertainment:Holidays',-84.30,'Rachel\'s activities',1,0,0),(4121,'2013-10-04','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(4122,'2013-10-04','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-37.98,'Minimum payment',1,0,0),(4123,'2013-10-04','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',37.98,'Minimum payment',1,0,0),(4124,'2013-10-04','FDMARK','Tesco Garage','Food:Groceries',-17.47,'',1,0,0),(4125,'2013-10-04','HXSAM','Amazon Marketplace','Entertainment',-4.00,'',1,0,0),(4126,'2013-10-04','HXSAM','Amazon Marketplace','Entertainment',-14.44,'',1,0,0),(4127,'2013-10-04','HXSAM','New Look','Clothing:Sam',-16.00,'',1,0,0),(4128,'2013-10-04','HXSAM','Boots','Medical',-44.00,'',1,0,0),(4129,'2013-10-04','HXSAM','Weekly Cash - Mark','Cash:Regular',-40.00,'',1,0,0),(4130,'2013-10-05','HXSAM','<FDMARK>','Transfer',200.00,'',1,0,0),(4131,'2013-10-05','FDMARK','<HXSAM>','Transfer',-200.00,'',1,0,0),(4132,'2013-10-06','HXSAM','<Credit Card HALIFAX SAM>','',-100.00,'',1,0,0),(4133,'2013-10-07','FDMARK','Tesco','Food:Groceries',-121.59,'',1,0,0),(4134,'2013-10-07','HXSAM','Cheque','Miscellaneous',-67.00,'Cake',1,0,0),(4135,'2013-10-07','FDMARK','Park & Ride','Bills:Transport',-20.00,'Bus monthly fee',1,0,0),(4136,'2013-10-07','FDMARK','BT','Bills:Utilities',-48.12,'House phone & broadband',1,0,0),(4137,'2013-10-07','FDMARK','Aviva CS UK Ltd','Other Income',359.39,'',1,0,0),(4138,'2013-10-07','FDMARK','<Credit Card BARCLAYCARD>','Transfer',-374.39,'',1,0,0),(4139,'2013-10-07','HXSAM','Post Office Counters','Bills:Postage',-10.40,'',1,0,0),(4140,'2013-10-07','HXSAM','Wilkinsons','Household',-12.19,'',1,0,0),(4141,'2013-10-07','HXSAM','Gosober.org','Charity',-15.00,'',1,0,0),(4142,'2013-10-07','HXSAM','Dorothy Perkins','Clothing:Sam',-24.00,'',1,0,0),(4143,'2013-10-07','HXSAM','Home Bargains','Food:Groceries',-28.76,'',1,0,0),(4144,'2013-10-07','HXSAM','Dorothy Perkins','Clothing',-30.00,'',1,0,0),(4145,'2013-10-07','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(4146,'2013-10-08','HXSAM','<NEXTCARD>','',-100.00,'',1,0,0),(4147,'2013-10-08','NEXTCARD','<HXSAM>','',100.00,'',1,0,0),(4148,'2013-10-08','FDMARK','Aviva Household','Bills:Insurance',-25.25,'',1,0,0),(4149,'2013-10-09','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4150,'2013-10-09','HXSAM','Paypal','Miscellaneous',-3.24,'',1,0,0),(4151,'2013-10-09','HXSAM','Paypal','Gifts',-14.20,'',1,0,0),(4152,'2013-10-09','HXSAM','Jolleys Pet Food','Pets',-9.98,'',1,0,0),(4153,'2013-10-09','HXSAM','Holmefield Vets','Pets',-33.12,'',1,0,0),(4154,'2013-10-09','FDMARK','O2','Bills:Mobile Phones',-25.15,'Sam\'s iPhone ',1,0,0),(4155,'2013-10-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(4156,'2013-10-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(4157,'2013-10-11','HXSAM','B&M bargains','Food:Groceries',-11.74,'',1,0,0),(4158,'2013-10-11','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(4159,'2013-10-11','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-16.86,'Minimum payment',1,0,0),(4160,'2013-10-11','FDMARK','Morrisons','Food:Groceries',-26.44,'',1,0,0),(4161,'2013-10-11','HXSAM','Weekly Cash - Sam','Cash:Regular',-40.00,'',1,0,0),(4162,'2013-10-14','FDMARK','Tesco','Food:Groceries',-121.91,'',1,0,0),(4163,'2013-10-14','FDMARK','Tesco Garage','Bills:Motor',-50.01,'Petrol - Golf',1,0,0),(4164,'2013-10-14','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(4165,'2013-10-14','FDMARK','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-250.00,'Repay Xmas Presents',1,0,0),(4166,'2013-10-14','HXSAM','National Lottery','Other Income',25.00,'',1,0,0),(4167,'2013-10-14','HXSAM','Sainsbury\'s','Food:Groceries',-12.49,'',1,0,0),(4168,'2013-10-15','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-19.02,'',1,0,0),(4169,'2013-10-15','HXSAM','Amazon Marketplace','Entertainment',-7.89,'',1,0,0),(4170,'2013-10-15','HXSAM','Amazon Marketplace','Entertainment',-5.67,'HDMI stuff',1,0,0),(4171,'2013-10-16','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4172,'2013-10-16','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(4173,'2013-10-16','FDMARK','Wilkinsons','Household',-16.95,'',1,0,0),(4174,'2013-10-16','FDMARK','Sainsbury\'s','Food:Groceries',-10.00,'',1,0,0),(4175,'2013-10-16','HXSAM','Paypal','Gifts',-4.15,'',1,0,0),(4176,'2013-10-16','HXSAM','Paypal','Gifts',-13.33,'',1,0,0),(4177,'2013-10-17','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(4178,'2013-10-17','FDMARK','Tesco Garage','Food:Groceries',-4.15,'',1,0,0),(4179,'2013-10-17','HXSAM','EE & T-Mobile','Bills:Mobile Phones',-10.00,'',1,0,0),(4180,'2013-10-17','HXSAM','Weekly Cash - Mark','Cash:Regular',-40.00,'',1,0,0),(4181,'2013-10-18','HXSAM','Home Bargains','Food:Groceries',-40.98,'',1,0,0),(4182,'2013-10-19','FDMARK','Cash','Cash',-20.00,'',1,0,0),(4183,'2013-10-21','FDMARK','Tesco','Food:Groceries',-102.07,'',1,0,0),(4184,'2013-10-21','FDMARK','Lovefilm.com','Entertainment:Hobbies',-13.27,'',1,0,0),(4185,'2013-10-21','FDMARK','Boots','Medical',-5.97,'',1,0,0),(4186,'2013-10-21','FDMARK','Toys R Us','Gifts',-26.48,'',1,0,0),(4187,'2013-10-21','FDMARK','Tesco Garage','Food:Groceries',-12.80,'',1,0,0),(4188,'2013-10-21','FDMARK','Tesco Garage','Food:Groceries',-14.69,'',1,0,0),(4189,'2013-10-21','HXSAM','Cash','Cash',-30.00,'',1,0,0),(4190,'2013-10-21','FDMARK','Tesco Garage','Bills:Motor',-65.35,'',1,0,0),(4191,'2013-10-22','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.89,'',1,0,0),(4192,'2013-10-23','FDMARK','Aviva CS UK Ltd','Work:Expenses',97.30,'',1,0,0),(4193,'2013-10-23','FDMARK','<Credit Card BARCLAYCARD>','Work:Expenses',-100.30,'',1,0,0),(4194,'2013-10-24','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4195,'2013-10-24','HXSAM','Paypal','Gifts',-5.59,'',1,0,0),(4196,'2013-10-24','HXSAM','Amazon Marketplace','Entertainment',-18.13,'',1,0,0),(4197,'2013-10-25','FDMARK','Aviva','Salary',3867.00,'',1,0,0),(4198,'2013-10-25','NEXTCARD','Next','Clothing',-337.76,'',1,0,0),(4199,'2013-10-25','FDMARK','Morrisons','Food:Groceries',-22.40,'',1,0,0),(4200,'2013-10-26','HXSAM','<FDMARK>','Transfer:Monthly Spends',800.00,'',1,0,0),(4201,'2013-10-26','FDMARK','<HXSAM>','Transfer:Monthly Spends',-800.00,'',1,0,0),(4202,'2013-10-26','FDMARK','O2','Bills:Mobile Phones',-37.15,'Mark\'s iPhone ',1,0,0),(4203,'2013-10-28','FDMARK','Morrisons','Food:Groceries',-121.72,'',1,0,0),(4204,'2013-10-28','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(4205,'2013-10-28','HXSAM','Amazon','Household',-79.99,'Apple TV',1,0,0),(4206,'2013-10-28','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4207,'2013-10-28','HXSAM','Apple ITunes','Entertainment:Hobbies',-5.48,'',1,0,0),(4208,'2013-10-28','HXSAM','Card Factory','Gifts',-5.95,'',1,0,0),(4209,'2013-10-28','HXSAM','Amazon Marketplace','Entertainment',-11.98,'',1,0,0),(4210,'2013-10-28','HXSAM','Tesco Garage','Food:Groceries',-13.90,'',1,0,0),(4211,'2013-10-28','HXSAM','Home Bargains','Food:Groceries',-26.27,'',1,0,0),(4212,'2013-10-28','HXSAM','Brantano','Clothing:Kids',-39.00,'',1,0,0),(4213,'2013-10-28','FDMARK','Pinn Insure Plc','Insurance',-7.47,'Cat insurance ',1,0,0),(4214,'2013-10-28','HXSAM','Frankie & Benny\'s','Cash:Regular',-55.60,'',1,0,0),(4215,'2013-10-29','FDMARK','Park & Ride','Bills:Transport',-40.00,'Bus monthly fee',1,0,0),(4216,'2013-10-29','HXSAM','Gap','Clothing',-57.63,'',1,0,0),(4217,'2013-10-29','HXSAM','Cheque','Miscellaneous',-16.00,'Aimee dancing',1,0,0),(4218,'2013-10-29','HXSAM','Homebase','Household',-22.60,'',1,0,0),(4219,'2013-10-29','HXSAM','Amazon Marketplace','Entertainment',-11.24,'',1,0,0),(4220,'2013-10-29','HXSAM','Amazon Marketplace','Entertainment',-28.00,'',1,0,0),(4221,'2013-10-30','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4222,'2013-10-31','FORTHEFUTURE','First Direct','Interest',0.29,'',1,0,0),(4223,'2013-10-31','FORTHEFUTURE','First Direct','Interest',1.12,'',1,0,0),(4224,'2013-10-31','FDMARK','Tesco Garage','Bills:Motor',-74.76,'Petrol - Golf',1,0,0),(4225,'2013-10-31','HXSAM','Sainsbury\'s','Food:Groceries',-29.42,'',1,0,0),(4226,'2013-10-31','HXSAM','Selby College','Salary',718.31,'Sam salary',1,0,0),(4227,'2013-11-01','HXSAM','Cash','Cash',-40.00,'Sam night out',1,0,0),(4228,'2013-11-01','HXSAM','Apple ITunes','Entertainment:Hobbies',-16.99,'Mythbusters series 2',1,0,0),(4229,'2013-11-01','HXSAM','McDonalds','Food:Dining',-20.91,'',1,0,0),(4230,'2013-11-01','HXSAM','Halifax','Overdraft fee',-5.00,'',1,0,0),(4231,'2013-11-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(4232,'2013-11-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(4233,'2013-11-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(4234,'2013-11-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(4235,'2013-11-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(4236,'2013-11-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-151.00,'',1,0,0),(4237,'2013-11-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.18,'',1,0,0),(4238,'2013-11-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(4239,'2013-11-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(4240,'2013-11-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(4241,'2013-11-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(4242,'2013-11-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(4243,'2013-11-01','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(4244,'2013-11-02','HXSAM','<Credit Card HALIFAX MARK>','Transfer',-50.00,'Pay for trainers',1,0,0),(4245,'2013-11-03','HXSAM','Sainsbury\'s','Food:Groceries',1.50,'',1,0,0),(4246,'2013-11-03','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-56.79,'Minimum payment',1,0,0),(4247,'2013-11-03','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',56.79,'Minimum payment',1,0,0),(4248,'2013-11-04','HXSAM','Cineworld','Entertainment:Days Out',-6.30,'',1,0,0),(4249,'2013-11-04','HXSAM','Pizza Express','Food:Dining',-12.45,'',1,0,0),(4250,'2013-11-04','FDMARK','Tesco','Food:Groceries',-130.46,'',1,0,0),(4251,'2013-11-04','HXSAM','Tesco','Food:Groceries',-17.16,'',1,0,0),(4252,'2013-11-04','HXSAM','The Swan','Food:Dining',-34.35,'',1,0,0),(4253,'2013-11-04','HXSAM','Neulion/NFL','Hobbies',-33.49,'',1,0,0),(4254,'2013-11-04','HXSAM','Amazon Marketplace','Gifts',-23.98,'',1,0,0),(4255,'2013-11-04','HXSAM','Flyers Group','Clothing',-28.00,'',1,0,0),(4256,'2013-11-04','HXSAM','Marks & Spencer','Clothing',-30.30,'',1,0,0),(4257,'2013-11-04','HXSAM','Gap','Clothing',-146.58,'',1,0,0),(4258,'2013-11-04','HXSAM','Starbucks','Food:Dining',-11.20,'',1,0,0),(4259,'2013-11-04','FDMARK','Tesco Direct','Gifts',-10.00,'',1,0,0),(4260,'2013-11-04','FDMARK','Tesco Direct','Gifts',-3.00,'',1,0,0),(4261,'2013-11-05','FDMARK','ParentPay','Food:School Dinners',-31.50,'',1,0,0),(4262,'2013-11-06','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4263,'2013-11-06','HXSAM','Paypal','Hobbies',-4.95,'',1,0,0),(4264,'2013-11-06','HXSAM','Paypal','Hobbies',-4.95,'',1,0,0),(4265,'2013-11-06','HXSAM','Paypal','Hobbies',-18.09,'',1,0,0),(4266,'2013-11-06','HXSAM','Amazon EU','Gifts',-59.99,'',1,0,0),(4267,'2013-11-06','HXSAM','<FDMARK>','Transfer',60.00,'',1,0,0),(4268,'2013-11-06','FDMARK','<HXSAM>','Transfer',-60.00,'',1,0,0),(4269,'2013-11-06','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(4270,'2013-11-06','FDMARK','Aviva Household','Bills:Insurance',-25.13,'',1,0,0),(4271,'2013-11-06','FDMARK','BT','Bills:Utilities',-41.68,'House phone & broadband',1,0,0),(4272,'2013-11-06','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(4273,'2013-11-07','FDMARK','Home Bargains','Food:Groceries',-21.22,'',1,0,0),(4274,'2013-11-07','FDMARK','Tesco Garage','Food:Groceries',-15.23,'',1,0,0),(4275,'2013-11-07','FDMARK','B&M bargains','Food:Groceries',-7.14,'',1,0,0),(4276,'2013-11-07','HXSAM','Paypal','Clothing',-17.49,'',1,0,0),(4277,'2013-11-07','HXSAM','Paypal','Hobbies',-19.49,'Children in need',1,0,0),(4278,'2013-11-08','FDMARK','Home Bargains','Food:Groceries',-20.84,'',1,0,0),(4279,'2013-11-08','FDMARK','Amazon EU','Gifts',-29.99,'',1,0,0),(4280,'2013-11-08','FDMARK','O2','Bills:Mobile Phones',-33.20,'Sam\'s iPhone ',1,0,0),(4281,'2013-11-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(4282,'2013-11-11','FDMARK','Tesco','Food:Groceries',-148.07,'',1,0,0),(4283,'2013-11-11','HXSAM','Hunters','Beauty:Haircut',-58.80,'',1,0,0),(4284,'2013-11-11','HXSAM','Dorothy Perkins','Clothing',-38.10,'',1,0,0),(4285,'2013-11-11','HXSAM','Dorothy Perkins','Clothing',-22.00,'',1,0,0),(4286,'2013-11-11','HXSAM','Boots','Gifts',-54.96,'',1,0,0),(4287,'2013-11-11','FDMARK','Amazon EU','Gifts',-9.99,'',1,0,0),(4288,'2013-11-11','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(4289,'2013-11-11','HXSAM','Samaritans Purse','Gifts',-6.00,'',1,0,0),(4290,'2013-11-11','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(4291,'2013-11-11','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-16.32,'Minimum payment',1,0,0),(4292,'2013-11-11','FDMARK','Tesco Garage','Bills:Motor',-75.72,'BMW ',1,0,0),(4293,'2013-11-11','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4294,'2013-11-12','HXSAM','Amazon EU','Gifts',-44.52,'',1,0,0),(4295,'2013-11-12','HXSAM','<FDMARK>','Transfer',80.00,'',1,0,0),(4296,'2013-11-12','FDMARK','<HXSAM>','Transfer',-80.00,'',1,0,0),(4297,'2013-11-13','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4298,'2013-11-13','FDMARK','Amazon EU','Gifts',-60.10,'',1,0,0),(4299,'2013-11-13','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.89,'Tv show',1,0,0),(4300,'2013-11-13','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-2.99,'',1,0,0),(4301,'2013-11-13','HXSAM','Sainsbury\'s','Food:Groceries',-34.97,'',1,0,0),(4302,'2013-11-14','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(4303,'2013-11-14','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(4304,'2013-11-14','HXSAM','Tesco Garage','Food:Groceries',-10.05,'',1,0,0),(4305,'2013-11-15','FDMARK','Tesco','Food:Groceries',-124.33,'',1,0,0),(4306,'2013-11-15','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-20.41,'',1,0,0),(4307,'2013-11-15','HXSAM','Centerparcs','Entertainment:Holidays',30.00,'',1,0,0),(4308,'2013-11-15','HXSAM','Centerparcs','Entertainment:Holidays',-16.50,'',1,0,0),(4309,'2013-11-15','FDMARK','The Works','Gifts',-10.00,'Book',1,0,0),(4310,'2013-11-15','HXSAM','Weekly Cash - Mark','Cash:Regular',-40.00,'',1,0,0),(4311,'2013-11-17','FDMARK','Cash','Cash',-50.00,'',1,0,0),(4312,'2013-11-18','FDMARK','Centerparcs','Entertainment:Holidays',-40.03,'',1,0,0),(4313,'2013-11-18','FDMARK','Tesco','Food:Groceries',-8.03,'',1,0,0),(4314,'2013-11-18','FDMARK','Centerparcs SF','Entertainment:Holidays',-35.00,'',1,0,0),(4315,'2013-11-18','FDMARK','Centerparcs Ecom','Entertainment:Holidays',-35.00,'',1,0,0),(4316,'2013-11-18','FDMARK','Strada Sherwood','Entertainment:Holidays',-34.82,'',1,0,0),(4317,'2013-11-18','HXSAM','Nuance Group Uk','Entertainment:Holidays',-22.99,'',1,0,0),(4318,'2013-11-18','HXSAM','Nuance Group Uk','Entertainment:Holidays',-25.98,'',1,0,0),(4319,'2013-11-18','HXSAM','Centerparcs Sherw','Entertainment:Holidays',-49.00,'',1,0,0),(4320,'2013-11-18','HXSAM','Centerparcs Sherw','Entertainment:Holidays',-7.64,'',1,0,0),(4321,'2013-11-19','HXSAM','Catnaps','Entertainment:Holidays',-32.00,'Cattery',1,0,0),(4322,'2013-11-19','HXSAM','Cheque','Miscellaneous',-48.00,'Dancing show tickets',1,0,0),(4323,'2013-11-19','FDMARK','Lovefilm.com','Entertainment:Hobbies',-13.27,'',1,0,0),(4324,'2013-11-19','FDMARK','Foresters','Entertainment:Holidays',-30.80,'',1,0,0),(4325,'2013-11-19','FDMARK','Tesco Garage','Food:Groceries',-7.04,'',1,0,0),(4326,'2013-11-19','HXSAM','Paypal','Hobbies',-5.40,'',1,0,0),(4327,'2013-11-19','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4328,'2013-11-20','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4329,'2013-11-20','FDMARK','Aldi','Food:Groceries',-12.57,'',1,0,0),(4330,'2013-11-20','HXSAM','Paypal','Hobbies',-14.20,'',1,0,0),(4331,'2013-11-20','HXSAM','Apple ITunes','Entertainment:Hobbies',-3.38,'',1,0,0),(4332,'2013-11-20','HXSAM','Paypal','Hobbies',-8.00,'',1,0,0),(4333,'2013-11-20','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(4334,'2013-11-21','HXSAM','Home Bargains','Food:Groceries',-35.00,'',1,0,0),(4335,'2013-11-22','HXSAM','Paypal','Hobbies',-6.98,'',1,0,0),(4336,'2013-11-23','HXSAM','Amazon','Entertainment:Hobbies',-9.49,'',1,0,0),(4337,'2013-11-25','FDMARK','Tesco','Food:Groceries',-114.65,'',1,0,0),(4338,'2013-11-25','NEXTCARD','Next','Clothing',-58.77,'',1,0,0),(4339,'2013-11-25','FDMARK','O2','Bills:Mobile Phones',-39.36,'Mark\'s iPhone ',1,0,0),(4340,'2013-11-25','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4341,'2013-11-25','HXSAM','Heaven & Home','Household',-9.58,'',1,0,0),(4342,'2013-11-25','HXSAM','Sainsbury\'s','Food:Groceries',-14.49,'',1,0,0),(4343,'2013-11-25','HXSAM','Love You Hair & Beauty','Beauty',-20.00,'',1,0,0),(4344,'2013-11-25','HXSAM','<FDMARK>','Transfer',40.00,'',1,0,0),(4345,'2013-11-25','FDMARK','<HXSAM>','Transfer',-40.00,'',1,0,0),(4346,'2013-11-27','FDMARK','Aviva','Salary',3867.00,'',1,0,0),(4347,'2013-11-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',800.00,'',1,0,0),(4348,'2013-11-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-800.00,'',1,0,0),(4349,'2013-11-27','HXSAM','DGS/RPP DD','Bills:Insurance',-10.59,'',1,0,0),(4350,'2013-11-27','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-6.64,'',1,0,0),(4351,'2013-11-27','HXSAM','ParentPay','Entertainment:Days Out',-8.00,'',1,0,0),(4352,'2013-11-28','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4353,'2013-11-28','HXSAM','Wallis','Clothing:Sam',-24.00,'',1,0,0),(4354,'2013-11-28','HXSAM','Dorothy Perkins','Clothing:Sam',-21.00,'',1,0,0),(4355,'2013-11-28','FDMARK','Tesco','Food:Groceries',-17.04,'',1,0,0),(4356,'2013-11-28','FDMARK','Amazon','Gifts',-11.60,'',1,0,0),(4357,'2013-11-28','FDMARK','Pinn Insure Plc','Insurance',-7.47,'Cat insurance ',1,0,0),(4358,'2013-11-29','FDMARK','Home Bargains','Food:Groceries',-15.20,'',1,0,0),(4359,'2013-11-29','FDMARK','Selby Garden Center','Household',-134.93,'',1,0,0),(4360,'2013-11-29','FDMARK','Tesco Garage','Food:Groceries',-5.57,'',1,0,0),(4361,'2013-11-29','HXSAM','Paypal','Hobbies',-56.99,'',1,0,0),(4362,'2013-11-29','HXSAM','Selby College','Salary',870.37,'Sam salary',1,0,0),(4363,'2013-11-29','HXSAM','Weekly Cash - Sam','Cash:Regular',-40.00,'',1,0,0),(4364,'2013-11-30','FORTHEFUTURE','First Direct','Interest',0.28,'',1,0,0),(4365,'2013-11-30','FORTHEFUTURE','First Direct','Interest',1.10,'',1,0,0),(4366,'2013-12-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(4367,'2013-12-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(4368,'2013-12-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(4369,'2013-12-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(4370,'2013-12-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(4371,'2013-12-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-151.00,'',1,0,0),(4372,'2013-12-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(4373,'2013-12-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(4374,'2013-12-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(4375,'2013-12-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(4376,'2013-12-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(4377,'2013-12-01','FDMARK','Tesco Garage','Bills:Motor',-66.16,'BMW ',1,0,0),(4378,'2013-12-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(4379,'2013-12-01','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(4380,'2013-12-02','FDMARK','Tesco','Food:Groceries',-118.80,'',1,0,0),(4381,'2013-12-02','HXSAM','Cash','Cash',-10.00,'',1,0,0),(4382,'2013-12-02','HXSAM','Paypal','Hobbies',-28.99,'Throw for bed ',1,0,0),(4383,'2013-12-02','FDMARK','B&M bargains','Household',-37.85,'',1,0,0),(4384,'2013-12-02','HXSAM','Amazon','Gifts',-9.99,'',1,0,0),(4385,'2013-12-02','HXSAM','Hunters','Beauty:Haircut',-15.00,'',1,0,0),(4386,'2013-12-02','HXSAM','Argos','Gifts',-19.98,'',1,0,0),(4387,'2013-12-02','HXSAM','Debenhams','Other Income:Refunds',-5.60,'',1,0,0),(4388,'2013-12-02','HXSAM','The Works','Gifts',-11.97,'',1,0,0),(4389,'2013-12-02','FDMARK','Tesco Garage','Bills:Motor',-78.63,'Petrol - Golf',1,0,0),(4390,'2013-12-02','HXSAM','Weekly Cash - Mark','Cash:Regular',-30.00,'',1,0,0),(4391,'2013-12-02','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4392,'2013-12-02','FDMARK','John Greed Jewellery','Gifts',-80.00,'',1,0,0),(4393,'2013-12-02','FDMARK','Amazon','Gifts',-12.95,'',1,0,0),(4394,'2013-12-03','FDMARK','ParentPay','Food:School Dinners',-31.50,'',1,0,0),(4395,'2013-12-03','FDMARK','Pets At Home','Pets',-6.00,'',1,0,0),(4396,'2013-12-03','HXSAM','B&M bargains','Household',-8.98,'',1,0,0),(4397,'2013-12-03','HXSAM','New Look','Clothing',-17.99,'',1,0,0),(4398,'2013-12-03','HXSAM','Primark','Clothing',-14.00,'',1,0,0),(4399,'2013-12-03','HXSAM','Wh Smith','Books',-8.98,'',1,0,0),(4400,'2013-12-04','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4401,'2013-12-04','FDMARK','Amazon','Gifts',-48.64,'',1,0,0),(4402,'2013-12-04','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(4403,'2013-12-04','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-56.95,'Minimum payment',1,0,0),(4404,'2013-12-04','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',56.95,'Minimum payment',1,0,0),(4405,'2013-12-04','FDMARK','Sainsbury\'s','Food:Groceries',-20.52,'',1,0,0),(4406,'2013-12-04','HXSAM','Jolleys Pet Food','Pets',-9.48,'',1,0,0),(4407,'2013-12-04','HXSAM','Wilkinsons','Household',-13.10,'',1,0,0),(4408,'2013-12-05','HXSAM','Paypal','Hobbies',-4.30,'',1,0,0),(4409,'2013-12-05','HXSAM','Paypal','Hobbies',-5.50,'',1,0,0),(4410,'2013-12-05','HXSAM','Amazon Marketplace','Gifts',-5.98,'',1,0,0),(4411,'2013-12-05','HXSAM','Amazon Marketplace','Gifts',-6.11,'',1,0,0),(4412,'2013-12-05','HXSAM','Tesco Garage','Food:Groceries',-11.50,'',1,0,0),(4413,'2013-12-05','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(4414,'2013-12-05','FDMARK','BT','Bills:Utilities',-43.03,'House phone & broadband',1,0,0),(4415,'2013-12-06','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4416,'2013-12-06','HXSAM','Amazon Marketplace','Gifts',-40.08,'',1,0,0),(4417,'2013-12-06','HXSAM','Love You Hair & Beauty','Beauty',-31.50,'',1,0,0),(4418,'2013-12-06','HXSAM','Tempest Photos','Entertainment',-61.50,'',1,0,0),(4419,'2013-12-06','HXSAM','<FDMARK>','Transfer',40.00,'',1,0,0),(4420,'2013-12-06','FDMARK','<HXSAM>','Transfer',-40.00,'',1,0,0),(4421,'2013-12-07','HXSAM','Cash','Cash',-50.00,'Cash for London trip',1,0,0),(4422,'2013-12-09','FDMARK','Tesco','Food:Groceries',-119.87,'',1,0,0),(4423,'2013-12-09','HXSAM','Paypal','Other Income:Refunds',21.99,'',1,0,0),(4424,'2013-12-09','HXSAM','Amazon Marketplace','Gifts',-14.98,'Bike lights',1,0,0),(4425,'2013-12-09','FDMARK','O2','Bills:Mobile Phones',-30.94,'Sam\'s iPhone ',1,0,0),(4426,'2013-12-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(4427,'2013-12-09','HXSAM','Amazon Marketplace','Gifts',-6.13,'',1,0,0),(4428,'2013-12-09','HXSAM','Amazon Marketplace','Gifts',-8.00,'',1,0,0),(4429,'2013-12-09','HXSAM','Harrods','Household',-13.90,'',1,0,0),(4430,'2013-12-09','HXSAM','Science Museum','Entertainment:Days Out',-16.00,'',1,0,0),(4431,'2013-12-09','HXSAM','Amazon','Gifts',-122.05,'',1,0,0),(4432,'2013-12-09','HXSAM','Jolleys Pet Food','Pets',-25.98,'',1,0,0),(4433,'2013-12-09','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4434,'2013-12-10','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-20.50,'Minimum payment',1,0,0),(4435,'2013-12-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(4436,'2013-12-11','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4437,'2013-12-11','HXSAM','Cash','Cash',-40.00,'Mark Xmas do #1',1,0,0),(4438,'2013-12-11','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(4439,'2013-12-11','FDMARK','Morrisons','Food:Groceries',-20.60,'',1,0,0),(4440,'2013-12-11','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.89,'',1,0,0),(4441,'2013-12-11','HXSAM','Alexanders','Gifts',-10.97,'',1,0,0),(4442,'2013-12-11','HXSAM','Amazon','Gifts',-12.68,'',1,0,0),(4443,'2013-12-11','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(4444,'2013-12-12','HXSAM','Paypal','Clothing:Kids',-12.00,'',1,0,0),(4445,'2013-12-12','HXSAM','Amazon','Gifts',-6.75,'',1,0,0),(4446,'2013-12-12','HXSAM','Amazon','Gifts',-14.04,'',1,0,0),(4447,'2013-12-12','FDMARK','Int\'l ','Miscellaneous',-10.00,'',1,0,0),(4448,'2013-12-13','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4449,'2013-12-16','FDMARK','Tesco','Food:Groceries',-131.44,'',1,0,0),(4450,'2013-12-16','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-20.66,'',1,0,0),(4451,'2013-12-16','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4452,'2013-12-16','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4453,'2013-12-16','HXSAM','Pylones','Gifts',-9.90,'',1,0,0),(4454,'2013-12-16','HXSAM','Hawkins Bazaar','Gifts',-11.49,'',1,0,0),(4455,'2013-12-16','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(4456,'2013-12-16','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(4457,'2013-12-16','FDMARK','Tesco Garage','Food:Groceries',-21.48,'',1,0,0),(4458,'2013-12-16','HXSAM','White Wholesale Lt','Miscellaneous',-10.00,'',1,0,0),(4459,'2013-12-16','HXSAM','Vom Fass Concessio','Gifts',-15.00,'',1,0,0),(4460,'2013-12-16','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4461,'2013-12-17','HXSAM','Pizza Hut','Food:Dining',-32.63,'',1,0,0),(4462,'2013-12-17','FDMARK','Wh Smith','Books',-7.18,'',1,0,0),(4463,'2013-12-17','HXSAM','Hmv','Gifts',-20.00,'',1,0,0),(4464,'2013-12-17','HXSAM','Who Internet','Other Income:Winnings',130.00,'',1,0,0),(4465,'2013-12-17','HXSAM','Hotel Chocolat','Gifts',-28.00,'',1,0,0),(4466,'2013-12-17','HXSAM','Who Internet','Entertainment:Books',-10.00,'',1,0,0),(4467,'2013-12-17','HXSAM','Amazon Marketplace','Gifts',-10.29,'',1,0,0),(4468,'2013-12-18','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4469,'2013-12-18','HXSAM','Paypal','Miscellaneous',-27.00,'',1,0,0),(4470,'2013-12-18','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-0.77,'',1,0,0),(4471,'2013-12-19','FDMARK','Tesco Garage','Food:Groceries',-16.18,'',1,0,0),(4472,'2013-12-19','FDMARK','Tesco Garage','Food:Groceries',-12.98,'',1,0,0),(4473,'2013-12-19','FDMARK','B&M bargains','Household',-19.99,'',1,0,0),(4474,'2013-12-19','FDMARK','TheTrainLine.com','Miscellaneous',-14.80,'',1,0,0),(4475,'2013-12-19','HXSAM','Paypal','Miscellaneous',-4.91,'',1,0,0),(4476,'2013-12-19','HXSAM','Paypal','Miscellaneous',-6.97,'',1,0,0),(4477,'2013-12-19','FDMARK','Lovefilm.com','Entertainment:Hobbies',-13.27,'',1,0,0),(4478,'2013-12-20','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4479,'2013-12-20','HXSAM','Amazon Marketplace','Gifts',-9.29,'',1,0,0),(4480,'2013-12-20','HXSAM','McDonalds','Food:Dining',-12.85,'',1,0,0),(4481,'2013-12-20','HXSAM','Wh Smith','Books',-21.40,'',1,0,0),(4482,'2013-12-20','HXSAM','Amazon Marketplace','Gifts',-22.46,'',1,0,0),(4483,'2013-12-20','HXSAM','Selby College','Salary',608.76,'Sam salary',1,0,0),(4484,'2013-12-21','HXSAM','<Credit Card HALIFAX MARK>','Transfer',-230.00,'',1,0,0),(4485,'2013-12-23','HXSAM','B&M bargains','Household',-8.45,'',1,0,0),(4486,'2013-12-23','FDMARK','Aviva','Salary',3867.00,'',1,0,0),(4487,'2013-12-23','HXSAM','<FDMARK>','Transfer:Monthly Spends',800.00,'',1,0,0),(4488,'2013-12-23','FDMARK','<HXSAM>','Transfer:Monthly Spends',-800.00,'',1,0,0),(4489,'2013-12-23','HXSAM','Cineworld','Entertainment:Days Out',-31.03,'',1,0,0),(4490,'2013-12-23','HXSAM','Hunters','Beauty:Haircut',-27.00,'',1,0,0),(4491,'2013-12-23','HXSAM','Love You Hair & Beauty','Beauty',-16.00,'',1,0,0),(4492,'2013-12-23','HXSAM','Weekly Cash - Mark','Cash:Regular',-30.00,'',1,0,0),(4493,'2013-12-24','FDMARK','Tesco','Food:Groceries',-120.57,'',1,0,0),(4494,'2013-12-24','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4495,'2013-12-24','FDMARK','Tesco ','Food:Groceries',-58.13,'',1,0,0),(4496,'2013-12-24','HXSAM','Jolleys Pet Food','Pets',-17.99,'',1,0,0),(4497,'2013-12-25','NEXTCARD','Next','Clothing',-165.59,'',1,0,0),(4498,'2013-12-27','HXSAM','DGS/RPP DD','Bills:Insurance',-11.59,'',1,0,0),(4499,'2013-12-27','HXSAM','National Lottery','Entertainment:Lottery',-12.00,'',1,0,0),(4500,'2013-12-27','HXSAM','Homebase','Gifts',-46.57,'Present for Madge & basket for jean ',1,0,0),(4501,'2013-12-27','FDMARK','O2','Bills:Mobile Phones',-37.35,'Mark\'s iPhone ',1,0,0),(4502,'2013-12-28','FDMARK','Pinn Insure Plc','Insurance',-7.47,'Cat insurance ',1,0,0),(4503,'2013-12-30','FDMARK','Tesco','Food:Groceries',-117.41,'',1,0,0),(4504,'2013-12-30','HXSAM','Amazon','Entertainment',-12.08,'Mud guards',1,0,0),(4505,'2013-12-30','HXSAM','National Lottery','Other Income',25.00,'',1,0,0),(4506,'2013-12-30','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-1.99,'',1,0,0),(4507,'2013-12-30','HXSAM','Amazon','Entertainment',-27.44,'',1,0,0),(4508,'2013-12-31','FORTHEFUTURE','First Direct','Interest',0.30,'',1,0,0),(4509,'2013-12-31','FORTHEFUTURE','First Direct','Interest',1.15,'',1,0,0),(4510,'2013-12-31','HXSAM','Amazon','Entertainment',-136.60,'Watch, jacket, DVDs, kindle case',1,0,0),(4511,'2013-12-31','HXSAM','The Outlet Brotherton','Miscellaneous',-9.16,'',1,0,0),(4512,'2013-12-31','HXSAM','Amazon','Entertainment',-11.09,'',1,0,0),(4513,'2013-12-31','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4514,'2014-01-01','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4515,'2014-01-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(4516,'2014-01-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(4517,'2014-01-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(4518,'2014-01-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(4519,'2014-01-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-151.00,'',1,0,0),(4520,'2014-01-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(4521,'2014-01-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(4522,'2014-01-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(4523,'2014-01-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(4524,'2014-01-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(4525,'2014-01-01','HXSAM','DGS/RPP DD','Bills:Insurance',-5.28,'Dishwasher cover',1,0,0),(4526,'2014-01-01','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(4527,'2014-01-02','FDMARK','Aviva CS UK Ltd','Other Income',256.00,'',1,0,0),(4528,'2014-01-02','HXSAM','Thai Sushine','Food:Dining',-4.80,'',1,0,0),(4529,'2014-01-02','HXSAM','Thai Sushine','Food:Dining',-55.40,'',1,0,0),(4530,'2014-01-02','FDMARK','Tesco Garage','Bills:Motor',-71.38,'BMW ',1,0,0),(4531,'2014-01-03','HXSAM','Boots','Other Income',27.00,'',1,0,0),(4532,'2014-01-03','HXSAM','Greenthumb','Garden',-32.00,'',1,0,0),(4533,'2014-01-03','HXSAM','Wh Smith','Books',-15.70,'',1,0,0),(4534,'2014-01-03','HXSAM','New Look','Clothing',-19.99,'',1,0,0),(4535,'2014-01-03','HXSAM','Boots','Medical',-24.50,'',1,0,0),(4536,'2014-01-03','HXSAM','Argos','Gifts',-38.98,'',1,0,0),(4537,'2014-01-03','HXSAM','Debenhams','Clothing',-40.30,'',1,0,0),(4538,'2014-01-03','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(4539,'2014-01-03','FDMARK','Asda Filling Station','Bills:Motor',-63.00,'Petrol - Golf',1,0,0),(4540,'2014-01-04','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-67.19,'Minimum payment',1,0,0),(4541,'2014-01-04','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',67.19,'Minimum payment',1,0,0),(4542,'2014-01-06','FDMARK','Tesco','Food:Groceries',-114.77,'',1,0,0),(4543,'2014-01-06','HXSAM','Homebase','Household',-21.58,'',1,0,0),(4544,'2014-01-06','HXSAM','Argos','Home',-10.99,'Laminating pouches',1,0,0),(4545,'2014-01-06','HXSAM','Jolleys Pet Food','Pets',-7.18,'',1,0,0),(4546,'2014-01-06','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-258.30,'',1,0,0),(4547,'2014-01-06','HXSAM','Love You Hair & Beauty','Beauty',-19.00,'',1,0,0),(4548,'2014-01-06','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-5.00,'',1,0,0),(4549,'2014-01-06','HXSAM','Apple ITunes','Entertainment:Hobbies',-24.99,'Mythbusters',1,0,0),(4550,'2014-01-06','HXSAM','Amazon','Entertainment',-14.00,'',1,0,0),(4551,'2014-01-06','HXSAM','Dorothy Perkins','Clothing:Sam',-21.12,'',1,0,0),(4552,'2014-01-06','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(4553,'2014-01-06','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(4554,'2014-01-07','HXSAM','ParentPay','Food:School Dinners',-31.10,'',1,0,0),(4555,'2014-01-07','HXSAM','Herbalife','Food:Groceries',-164.48,'',1,0,0),(4556,'2014-01-07','HXSAM','B&M bargains','Household',-7.45,'',1,0,0),(4557,'2014-01-07','HXSAM','Paypal','Miscellaneous',-8.00,'',1,0,0),(4558,'2014-01-07','HXSAM','Paypal','Miscellaneous',-18.95,'',1,0,0),(4559,'2014-01-07','HXSAM','Rowlands Pharmacy','Bills:Prescriptions',-15.70,'',1,0,0),(4560,'2014-01-07','HXSAM','Rowlands Pharmacy','Bills:Prescriptions',15.70,'',1,0,0),(4561,'2014-01-07','HXSAM','Alex Crewe Limited','Bills:Prescriptions',-15.70,'',1,0,0),(4562,'2014-01-07','HXSAM','<FDMARK>','Transfer',40.00,'',1,0,0),(4563,'2014-01-07','FDMARK','<HXSAM>','Transfer',-40.00,'',1,0,0),(4564,'2014-01-07','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(4565,'2014-01-07','FDMARK','BT','Bills:Utilities',-46.15,'House phone & broadband',1,0,0),(4566,'2014-01-08','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4567,'2014-01-08','HXSAM','Paypal','Miscellaneous',-15.98,'',1,0,0),(4568,'2014-01-08','FDMARK','O2','Bills:Mobile Phones',-27.60,'Sam\'s iPhone ',1,0,0),(4569,'2014-01-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(4570,'2014-01-09','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-23.30,'Minimum payment',1,0,0),(4571,'2014-01-10','NEXTCARD','Next','Clothing',-143.44,'',1,0,0),(4572,'2014-01-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(4573,'2014-01-10','HXSAM','Amazon','Refund',12.08,'',1,0,0),(4574,'2014-01-11','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(4575,'2014-01-11','HXSAM','Greenthumb','Garden',-32.00,'',1,0,0),(4576,'2014-01-13','FDMARK','Tesco','Food:Groceries',-152.60,'',1,0,0),(4577,'2014-01-13','HXSAM','Jolleys Pet Food','Pets',-18.48,'',1,0,0),(4578,'2014-01-13','HXSAM','Halfords','Hobbies',-14.39,'',1,0,0),(4579,'2014-01-13','HXSAM','Boots','Medical',-12.00,'',1,0,0),(4580,'2014-01-13','FDMARK','Tesco Garage','Food:Groceries',-12.46,'',1,0,0),(4581,'2014-01-13','HXSAM','Paypal','Miscellaneous',-5.99,'',1,0,0),(4582,'2014-01-13','HXSAM','Apple ITunes','Entertainment:Hobbies',-0.99,'',1,0,0),(4583,'2014-01-13','HXSAM','Paypal','Miscellaneous',-27.00,'Sam\'s coat',1,0,0),(4584,'2014-01-13','HXSAM','Cheque','Miscellaneous',-46.25,'Avon',1,0,0),(4585,'2014-01-14','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-22.60,'',1,0,0),(4586,'2014-01-14','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(4587,'2014-01-15','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4588,'2014-01-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-25.00,'Bus monthly fee',1,0,0),(4589,'2014-01-15','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(4590,'2014-01-16','FDMARK','Tesco Garage','Food:Groceries',-10.32,'',1,0,0),(4591,'2014-01-16','HXSAM','Amazon','Clothing',-46.44,'Marks boots',1,0,0),(4592,'2014-01-17','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.99,'Sleepy hollow',1,0,0),(4593,'2014-01-19','FDMARK','Lovefilm.com','Entertainment:Hobbies',-13.27,'',1,0,0),(4594,'2014-01-20','FDMARK','Tesco','Food:Groceries',-110.47,'',1,0,0),(4595,'2014-01-20','FDMARK','Tesco  ','Food:Groceries',-6.74,'',1,0,0),(4596,'2014-01-20','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.99,'Toast of london ',1,0,0),(4597,'2014-01-20','FDMARK','Tesco Garage','Bills:Motor',-55.81,'BMW ',1,0,0),(4598,'2014-01-20','FDMARK','Tesco','Other Income:Refunds',4.00,'',1,0,0),(4599,'2014-01-20','FDMARK','ParentPay','Entertainment:Days Out',-21.50,'School trips',1,0,0),(4600,'2014-01-20','HXSAM','Amazon','Refund',46.44,'',1,0,0),(4601,'2014-01-20','HXSAM','Home Bargains','Food:Groceries',-6.71,'',1,0,0),(4602,'2014-01-20','HXSAM','Home Bargains','Food:Groceries',-8.26,'',1,0,0),(4603,'2014-01-20','HXSAM','Love You Hair & Beauty','Beauty',-16.00,'',1,0,0),(4604,'2014-01-21','FDMARK','Alex Crewe Limited','Bills:Prescriptions',-7.85,'',1,0,0),(4605,'2014-01-21','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4606,'2014-01-21','HXSAM','Tesco Garage','Food:Groceries',-18.88,'',1,0,0),(4607,'2014-01-21','HXSAM','Amazon','Miscellaneous',-7.98,'Laptop cover',1,0,0),(4608,'2014-01-22','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4609,'2014-01-24','HXSAM','Paypal','Miscellaneous',-4.98,'',1,0,0),(4610,'2014-01-24','HXSAM','Tesco Garage','Food:Groceries',-15.84,'',1,0,0),(4611,'2014-01-24','HXSAM','York Race Course','Entertainment:Days Out',-8.50,'Tour de France grand depart parking ',1,0,0),(4612,'2014-01-25','FDMARK','<Credit Card HALIFAX SAM>','Transfer',-150.00,'',1,0,0),(4613,'2014-01-26','FDMARK','O2','Bills:Mobile Phones',-37.15,'Mark\'s iPhone ',1,0,0),(4614,'2014-01-27','FDMARK','Tesco','Food:Groceries',-119.63,'',1,0,0),(4615,'2014-01-27','FDMARK','Aviva','Salary',3867.00,'',1,0,0),(4616,'2014-01-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',800.00,'',1,0,0),(4617,'2014-01-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-800.00,'',1,0,0),(4618,'2014-01-27','FDMARK','Tesco','Delivery Charge',-10.00,'',1,0,0),(4619,'2014-01-27','HXSAM','DGS/RPP DD','Bills:Insurance',-11.59,'',1,0,0),(4620,'2014-01-27','HXSAM','Brantano','Clothing',-62.00,'',1,0,0),(4621,'2014-01-27','FDMARK','Aldi','Food:Groceries',-14.94,'',1,0,0),(4622,'2014-01-27','HXSAM','The Owl Hotel','Food:Dining',-55.28,'',1,0,0),(4623,'2014-01-27','HXSAM','Amazon','Miscellaneous',-33.86,'',1,0,0),(4624,'2014-01-28','NEXTCARD','<FDMARK>','Bills:Credit Card Payment',850.00,'',1,0,0),(4625,'2014-01-28','FDMARK','<NEXTCARD>','Bills:Credit Card Payment',-850.00,'',1,0,0),(4626,'2014-01-28','FDMARK','Tesco Garage','Food:Groceries',-14.49,'',1,0,0),(4627,'2014-01-28','HXSAM','Graze.com','Food:Snacks',-3.89,'',1,0,0),(4628,'2014-01-28','FDMARK','Pinn Insure Plc','Insurance',-7.47,'Cat insurance ',1,0,0),(4629,'2014-01-29','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4630,'2014-01-29','HXSAM','Paypal','Home',-16.50,'Toothbrush heads',1,0,0),(4631,'2014-01-29','HXSAM','Holland & Barrett','Food:Snacks',-15.97,'',1,0,0),(4632,'2014-01-30','HXSAM','Pets At Home','Pets',-9.00,'',1,0,0),(4633,'2014-01-30','HXSAM','Brantano','Clothing',-17.00,'',1,0,0),(4634,'2014-01-30','HXSAM','B&M bargains','Household',-18.77,'',1,0,0),(4635,'2014-01-30','HXSAM','Brantano','Clothing',-33.00,'',1,0,0),(4636,'2014-01-31','FDMARK','Tesco Garage','Food:Groceries',-9.02,'',1,0,0),(4637,'2014-01-31','FORTHEFUTURE','First Direct','Interest',0.30,'',1,0,0),(4638,'2014-01-31','FORTHEFUTURE','First Direct','Interest',1.17,'',1,0,0),(4639,'2014-01-31','HXSAM','Selby College','Salary',588.04,'Sam salary',1,0,0),(4640,'2014-01-31','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4641,'2014-02-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(4642,'2014-02-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(4643,'2014-02-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(4644,'2014-02-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(4645,'2014-02-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-151.00,'',1,0,0),(4646,'2014-02-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(4647,'2014-02-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(4648,'2014-02-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(4649,'2014-02-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(4650,'2014-02-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(4651,'2014-02-01','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(4652,'2014-02-02','FDMARK','ParentPay','Food:School Dinners',-50.00,'',1,0,0),(4653,'2014-02-03','FDMARK','Tesco','Food:Groceries',-129.43,'',1,0,0),(4654,'2014-02-03','FDMARK','Tesco Garage','Food:Groceries',13.41,'',1,0,0),(4655,'2014-02-03','FDMARK','Home Bargains','Food:Groceries',-12.04,'',1,0,0),(4656,'2014-02-03','FDMARK','Tesco Garage','Food:Groceries',-12.50,'',1,0,0),(4657,'2014-02-03','HXSAM','Holmefield Vets','Pets',-22.10,'',1,0,0),(4658,'2014-02-03','HXSAM','Love You Hair & Beauty','Beauty',-17.50,'',1,0,0),(4659,'2014-02-03','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4660,'2014-02-04','HXSAM','Tesco Garage','Food',-5.38,'',1,0,0),(4661,'2014-02-04','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(4662,'2014-02-04','HXSAM','Weekly Cash - Mark','Cash:Regular',-40.00,'',1,0,0),(4663,'2014-02-05','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4664,'2014-02-05','FDMARK','Tesco Garage','Food:Groceries',-14.96,'',1,0,0),(4665,'2014-02-05','HXSAM','Paypal','Gifts',-83.50,'',1,0,0),(4666,'2014-02-05','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(4667,'2014-02-05','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(4668,'2014-02-05','FDMARK','BT','Bills:Utilities',-50.53,'House phone & broadband',1,0,0),(4669,'2014-02-05','HXSAM','Paypal','Gifts',-28.69,'Aimee\'s bag',1,0,0),(4670,'2014-02-05','HXSAM','Amazon','Gifts',-19.99,'Harvey\'s game',1,0,0),(4671,'2014-02-05','HXSAM','Amazon','Entertainment',-19.70,'Bike rack',1,0,0),(4672,'2014-02-06','FDMARK','Tesco Garage','Food:Groceries',-28.66,'',1,0,0),(4673,'2014-02-06','HXSAM','Rowlands Pharmacy','Bills:Prescriptions',-7.85,'',1,0,0),(4674,'2014-02-06','HXSAM','Amazon','Entertainment',-6.02,'Dilbert',1,0,0),(4675,'2014-02-07','HXSAM','John Greed Jewellery','Gifts',-35.00,'',1,0,0),(4676,'2014-02-07','FORTHEFUTURE','First Direct','Interest',0.08,'',1,0,0),(4677,'2014-02-07','FORTHEFUTURE','First Direct','Interest',0.27,'',1,0,0),(4678,'2014-02-07','HXSAM','Cheque','Miscellaneous',-150.13,'Sam\'s shakes',1,0,0),(4679,'2014-02-07','HXSAM','Brantano','Clothing',-19.00,'',1,0,0),(4680,'2014-02-10','FDMARK','Tesco','Food:Groceries',-113.66,'',1,0,0),(4681,'2014-02-10','HXSAM','Cash','Cash',-30.00,'Sam night out',1,0,0),(4682,'2014-02-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(4683,'2014-02-10','HXSAM','Amazon','Entertainment',-0.62,'',1,0,0),(4684,'2014-02-10','FDMARK','O2','Bills:Mobile Phones',-23.74,'Sam\'s iPhone ',1,0,0),(4685,'2014-02-10','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(4686,'2014-02-10','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-24.08,'Minimum payment',1,0,0),(4687,'2014-02-10','FDMARK','Tesco Garage','Bills:Motor',-60.71,'BMW ',1,0,0),(4688,'2014-02-11','HXSAM','The Wychwood Brewery','Gifts',-13.98,'',1,0,0),(4689,'2014-02-11','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(4690,'2014-02-12','FDMARK','Tesco Garage','Food:Groceries',-9.97,'',1,0,0),(4691,'2014-02-12','HXSAM','Amazon','Gifts',-27.98,'',1,0,0),(4692,'2014-02-12','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4693,'2014-02-12','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(4694,'2014-02-13','HXSAM','Post Office Counters','Bills:Motor',-24.50,'Driving licence renewal',1,0,0),(4695,'2014-02-14','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Bus monthly fee',1,0,0),(4696,'2014-02-14','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(4697,'2014-02-15','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(4698,'2014-02-16','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4699,'2014-02-17','FDMARK','Tesco','Food:Groceries',-127.48,'',1,0,0),(4700,'2014-02-17','HXSAM','Tesco Garage','Food:Groceries',-17.70,'',1,0,0),(4701,'2014-02-17','HXSAM','That\'s Entertainment','Gifts',-17.99,'',1,0,0),(4702,'2014-02-17','HXSAM','Cineworld','Entertainment:Days Out',-8.50,'',1,0,0),(4703,'2014-02-17','HXSAM','Amazon','Miscellaneous',-1.24,'',1,0,0),(4704,'2014-02-17','HXSAM','Amazon','Miscellaneous',-8.89,'',1,0,0),(4705,'2014-02-17','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-22.42,'',1,0,0),(4706,'2014-02-17','HXSAM','Cineworld','Entertainment:Days Out',-13.86,'Lego movie',1,0,0),(4707,'2014-02-17','FDMARK','Tesco Garage','Bills:Motor',-62.10,'Petrol - Golf',1,0,0),(4708,'2014-02-18','HXSAM','Amazon','Miscellaneous',-19.99,'',1,0,0),(4709,'2014-02-18','HXSAM','Home Bargains','Food:Groceries',-23.38,'',1,0,0),(4710,'2014-02-19','HXSAM','Frankie & Benny\'s','Food:Dining',-51.35,'',1,0,0),(4711,'2014-02-19','HXSAM','New Look','Clothing',-39.97,'',1,0,0),(4712,'2014-02-19','HXSAM','Barclaycard','Refund',11.52,'',1,0,0),(4713,'2014-02-19','HXSAM','Graze.com','Food:Snacks',-3.49,'',1,0,0),(4714,'2014-02-19','HXSAM','Cash','Cash',-10.00,'',1,0,0),(4715,'2014-02-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-13.27,'',1,0,0),(4716,'2014-02-19','HXSAM','MandMDirect.com','Clothing:Mark',-55.43,'',1,0,0),(4717,'2014-02-19','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4718,'2014-02-20','FDMARK','<Credit Card HALIFAX MARK>','Refund',22.42,'',1,0,0),(4719,'2014-02-20','HXSAM','Paypal','Gifts',-24.48,'',1,0,0),(4720,'2014-02-20','HXSAM','Caffe Nero','Food:Dining',-10.70,'',1,0,0),(4721,'2014-02-20','HXSAM','Tesco Garage','Food:Groceries',-16.91,'',1,0,0),(4722,'2014-02-20','HXSAM','<FDMARK>','Transfer',50.00,'',1,0,0),(4723,'2014-02-20','FDMARK','<HXSAM>','Transfer',-50.00,'',1,0,0),(4724,'2014-02-20','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(4725,'2014-02-21','HXSAM','The Wishing Well','Food:Dining',-5.79,'',1,0,0),(4726,'2014-02-24','FDMARK','Tesco','Food:Groceries',-126.93,'',1,0,0),(4727,'2014-02-24','HXSAM','Aldi','Food:Groceries',-16.31,'',1,0,0),(4728,'2014-02-24','RAINYDAY','Halifax','Interest',1.75,'',1,0,0),(4729,'2014-02-24','HXSAM','Weekly Cash - Mark','Cash:Regular',-40.00,'',1,0,0),(4730,'2014-02-25','HXSAM','<NEXTCARD>','Clothing',-30.00,'',1,0,0),(4731,'2014-02-25','NEXTCARD','<HXSAM>','Clothing',30.00,'',1,0,0),(4732,'2014-02-25','FDMARK','O2','Bills:Mobile Phones',-37.15,'Mark\'s iPhone ',1,0,0),(4733,'2014-02-26','FDMARK','Tesco','Delivery Charge',-10.00,'',1,0,0),(4734,'2014-02-26','HXSAM','Morrisons','Food:Groceries',-41.34,'',1,0,0),(4735,'2014-02-27','FDMARK','Aviva','Salary',3867.00,'',1,0,0),(4736,'2014-02-27','HXSAM','DGS/RPP DD','Bills:Insurance',-11.59,'',1,0,0),(4737,'2014-02-27','HXSAM','Cash','Cash',-30.00,'',1,0,0),(4738,'2014-02-28','HXSAM','Paypal','Clothing',-18.50,'Sam dress',1,0,0),(4739,'2014-02-28','HXSAM','Cash','Cash',-20.00,'',1,0,0),(4740,'2014-02-28','FORTHEFUTURE','First Direct','Interest',0.21,'',1,0,0),(4741,'2014-02-28','HXSAM','Selby College','Salary',588.04,'Sam salary',1,0,0),(4742,'2014-02-28','FDMARK','Pinn Insure Plc','Insurance',-7.47,'Cat insurance ',1,0,0),(4743,'2014-03-01','HXSAM','<FDMARK>','Transfer:Monthly Spends',800.00,'',1,0,0),(4744,'2014-03-01','FDMARK','<HXSAM>','Transfer:Monthly Spends',-800.00,'',1,0,0),(4745,'2014-03-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(4746,'2014-03-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(4747,'2014-03-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(4748,'2014-03-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(4749,'2014-03-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(4750,'2014-03-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(4751,'2014-03-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(4752,'2014-03-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(4753,'2014-03-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(4754,'2014-03-02','FDMARK','ParentPay','Food:School Dinners',-25.60,'',1,0,0),(4755,'2014-03-03','FDMARK','Tesco','Food:Groceries',-122.16,'',1,0,0),(4756,'2014-03-03','HXSAM','Halfords','Hobbies',-8.99,'Brakes',1,0,0),(4757,'2014-03-03','HXSAM','Wilkinsons','Household',-7.00,'',1,0,0),(4758,'2014-03-03','HXSAM','Argos','Gifts',-11.99,'',1,0,0),(4759,'2014-03-03','HXSAM','Yorkshire Trading','Hobbies',-8.52,'Knitting stuff',1,0,0),(4760,'2014-03-03','FDMARK','Tesco Garage','Food:Groceries',-15.98,'',1,0,0),(4761,'2014-03-03','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(4762,'2014-03-03','HXSAM','DGS/RPP DD','Bills:Insurance',-6.74,'Dishwasher cover',1,0,0),(4763,'2014-03-03','HXSAM','The Book People','Books',-26.93,'',1,0,0),(4764,'2014-03-03','HXSAM','Tribute Funds','Miscellaneous',-10.00,'',1,0,0),(4765,'2014-03-03','HXSAM','Apple ITunes','Entertainment:Hobbies',-10.96,'TV series',1,0,0),(4766,'2014-03-03','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(4767,'2014-03-04','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(4768,'2014-03-04','HXSAM','<NEXTCARD>','Clothing',-5.00,'',1,0,0),(4769,'2014-03-04','NEXTCARD','<HXSAM>','Clothing',5.00,'',1,0,0),(4770,'2014-03-04','HXSAM','<NEXTCARD>','Clothing',-15.65,'',1,0,0),(4771,'2014-03-04','NEXTCARD','<HXSAM>','Clothing',15.65,'',1,0,0),(4772,'2014-03-04','HXSAM','Amazon','Gifts',-24.45,'',1,0,0),(4773,'2014-03-04','FDMARK','Tesco Garage','Bills:Motor',-61.43,'BMW ',1,0,0),(4774,'2014-03-05','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(4775,'2014-03-05','FDMARK','Tesco Garage','Food:Groceries',-10.82,'',1,0,0),(4776,'2014-03-05','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(4777,'2014-03-05','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4778,'2014-03-06','FDMARK','Tesco Garage','Food:Groceries',-14.69,'',1,0,0),(4779,'2014-03-06','HXSAM','Superdrug','Medical',-4.99,'',1,0,0),(4780,'2014-03-06','HXSAM','Amazon','Gifts',-3.99,'Bike brakes',1,0,0),(4781,'2014-03-07','FDMARK','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-700.00,'',1,0,0),(4782,'2014-03-07','HXSAM','Cheque','Miscellaneous',-15.00,'Guide trip',1,0,0),(4783,'2014-03-07','HXSAM','Cash','Cash',-40.00,'',1,0,0),(4784,'2014-03-07','HXSAM','Amazon','Gifts',-3.97,'Wimpy kid',1,0,0),(4785,'2014-03-07','HXSAM','Jolleys Pet Food','Pets',-20.00,'',1,0,0),(4786,'2014-03-07','FDMARK','BT','Bills:Utilities',-48.36,'House phone & broadband',1,0,0),(4787,'2014-03-10','FDMARK','Tesco','Food:Groceries',-126.29,'',1,0,0),(4788,'2014-03-10','HXSAM','Amazon','Gifts',-14.00,'',1,0,0),(4789,'2014-03-10','HXSAM','Homebase','Household',-94.99,'',1,0,0),(4790,'2014-03-10','HXSAM','Amazon','Gifts',-19.89,'',1,0,0),(4791,'2014-03-10','HXSAM','LOYD Selby','Miscellaneous',-20.00,'',1,0,0),(4792,'2014-03-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(4793,'2014-03-10','HXSAM','Paypal','Clothing',-13.99,'',1,0,0),(4794,'2014-03-10','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(4795,'2014-03-10','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-46.77,'',1,0,0),(4796,'2014-03-10','HXSAM','TheTrainLine.com','Miscellaneous',-42.50,'Train tix for Miranda',1,0,0),(4797,'2014-03-11','HXSAM','Debenhams','Clothing',-44.00,'Sam outfit',1,0,0),(4798,'2014-03-11','HXSAM','New Look','Clothing',-32.98,'Sam outfit',1,0,0),(4799,'2014-03-11','FDMARK','Tesco Garage','Food:Groceries',-13.96,'',1,0,0),(4800,'2014-03-11','HXSAM','Love You Hair & Beauty','Beauty',-46.00,'Nails & voucher',1,0,0),(4801,'2014-03-11','FDMARK','Bahnstormer','Bills:Motor',-310.00,'',1,0,0),(4802,'2014-03-11','FDMARK','O2','Bills:Mobile Phones',-21.99,'Sam\'s iPhone ',1,0,0),(4803,'2014-03-11','FDMARK','DVLA','Bills:Motor',-30.00,'Bmw tax',1,0,0),(4804,'2014-03-11','FDMARK','Hitachi Capital Lv','Bills:Loans',-43.12,'Sofa Loan',1,0,0),(4805,'2014-03-11','HXSAM','<Credit Card HALIFAX SAM>','Bills:Credit Card Payment',-21.48,'Minimum payment',1,0,0),(4806,'2014-03-11','FDMARK','Rowlands Pharmacy','Bills:Prescriptions',-15.70,'',1,0,0),(4807,'2014-03-11','HXSAM','Apple ITunes','Entertainment:Hobbies',-10.99,'Box set',1,0,0),(4808,'2014-03-11','HXSAM','Aldi','Food:Groceries',-4.53,'',1,0,0),(4809,'2014-03-11','HXSAM','Homebase','Household',-21.97,'',1,0,0),(4810,'2014-03-12','FDMARK','Aviva Accounts Rec','Work:Expenses',196.20,'',1,0,0),(4811,'2014-03-13','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4812,'2014-03-13','HXSAM','Argos','Gifts',-17.99,'Headset',1,0,0),(4813,'2014-03-14','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(4814,'2014-03-14','FDMARK','<Credit Card HALIFAX SAM>','Transfer',-200.00,'',1,0,0),(4815,'2014-03-14','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-25.00,'Minimum payment ',1,0,0),(4816,'2014-03-14','HXSAM','Tesco Garage','Food:Groceries',-4.00,'',1,0,0),(4817,'2014-03-15','HXSAM','Cash','Cash',-40.00,'',1,0,0),(4818,'2014-03-17','FDMARK','Tesco','Food:Groceries',-116.43,'',1,0,0),(4819,'2014-03-17','FDMARK','Apcoa','Work:Expenses',-2.30,'',1,0,0),(4820,'2014-03-17','HXSAM','National Rail','Bills:Transport',-51.60,'Train to Manchester',1,0,0),(4821,'2014-03-17','HXSAM','Pizza Express','Food:Dining',-41.20,'',1,0,0),(4822,'2014-03-17','FDMARK','<Credit Card HALIFAX MARK>','Bills:Credit Card Payment',-2.64,'',1,0,0),(4823,'2014-03-17','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Bus monthly fee',1,0,0),(4824,'2014-03-18','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4825,'2014-03-19','HXSAM','Prime Instant Video','Entertainment:Hobbies',-5.99,'',1,0,0),(4826,'2014-03-19','HXSAM','Hunters','Beauty:Haircut',-56.00,'',1,0,0),(4827,'2014-03-19','NEXTCARD','Adjustment','Miscellaneous',-110.24,'',1,0,0),(4828,'2014-03-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(4829,'2014-03-21','HXSAM','Cash','Cash',-10.00,'',1,0,0),(4830,'2014-03-21','HXSAM','B&M bargains','Household',-16.50,'',1,0,0),(4831,'2014-03-22','NEXTCARD','Next','Clothing',-7.00,'Harvey school shorts',1,0,0),(4832,'2014-03-22','NEXTCARD','Next','Clothing',-9.00,'HT school Trousers',1,0,0),(4833,'2014-03-22','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(4834,'2014-03-22','NEXTCARD','Next','Clothing',-20.00,'ST work trousers',1,0,0),(4835,'2014-03-22','NEXTCARD','Next','Clothing',-14.00,'ST work blouse',1,0,0),(4836,'2014-03-22','NEXTCARD','Next','Clothing',-8.00,'AT pumps',1,0,0),(4837,'2014-03-22','NEXTCARD','Next','Clothing',-10.00,'AT jeans',1,0,0),(4838,'2014-03-22','NEXTCARD','Next','Clothing',-4.00,'Gift for HT',1,0,0),(4839,'2014-03-22','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(4840,'2014-03-22','NEXTCARD','Next','Clothing',-24.00,'ST cardigan for work',1,0,0),(4841,'2014-03-22','NEXTCARD','Next','Clothing',-18.00,'School trousers HT x 2',1,0,0),(4842,'2014-03-22','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(4843,'2014-03-22','NEXTCARD','Next','Clothing',-6.50,'Tankini AT',1,0,0),(4844,'2014-03-22','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(4845,'2014-03-22','NEXTCARD','Next','Clothing',-5.50,'AT socks',1,0,0),(4846,'2014-03-22','NEXTCARD','Next','Clothing',-35.00,'ST skirt for work',1,0,0),(4847,'2014-03-22','NEXTCARD','Next','Clothing',-15.00,'ST top for work',1,0,0),(4848,'2014-03-22','NEXTCARD','Next','Returned Clothing',-102.00,'',1,0,0),(4849,'2014-03-22','NEXTCARD','Next','Returns',80.00,'',1,0,0),(4850,'2014-03-24','FDMARK','Tesco','Food:Groceries',-128.61,'',1,0,0),(4851,'2014-03-24','HXSAM','Cineworld','Entertainment:Days Out',-25.00,'',1,0,0),(4852,'2014-03-24','HXSAM','Claire\'s Accessories','Clothing:Kids',-10.00,'',1,0,0),(4853,'2014-03-24','HXSAM','Gap','Clothing',-20.47,'',1,0,0),(4854,'2014-03-24','HXSAM','Cineworld','Entertainment:Days Out',-9.30,'',1,0,0),(4855,'2014-03-24','HXSAM','Birchwood Farm','Food:Dining',-55.80,'',1,0,0),(4856,'2014-03-24','FDMARK','Tesco Garage','Food:Groceries',-14.98,'',1,0,0),(4857,'2014-03-24','HXSAM','Amazon','Gifts',-9.98,'Aimee\'s phone',1,0,0),(4858,'2014-03-24','HXSAM','Apple ITunes','Entertainment:Hobbies',-25.99,'',1,0,0),(4859,'2014-03-24','HXSAM','Toyz+','Gifts',-4.99,'',1,0,0),(4860,'2014-03-25','FDMARK','O2','Bills:Mobile Phones',-39.39,'Mark\'s iPhone ',1,0,0),(4861,'2014-03-25','HXSAM','Cash','Cash',-50.00,'',1,0,0),(4862,'2014-03-26','FDMARK','Tesco','Delivery Charge',-10.00,'',1,0,0),(4863,'2014-03-26','HXSAM','Paypal','Clothing',-5.00,'',1,0,0),(4864,'2014-03-26','HXSAM','Jolleys Pet Food','Pets',-8.99,'',1,0,0),(4865,'2014-03-26','HXSAM','Weekly Cash - Sam','Cash:Regular',-10.00,'',1,0,0),(4866,'2014-03-27','FDMARK','Aviva','Salary',12068.00,'',1,0,0),(4867,'2014-03-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',800.00,'',1,0,0),(4868,'2014-03-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-800.00,'',1,0,0),(4869,'2014-03-27','HXSAM','DGS/RPP DD','Bills:Insurance',-11.59,'',1,0,0),(4870,'2014-03-27','FDMARK','Tesco Garage','Food:Groceries',-28.16,'',1,0,0),(4871,'2014-03-27','FDMARK','Aviva Accounts Rec','Work:Expenses',133.80,'',1,0,0),(4872,'2014-03-28','HXSAM','Cash','Cash',-30.00,'',1,0,0),(4873,'2014-03-28','FDMARK','Tesco Garage','Bills:Motor',-61.88,'Petrol - Golf',1,0,0),(4874,'2014-03-28','FDMARK','Pinn Insure Plc','Insurance',-7.47,'Cat insurance ',1,0,0),(4875,'2014-03-29','HXSAM','<FDMARK>','Transfer',100.00,'',1,0,0),(4876,'2014-03-29','FDMARK','<HXSAM>','Transfer',-100.00,'',1,0,0),(4877,'2014-03-29','FDMARK','<Credit Card FIRST DIRECT>','Bills:Credit Card Payment',-203.50,'',1,0,0),(4878,'2014-03-29','RAINYDAY','<FDMARK>','Transfer',7900.00,'',1,0,0),(4879,'2014-03-29','FDMARK','<RAINYDAY>','Transfer',-7900.00,'',1,0,0),(4880,'2014-03-29','FDMARK','<Credit Card HALIFAX SAM>','Transfer',-903.36,'',1,0,0),(4881,'2014-03-30','HXSAM','Cash','Cash',-40.00,'',1,0,0),(4882,'2014-03-31','FDMARK','Tesco','Food:Groceries',-119.58,'',1,0,0),(4883,'2014-03-31','HXSAM','Paypal','Clothing',-12.00,'',1,0,0),(4884,'2014-03-31','HXSAM','Amazon','Hobbies',-0.99,'',1,0,0),(4885,'2014-03-31','HXSAM','TSL Clothing','Clothing',-20.95,'',1,0,0),(4886,'2014-03-31','HXSAM','EE & T-Mobile','Bills:Mobile Phones',-10.00,'',1,0,0),(4887,'2014-03-31','HXSAM','Amazon','Hobbies',-0.99,'',1,0,0),(4888,'2014-03-31','HXSAM','Apple ITunes','Entertainment:Hobbies',-3.49,'',1,0,0),(4889,'2014-03-31','HXSAM','Boots','Medical',-15.70,'',1,0,0),(4890,'2014-03-31','HXSAM','Dorothy Perkins','Clothing:Sam',-20.30,'',1,0,0),(4891,'2014-03-31','FDMARK','Aviva Motor','Bills:Insurance',-348.80,'',1,0,0),(4892,'2014-03-31','FORTHEFUTURE','First Direct','Interest',0.31,'',1,0,0),(4893,'2014-03-31','HXSAM','Hotel Chocolat','Gifts',-13.00,'',1,0,0),(4894,'2014-03-31','HXSAM','Selby College','Salary',588.04,'Sam salary',1,0,0),(4895,'2014-03-31','FDMARK','Tesco Garage','Bills:Motor',-73.13,'BMW ',1,0,0),(4896,'2014-03-31','HXSAM','Tesco Garage','Gifts',-29.20,'',1,0,0),(4897,'2014-04-01','HXSAM','Amazon','Gifts',-17.82,'',1,0,0),(4898,'2014-04-01','HXSAM','Halfords','Hobbies',-276.99,'',1,0,0),(4899,'2014-04-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(4900,'2014-04-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(4901,'2014-04-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(4902,'2014-04-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(4903,'2014-04-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(4904,'2014-04-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-156.78,'',1,0,0),(4905,'2014-04-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(4906,'2014-04-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(4907,'2014-04-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(4908,'2014-04-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(4909,'2014-04-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(4910,'2014-04-01','HXSAM','DGS/RPP DD','Bills:Insurance',-6.74,'Dishwasher cover',1,0,0),(4911,'2014-04-01','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(4912,'2014-04-02','FDMARK','Morrisons','Food:Groceries',-26.13,'',1,0,0),(4913,'2014-04-02','HXSAM','Paypal','Clothing',-6.50,'',1,0,0),(4914,'2014-04-02','HXSAM','Paypal','Clothing',-7.00,'',1,0,0),(4915,'2014-04-02','HXSAM','Paypal','Clothing',-13.50,'',1,0,0),(4916,'2014-04-02','HXSAM','Amazon','Hobbies',-20.53,'Gloves & light',1,0,0),(4917,'2014-04-03','HXSAM','National Lottery','Hobbies',-10.00,'',1,0,0),(4918,'2014-04-03','HXSAM','Weekly Cash - Sam','Cash:Regular',-50.00,'',1,0,0),(4919,'2014-04-03','HXSAM','Tesco Direct','Clothing:Kids',-24.25,'',1,0,0),(4920,'2014-04-04','HXSAM','<FDMARK>','Bills:Motor',130.00,'',1,0,0),(4921,'2014-04-04','FDMARK','<HXSAM>','Bills:Motor',-130.00,'',1,0,0),(4922,'2014-04-04','FDMARK','Tesco Garage','Food:Groceries',-7.49,'',1,0,0),(4923,'2014-04-04','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(4924,'2014-04-04','HXSAM','Placeholder - Car Service','Bills:Motor',-130.00,'Golf service by Mark',1,0,0),(4925,'2014-04-04','FDMARK','BT','Bills:Utilities',-46.64,'House phone & broadband',1,0,0),(4926,'2014-04-06','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(4927,'2014-04-07','FDMARK','Aldi','Food:Groceries',-5.38,'',1,0,0),(4928,'2014-04-07','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.98,'',1,0,0),(4929,'2014-04-07','HXSAM','Argos','Gifts',-16.98,'',1,0,0),(4930,'2014-04-07','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-45.72,'',1,0,0),(4931,'2014-04-08','FDMARK','Tesco','Food:Groceries',-126.88,'',1,0,0),(4932,'2014-04-08','HXSAM','Cash','Cash',-50.00,'',1,0,0),(4933,'2014-04-08','HXSAM','Jolleys Pet Food','Pets',-5.89,'',1,0,0),(4934,'2014-04-08','HXSAM','B&M bargains','Household',-4.95,'',1,0,0),(4935,'2014-04-08','HXSAM','<RAINYDAY>','Transfer',300.00,'',1,0,0),(4936,'2014-04-08','RAINYDAY','<HXSAM>','Transfer',-300.00,'',1,0,0),(4937,'2014-04-08','FDMARK','O2','Bills:Mobile Phones',-29.02,'Sam\'s iPhone ',1,0,0),(4938,'2014-04-09','FDMARK','Tesco Garage','Food:Groceries',-7.23,'',1,0,0),(4939,'2014-04-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(4940,'2014-04-10','HXSAM','Tesco Garage','Food:Groceries',-10.99,'',1,0,0),(4941,'2014-04-10','HXSAM','Banardos','Entertainment:Books',-16.96,'',1,0,0),(4942,'2014-04-10','HXSAM','Amazon','Gifts',-42.99,'',1,0,0),(4943,'2014-04-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(4944,'2014-04-10','HXSAM','Lindt','Gifts',-7.99,'',1,0,0),(4945,'2014-04-10','HXSAM','Next','Clothing',-11.50,'',1,0,0),(4946,'2014-04-10','HXSAM','Amazon','Clothing',-39.20,'Harvey\'s shoes',1,0,0),(4947,'2014-04-10','HXSAM','Market Lane Dental','Bills:Prescriptions',-18.50,'',1,0,0),(4948,'2014-04-11','HXSAM','Paypal','Clothing',-42.49,'',1,0,0),(4949,'2014-04-11','HXSAM','Amazon','Gifts',-6.00,'',1,0,0),(4950,'2014-04-11','HXSAM','Wh Smith','Books',-13.37,'',1,0,0),(4951,'2014-04-11','HXSAM','River Island','Gifts',-17.00,'',1,0,0),(4952,'2014-04-11','HXSAM','Pear Tree Farm','Food:Dining',-34.86,'',1,0,0),(4953,'2014-04-11','HXSAM','Pear Tree Farm','Food:Dining',-8.50,'',1,0,0),(4954,'2014-04-11','HXSAM','Hobby Craft','Home:Decorations',-7.99,'',1,0,0),(4955,'2014-04-11','HXSAM','Lastminute.com','Entertainment:Days Out',-135.00,'Big blue hotel, Blackpool ',1,0,0),(4956,'2014-04-11','HXSAM','Amazon','Hobbies',-44.99,'Kettle',1,0,0),(4957,'2014-04-12','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(4958,'2014-04-14','FDMARK','Tesco','Food:Groceries',-106.24,'',1,0,0),(4959,'2014-04-14','HXSAM','Aldi','Food:Groceries',-7.80,'',1,0,0),(4960,'2014-04-14','HXSAM','Home Bargains','Home:Appliances',-16.45,'',1,0,0),(4961,'2014-04-14','HXSAM','Selby Superbowl','Entertainment:Days Out',-18.00,'',1,0,0),(4962,'2014-04-14','HXSAM','Selby Superbowl','Entertainment:Days Out',-53.60,'Deposit for Harvey\'s party',1,0,0),(4963,'2014-04-14','FDMARK','Argos','Gifts',-6.49,'',1,0,0),(4964,'2014-04-14','FDMARK','Jolleys Pet Food','Pets',-16.50,'',1,0,0),(4965,'2014-04-14','HXSAM','Jean Tonks','Gifts',5000.00,'',1,0,0),(4966,'2014-04-14','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-0.77,'',1,0,0),(4967,'2014-04-14','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(4968,'2014-04-14','HXSAM','<Credit Card MBNA Sam>','Bills:Credit Card Payment',-46.80,'Minimum payment ',1,0,0),(4969,'2014-04-15','HXSAM','Home Bargains','Home',-18.94,'Light bulbs, etc',1,0,0),(4970,'2014-04-15','HXSAM','Amazon Marketplace','Gifts',-1.74,'',0,0,0),(4971,'2014-04-15','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-0.61,'',1,0,0),(4972,'2014-04-15','HXSAM','Love You Hair & Beauty','Beauty',-31.00,'',1,0,0),(4973,'2014-04-15','HXSAM','Dorothy Perkins','Clothing:Sam',-10.00,'',1,0,0),(4974,'2014-04-15','HXSAM','Amazon','Home:Furniture',-69.00,'Cat flap',1,0,0),(4975,'2014-04-15','FDMARK','Sainsbury\'s','Food:Groceries',-32.53,'',1,0,0),(4976,'2014-04-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Bus monthly fee',1,0,0),(4977,'2014-04-15','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(4978,'2014-04-15','HXSAM','Cineworld','Entertainment:Days Out',-4.05,'',1,0,0),(4979,'2014-04-16','HXSAM','Cash','Cash',-101.00,'Blackpool spends ',1,0,0),(4980,'2014-04-16','HXSAM','M&Co','Clothing',-12.00,'',1,0,0),(4981,'2014-04-16','HXSAM','Cineworld','Entertainment:Days Out',-5.50,'',1,0,0),(4982,'2014-04-16','HXSAM','Paypal','Hobbies',-7.99,'Laptop battery',1,0,0),(4983,'2014-04-16','HXSAM','Blackpool Pleasure Beach','Entertainment:Days Out',-94.00,'',1,0,0),(4984,'2014-04-16','HXSAM','Market Lane Dental','Bills:Prescriptions',-18.50,'',1,0,0),(4985,'2014-04-16','FDMARK','Tesco Garage','Bills:Motor',-46.21,'BMW ',1,0,0),(4986,'2014-04-17','HXSAM','Madame Tussauds','Gifts',-20.00,'Souvenir photos',1,0,0),(4987,'2014-04-17','FDMARK','Rowlands Pharmacy','Bills:Prescriptions',-8.05,'',1,0,0),(4988,'2014-04-18','HXSAM','<RAINYDAY>','Gifts',-2600.00,'',1,0,0),(4989,'2014-04-18','RAINYDAY','<HXSAM>','Gifts',2600.00,'',1,0,0),(4990,'2014-04-18','HXSAM','Greenthumb','Garden',-16.00,'',1,0,0),(4991,'2014-04-19','HXSAM','Prime Instant Video','Entertainment:Hobbies',-5.99,'',1,0,0),(4992,'2014-04-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(4993,'2014-04-20','NEXTCARD','Next','Returns',22.00,'',1,0,0),(4994,'2014-04-22','FDMARK','Tesco','Food:Groceries',-120.03,'',1,0,0),(4995,'2014-04-22','HXSAM','Euro Garages','Entertainment:Hobbies',-7.87,'Magazines',1,0,0),(4996,'2014-04-22','HXSAM','Pizza Hut','Food:Dining',-40.55,'',1,0,0),(4997,'2014-04-22','HXSAM','Coasters','Food:Dining',-29.30,'',1,0,0),(4998,'2014-04-22','FDMARK','ParentPay','Food:School Dinners',-4.20,'',1,0,0),(4999,'2014-04-22','HXSAM','TSL Clothing','Refund',17.00,'',1,0,0),(5000,'2014-04-22','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-2.89,'',1,0,0),(5001,'2014-04-22','HXSAM','Jolleys Pet Food','Pets',-4.58,'',1,0,0),(5002,'2014-04-22','FDMARK','Tesco Garage','Food:Groceries',-9.24,'',1,0,0),(5003,'2014-04-23','HXSAM','<Credit Card MBNA Sam>','Transfer',-1932.48,'',1,0,0),(5004,'2014-04-23','HXSAM','B&M bargains','Household',-5.98,'',1,0,0),(5005,'2014-04-23','HXSAM','Paypal','Home:Furniture',-16.97,'',1,0,0),(5006,'2014-04-24','HXSAM','Paypal','Entertainment:Hobbies',-102.46,'',1,0,0),(5007,'2014-04-24','HXSAM','Amazon Marketplace','Hobbies',-1.19,'',1,0,0),(5008,'2014-04-24','HXSAM','Amazon Marketplace','Hobbies',-2.24,'',1,0,0),(5009,'2014-04-24','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(5010,'2014-04-24','HXSAM','Weekly Cash - Sam','Cash:Regular',-60.00,'',1,0,0),(5011,'2014-04-25','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(5012,'2014-04-25','FDMARK','Pret A Manger','Food',-7.34,'',1,0,0),(5013,'2014-04-25','FDMARK','O2','Bills:Mobile Phones',-38.25,'Mark\'s iPhone ',1,0,0),(5014,'2014-04-25','HXSAM','Amazon','Gifts',-16.00,'',1,0,0),(5015,'2014-04-26','HXSAM','<FDMARK>','Transfer:Monthly Spends',800.00,'',1,0,0),(5016,'2014-04-26','FDMARK','<HXSAM>','Transfer:Monthly Spends',-800.00,'',1,0,0),(5017,'2014-04-26','HXSAM','Love You Hair & Beauty','Beauty',-12.50,'',1,0,0),(5018,'2014-04-27','FDMARK','Aviva','Salary',3965.00,'',1,0,0),(5019,'2014-04-27','HXSAM','DGS/RPP DD','Bills:Insurance',-11.59,'',1,0,0),(5020,'2014-04-28','FDMARK','Tesco','Food:Groceries',-119.79,'',1,0,0),(5021,'2014-04-28','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(5022,'2014-04-28','HXSAM','Misc','Gifts',-51.23,'',1,0,0),(5023,'2014-04-28','HXSAM','Paypal','Entertainment:Hobbies',-2.10,'',1,0,0),(5024,'2014-04-28','HXSAM','Wh Smith','Books',-30.23,'',1,0,0),(5025,'2014-04-28','HXSAM','Wallis','Clothing:Sam',-15.00,'',1,0,0),(5026,'2014-04-28','HXSAM','Banardos','Clothing:Sam',-8.48,'',1,0,0),(5027,'2014-04-28','HXSAM','Halfords','Hobbies',-19.99,'Bike Maintenance',1,0,0),(5028,'2014-04-28','HXSAM','Home Bargains','Home',-30.02,'',1,0,0),(5029,'2014-04-28','HXSAM','Boots','Medical',-12.99,'',1,0,0),(5030,'2014-04-28','HXSAM','Owl Hotel','Food:Dining',-55.60,'',1,0,0),(5031,'2014-04-28','HXSAM','Boots','Medical',-4.99,'',1,0,0),(5032,'2014-04-28','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-1.19,'',1,0,0),(5033,'2014-04-28','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-0.99,'',1,0,0),(5034,'2014-04-28','HXSAM','Amazon Marketplace','Hobbies',-21.85,'',1,0,0),(5035,'2014-04-28','FDMARK','Pinn Insure Plc','Insurance',-7.47,'Cat insurance ',1,0,0),(5036,'2014-04-28','HXSAM','Weekly Cash - Sam','Cash:Regular',-40.00,'',1,0,0),(5037,'2014-04-30','FDMARK','Sainsbury\'s','Food:Groceries',-30.45,'',1,0,0),(5038,'2014-04-30','HXSAM','Paypal','Entertainment:Hobbies',-1.89,'',1,0,0),(5039,'2014-04-30','HXSAM','Paypal','Clothing',-18.00,'',1,0,0),(5040,'2014-04-30','HXSAM','Amazon','Gifts',-15.84,'',1,0,0),(5041,'2014-04-30','HXSAM','Paypal','Clothing',-13.59,'',1,0,0),(5042,'2014-04-30','FORTHEFUTURE','First Direct','Interest',0.31,'',1,0,0),(5043,'2014-04-30','HXSAM','Selby College','Salary',588.04,'Sam salary',1,0,0),(5044,'2014-05-01','HXSAM','H&M','Clothing',-28.97,'SAMs spends',1,0,0),(5045,'2014-05-01','HXSAM','Marks & Spencer','Food',-8.70,'',1,0,0),(5046,'2014-05-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(5047,'2014-05-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-36.00,'',1,0,0),(5048,'2014-05-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(5049,'2014-05-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(5050,'2014-05-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(5051,'2014-05-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-154.00,'',1,0,0),(5052,'2014-05-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(5053,'2014-05-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(5054,'2014-05-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(5055,'2014-05-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(5056,'2014-05-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(5057,'2014-05-01','HXSAM','DGS/RPP DD','Bills:Insurance',-6.74,'Dishwasher cover',1,0,0),(5058,'2014-05-01','HXSAM','Pet Health Plan','Insurance',-9.99,'',1,0,0),(5059,'2014-05-01','FDMARK','Aviva CS UK Ltd','Work:Expenses',124.20,'',1,0,0),(5060,'2014-05-02','FDMARK','Home Bargains','Food:Groceries',-38.42,'',1,0,0),(5061,'2014-05-02','HXSAM','Primark','Clothing',-15.00,'Sam',1,0,0),(5062,'2014-05-02','HXSAM','Primark','Clothing',-116.50,'SAMs spends ﾣ26',1,0,0),(5063,'2014-05-02','HXSAM','The RAC','Bills:Motor',-139.99,'',1,0,0),(5064,'2014-05-03','FDMARK','<Credit Card FIRST DIRECT>','Transfer',-120.40,'',1,0,0),(5065,'2014-05-06','FDMARK','Tesco  ','Food:Groceries',-19.06,'',1,0,0),(5066,'2014-05-06','FDMARK','BT','Bills:Utilities',-48.47,'House phone & broadband',1,0,0),(5067,'2014-05-06','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-44.69,'',1,0,0),(5068,'2014-05-06','HXSAM','<NEXTCARD>','Transfer',-27.67,'',1,0,0),(5069,'2014-05-06','NEXTCARD','<HXSAM>','Transfer',27.67,'',1,0,0),(5070,'2014-05-06','HXSAM','Selby Superbowl','Entertainment:Days Out',-70.00,'',1,0,0),(5071,'2014-05-06','HXSAM','Amazon','Gifts',-17.99,'Lego ds game',1,0,0),(5072,'2014-05-06','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(5073,'2014-05-07','FDMARK','Tesco','Food:Groceries',-120.78,'',1,0,0),(5074,'2014-05-07','FDMARK','Aldi','Food:Groceries',-7.66,'',1,0,0),(5075,'2014-05-07','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-0.99,'',1,0,0),(5076,'2014-05-07','HXSAM','Amazon Marketplace','Clothing',-18.90,'Marks shorts',1,0,0),(5077,'2014-05-07','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(5078,'2014-05-07','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(5079,'2014-05-07','HXSAM','Toys R Us','Gifts',-39.96,'',1,0,0),(5080,'2014-05-08','FDMARK','Morrisons','Food:Groceries',-19.46,'',1,0,0),(5081,'2014-05-08','HXSAM','Boots','Medical',-9.98,'',1,0,0),(5082,'2014-05-08','HXSAM','Rowlands Pharmacy','Bills:Prescriptions',-8.05,'',1,0,0),(5083,'2014-05-08','FDMARK','O2','Bills:Mobile Phones',-22.82,'Sam\'s iPhone ',1,0,0),(5084,'2014-05-08','FDMARK','Tesco Garage','Bills:Motor',-64.07,'BMW ',1,0,0),(5085,'2014-05-09','HXSAM','Cash','Cash',-30.00,'',1,0,0),(5086,'2014-05-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(5087,'2014-05-11','NEXTCARD','Next','Interest',-5.02,'',1,0,0),(5088,'2014-05-12','FDMARK','Tesco','Food:Groceries',-131.88,'',1,0,0),(5089,'2014-05-12','HXSAM','The Yorkshire Fryer','Food:Dining',-51.60,'',1,0,0),(5090,'2014-05-12','HXSAM','Argos','Gifts',-9.99,'Aimee\'s watch',1,0,0),(5091,'2014-05-12','HXSAM','Apple ITunes','Entertainment:Hobbies',-10.00,'Harvey\'s gift from grandma',1,0,0),(5092,'2014-05-12','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(5093,'2014-05-12','HXSAM','Halifax','Bills:Credit Card Payment',-4.03,'',1,0,0),(5094,'2014-05-12','HXSAM','Tesco  ','Food:Groceries',-13.00,'',1,0,0),(5095,'2014-05-12','HXSAM','Love You Hair & Beauty','Beauty',-17.50,'',1,0,0),(5096,'2014-05-12','FDMARK','Aldi','Food:Groceries',-11.95,'',1,0,0),(5097,'2014-05-14','FDMARK','Aldi','Food:Groceries',-16.29,'',1,0,0),(5098,'2014-05-14','HXSAM','Paypal','Miscellaneous',-10.20,'',1,0,0),(5099,'2014-05-14','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-10.99,'Mark book',1,0,0),(5100,'2014-05-14','HXSAM','Wh Smith','Books',-6.00,'',1,0,0),(5101,'2014-05-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Bus monthly fee',1,0,0),(5102,'2014-05-15','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(5103,'2014-05-15','HXSAM','Paypal','Miscellaneous',-7.24,'',1,0,0),(5104,'2014-05-15','HXSAM','<Credit Card MBNA Sam>','Transfer',-25.33,'',1,0,0),(5105,'2014-05-16','HXSAM','Tempest Photos','Entertainment',-13.50,'',1,0,0),(5106,'2014-05-16','HXSAM','Tempest Photos','Entertainment',-21.00,'',1,0,0),(5107,'2014-05-16','HXSAM','Amazon','Gifts',-26.89,'Mark headphones ',1,0,0),(5108,'2014-05-16','FDMARK','Aldi','Food:Groceries',-7.36,'',1,0,0),(5109,'2014-05-16','FDMARK','Home Bargains','Food:Groceries',-15.73,'',1,0,0),(5110,'2014-05-16','FDMARK','B&M bargains','Household',-12.95,'',1,0,0),(5111,'2014-05-19','FDMARK','Tesco','Food:Groceries',-86.70,'',1,0,0),(5112,'2014-05-19','HXSAM','Burgerking','Food:Dining',-8.88,'',1,0,0),(5113,'2014-05-19','HXSAM','Cineworld','Entertainment:Days Out',-6.38,'',1,0,0),(5114,'2014-05-19','HXSAM','Cineworld','Entertainment:Days Out',-13.86,'',1,0,0),(5115,'2014-05-19','HXSAM','MandMDirect.com','Clothing:Mark',-64.46,'',1,0,0),(5116,'2014-05-19','HXSAM','<NEXTCARD>','Transfer',-169.31,'',1,0,0),(5117,'2014-05-19','NEXTCARD','<HXSAM>','Transfer',169.31,'',1,0,0),(5118,'2014-05-19','HXSAM','Prime Instant Video','Entertainment:Hobbies',-5.99,'',1,0,0),(5119,'2014-05-19','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-9.12,'',1,0,0),(5120,'2014-05-19','HXSAM','McDonalds','Food:Dining',-5.48,'',1,0,0),(5121,'2014-05-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(5122,'2014-05-20','FDMARK','ParentPay','Entertainment:Days Out',-15.80,'',1,0,0),(5123,'2014-05-21','FDMARK','Aldi','Food:Groceries',-7.09,'',1,0,0),(5124,'2014-05-21','HXSAM','Paypal','Miscellaneous',-19.41,'',1,0,0),(5125,'2014-05-22','HXSAM','Paypal','Miscellaneous',-17.20,'',1,0,0),(5126,'2014-05-22','HXSAM','Paypal','Miscellaneous',-4.19,'',1,0,0),(5127,'2014-05-23','FDMARK','Sainsbury\'s','Food:Groceries',-17.09,'',1,0,0),(5128,'2014-05-23','HXSAM','Banardos','Clothing:Sam',-6.47,'',1,0,0),(5129,'2014-05-23','HXSAM','Amazon','Gifts',-16.99,'',1,0,0),(5130,'2014-05-23','HXSAM','Paypal','Miscellaneous',-12.70,'',1,0,0),(5131,'2014-05-23','HXSAM','Weekly Cash - Sam','Cash:Regular',-10.00,'',1,0,0),(5132,'2014-05-24','HXSAM','<FDMARK>','Transfer',100.00,'',1,0,0),(5133,'2014-05-24','FDMARK','<HXSAM>','Transfer',-100.00,'',1,0,0),(5134,'2014-05-24','HXSAM','Cash','Cash',-40.00,'',1,0,0),(5135,'2014-05-26','FDMARK','O2','Bills:Mobile Phones',-38.65,'Mark\'s iPhone ',1,0,0),(5136,'2014-05-27','FDMARK','Aviva','Salary',3965.00,'',1,0,0),(5137,'2014-05-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',1000.00,'',1,0,0),(5138,'2014-05-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1000.00,'',1,0,0),(5139,'2014-05-27','HXSAM','DGS/RPP DD','Bills:Insurance',-11.59,'',1,0,0),(5140,'2014-05-27','RAINYDAY','<FDMARK>','Transfer',600.00,'',1,0,0),(5141,'2014-05-27','FDMARK','<RAINYDAY>','Transfer',-600.00,'',1,0,0),(5142,'2014-05-27','FDMARK','<Credit Card BARCLAYCARD>','Transfer',-600.00,'',1,0,0),(5143,'2014-05-27','HXSAM','<RAINYDAY>','Entertainment:Holidays',2408.00,'',1,0,0),(5144,'2014-05-27','RAINYDAY','<HXSAM>','Entertainment:Holidays',-2408.00,'',1,0,0),(5145,'2014-05-27','HXSAM','Chiquitos','Food:Dining',-38.30,'',1,0,0),(5146,'2014-05-27','HXSAM','Apple ITunes','Entertainment:Hobbies',-2.98,'',1,0,0),(5147,'2014-05-27','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-3.32,'',1,0,0),(5148,'2014-05-27','HXSAM','Cineworld','Entertainment:Days Out',-15.66,'',1,0,0),(5149,'2014-05-28','HXSAM','Home Bargains','Food:Groceries',-17.82,'',1,0,0),(5150,'2014-05-28','FDMARK','Tesco','Food:Groceries',-107.20,'',1,0,0),(5151,'2014-05-28','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(5152,'2014-05-28','FDMARK','Pret A Manger','Food',-7.34,'',1,0,0),(5153,'2014-05-28','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(5154,'2014-05-28','HXSAM','Cosmos Holidays','Entertainment:Holidays',-2408.88,'',1,0,0),(5155,'2014-05-28','FDMARK','Tesco Garage','Bills:Motor',-65.38,'Petrol - Golf',1,0,0),(5156,'2014-05-28','FDMARK','Pinn Insure Plc','Insurance',-7.47,'',1,0,0),(5157,'2014-05-28','HXSAM','Apple ITunes','Entertainment:Hobbies',-10.00,'',1,0,0),(5158,'2014-05-29','HXSAM','River Island','Clothing',-21.00,'',1,0,0),(5159,'2014-05-29','FDMARK','Rowlands Pharmacy','Bills:Prescriptions',-8.05,'',1,0,0),(5160,'2014-05-29','HXSAM','Cash','Cash',-50.00,'',1,0,0),(5161,'2014-05-29','FDMARK','Tesco Garage','Bills:Motor',-68.18,'BMW ',1,0,0),(5162,'2014-05-29','HXSAM','Wh Smith','Books',-14.95,'',1,0,0),(5163,'2014-05-29','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-3.67,'',1,0,0),(5164,'2014-05-29','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-5.97,'',1,0,0),(5165,'2014-05-30','HXSAM','Selby College','Salary',456.18,'Sam salary',1,0,0),(5166,'2014-05-31','FORTHEFUTURE','First Direct','Interest',0.32,'',1,0,0),(5167,'2014-05-31','HXSAM','Sports Direct','Clothing',-134.11,'',1,0,0),(5168,'2014-06-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-428.81,'Mortgage payment',1,0,0),(5169,'2014-06-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(5170,'2014-06-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(5171,'2014-06-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(5172,'2014-06-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(5173,'2014-06-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-154.00,'',1,0,0),(5174,'2014-06-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(5175,'2014-06-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(5176,'2014-06-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(5177,'2014-06-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(5178,'2014-06-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(5179,'2014-06-01','HXSAM','DGS/RPP DD','Bills:Insurance',-6.74,'Dishwasher cover',1,0,0),(5180,'2014-06-02','FDMARK','Tesco','Food:Groceries',-98.76,'',1,0,0),(5181,'2014-06-02','HXSAM','Cash','Cash',-20.00,'',1,0,0),(5182,'2014-06-02','HXSAM','Argos','Household',-35.99,'',1,0,0),(5183,'2014-06-02','HXSAM','EE & T-Mobile','Bills:Mobile Phones',-10.00,'',1,0,0),(5184,'2014-06-02','HXSAM','Sainsbury\'s','Clothing',-20.00,'',1,0,0),(5185,'2014-06-02','HXSAM','Boots','Medical',-21.36,'',1,0,0),(5186,'2014-06-02','HXSAM','Frankie & Benny\'s','Food:Dining',-26.65,'',1,0,0),(5187,'2014-06-03','HXSAM','Primark','Clothing',-63.00,'',1,0,0),(5188,'2014-06-03','HXSAM','Primark','Clothing',-60.00,'',1,0,0),(5189,'2014-06-03','FDMARK','Tesco Garage','Food:Groceries',-18.48,'',1,0,0),(5190,'2014-06-03','HXSAM','Paypal','Clothing',-11.00,'',1,0,0),(5191,'2014-06-04','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(5192,'2014-06-04','HXSAM','Paypal','Clothing',-32.98,'Cat bed',1,0,0),(5193,'2014-06-04','RAINYDAY','<FDMARK>','Transfer',-1000.00,'',1,0,0),(5194,'2014-06-04','FDMARK','<RAINYDAY>','Transfer',1000.00,'',1,0,0),(5195,'2014-06-04','HXSAM','Weekly Cash - Sam','Cash:Regular',-40.00,'',1,0,0),(5196,'2014-06-05','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(5197,'2014-06-05','FDMARK','BT','Bills:Utilities',-54.46,'House phone & broadband',1,0,0),(5198,'2014-06-05','FDMARK','Ambers','Home:Furniture',-663.00,'',1,0,0),(5199,'2014-06-08','HXSAM','<FDMARK>','Transfer',150.00,'',1,0,0),(5200,'2014-06-08','FDMARK','<HXSAM>','Transfer',-150.00,'',1,0,0),(5201,'2014-06-09','HXSAM','B&M bargains','Household',-31.83,'',1,0,0),(5202,'2014-06-09','HXSAM','Homebase','Household',-57.59,'',1,0,0),(5203,'2014-06-09','FDMARK','Tesco','Food:Groceries',-145.89,'',1,0,0),(5204,'2014-06-09','HXSAM','Cash','Cash',-40.00,'',1,0,0),(5205,'2014-06-09','FDMARK','Homebase','Household',-14.38,'',1,0,0),(5206,'2014-06-09','FDMARK','Ambers','Refund',140.00,'',1,0,0),(5207,'2014-06-09','NEXTCARD','','Clothing',-63.99,'',1,0,0),(5208,'2014-06-09','FDMARK','O2','Bills:Mobile Phones',-24.78,'Sam\'s iPhone ',1,0,0),(5209,'2014-06-09','HXSAM','<FDMARK>','Transfer',100.00,'',1,0,0),(5210,'2014-06-09','FDMARK','<HXSAM>','Transfer',-100.00,'',1,0,0),(5211,'2014-06-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(5212,'2014-06-09','FDMARK','Tesco Garage','Food:Groceries',-18.39,'',1,0,0),(5213,'2014-06-09','HXSAM','MandMDirect.com','Clothing:Mark',-81.63,'',1,0,0),(5214,'2014-06-10','HXSAM','Post Office Counters','Bills:Postage',-17.00,'',1,0,0),(5215,'2014-06-10','HXSAM','6th Selby Scouts','Hobbies',-6.00,'',1,0,0),(5216,'2014-06-10','HXSAM','Imagine Publishing','Entertainment:Books',-18.00,'Linux magazine',1,0,0),(5217,'2014-06-11','HXSAM','Amazon','Gifts',-9.99,'',1,0,0),(5218,'2014-06-11','HXSAM','Amazon','Gifts',-15.48,'',1,0,0),(5219,'2014-06-11','HXSAM','Amazon','Gifts',-19.95,'',1,0,0),(5220,'2014-06-11','HXSAM','Morrisons','Food:Groceries',-50.02,'',1,0,0),(5221,'2014-06-11','FDMARK','Homesense','Household',-39.97,'',1,0,0),(5222,'2014-06-11','FDMARK','Homebase','Household',-174.39,'',1,0,0),(5223,'2014-06-12','FDMARK','Tesco Garage','Food:Groceries',-10.68,'',1,0,0),(5224,'2014-06-12','FDMARK','Aviva CS UK Ltd','Work:Expenses',118.30,'',1,0,0),(5225,'2014-06-13','FDMARK','Pinn Insure Plc','Refund',7.47,'',1,0,0),(5226,'2014-06-13','FDMARK','Apcoa','Work:Expenses',-7.40,'',1,0,0),(5227,'2014-06-13','FDMARK','Homebase','Household',-62.55,'',1,0,0),(5228,'2014-06-13','HXSAM','Cash','Cash',-20.00,'',1,0,0),(5229,'2014-06-13','HXSAM','Paypal','Household',-83.16,'',1,0,0),(5230,'2014-06-13','HXSAM','Paypal','Household',-4.80,'',1,0,0),(5231,'2014-06-13','HXSAM','Paypal','Household',-1.99,'',1,0,0),(5232,'2014-06-13','HXSAM','<FDMARK>','Transfer',45.00,'',1,0,0),(5233,'2014-06-13','FDMARK','<HXSAM>','Transfer',-45.00,'',1,0,0),(5234,'2014-06-13','FDMARK','<Credit Card FIRST DIRECT>','Transfer',-114.50,'',1,0,0),(5235,'2014-06-16','FDMARK','Tesco','Food:Groceries',-93.12,'',1,0,0),(5236,'2014-06-16','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(5237,'2014-06-16','FDMARK','Homebase','Refund',24.99,'',1,0,0),(5238,'2014-06-16','FDMARK','Homebase','Household',-67.21,'',1,0,0),(5239,'2014-06-16','HXSAM','Home Bargains','Food:Groceries',-45.61,'',1,0,0),(5240,'2014-06-16','HXSAM','Yorkshire Trading','Hobbies',-20.98,'',1,0,0),(5241,'2014-06-16','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(5242,'2014-06-16','HXSAM','<RAINYDAY>','Transfer',530.00,'',1,0,0),(5243,'2014-06-16','RAINYDAY','<HXSAM>','Transfer',-530.00,'',1,0,0),(5244,'2014-06-16','FDMARK','Homebase','Household',-71.74,'',1,0,0),(5245,'2014-06-16','HXSAM','Carpet Right','Household',-474.63,'',1,0,0),(5246,'2014-06-16','FDMARK','Transport For London','Bills:Transport',-20.00,'',1,0,0),(5247,'2014-06-17','FDMARK','Pret A Manger','Food',-5.45,'',1,0,0),(5248,'2014-06-17','FDMARK','Homebase','Household',-19.97,'',1,0,0),(5249,'2014-06-17','HXSAM','Paypal','Clothing:Kids',-16.99,'',1,0,0),(5250,'2014-06-17','HXSAM','Cash','Cash',-70.00,'Carpet fitters',1,0,0),(5251,'2014-06-18','HXSAM','Next','Clothing',-25.00,'',1,0,0),(5252,'2014-06-18','HXSAM','Dreams','Home:Furniture',-449.00,'Bed frame',1,0,0),(5253,'2014-06-18','HXSAM','<RAINYDAY>','Transfer',450.00,'Money for bed',1,0,0),(5254,'2014-06-18','RAINYDAY','<HXSAM>','Transfer',-450.00,'Money for bed',1,0,0),(5255,'2014-06-18','HXSAM','Rowlands Pharmacy','Bills:Prescriptions',-8.05,'',1,0,0),(5256,'2014-06-18','HXSAM','Paypal','Clothing:Sam',-7.64,'',1,0,0),(5257,'2014-06-18','HXSAM','Paypal','Home',-28.00,'Curtains',1,0,0),(5258,'2014-06-18','HXSAM','Paypal','Clothing:Kids',-10.60,'',1,0,0),(5259,'2014-06-19','HXSAM','Prime Instant Video','Entertainment:Hobbies',-5.99,'',1,0,0),(5260,'2014-06-19','HXSAM','<RAINYDAY>','Transfer',80.00,'Pay for dressing table',1,0,0),(5261,'2014-06-19','RAINYDAY','<HXSAM>','Transfer',-80.00,'Pay for dressing table',1,0,0),(5262,'2014-06-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(5263,'2014-06-20','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-3.78,'',1,0,0),(5264,'2014-06-20','HXSAM','Cash','Cash',-10.00,'',1,0,0),(5265,'2014-06-20','HXSAM','<NEXTCARD>','Clothing',-36.99,'Balance of Next card',1,0,0),(5266,'2014-06-20','NEXTCARD','<HXSAM>','Clothing',36.99,'Balance of Next card',1,0,0),(5267,'2014-06-20','HXSAM','B&M bargains','Household',-5.57,'',1,0,0),(5268,'2014-06-20','FDMARK','Aldi','Food:Groceries',-16.83,'',1,0,0),(5269,'2014-06-20','HXSAM','Paypal','Home:Furniture',-82.01,'Dressing table ',1,0,0),(5270,'2014-06-20','HXSAM','Weekly Cash - Sam','Cash:Regular',-10.00,'',1,0,0),(5271,'2014-06-23','FDMARK','Tesco','Food:Groceries',-86.51,'',1,0,0),(5272,'2014-06-23','FDMARK','Aviva Accounts Rec','Work:Expenses',471.10,'',1,0,0),(5273,'2014-06-23','FDMARK','<Credit Card FIRST DIRECT>','Transfer',-459.30,'',1,0,0),(5274,'2014-06-23','HXSAM','Yorkshire Trading','Hobbies',-12.00,'',1,0,0),(5275,'2014-06-23','HXSAM','Wilkinsons','Household',-32.25,'',1,0,0),(5276,'2014-06-23','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(5277,'2014-06-23','FDMARK','Sainsbury\'s','Food:Groceries',-7.69,'',1,0,0),(5278,'2014-06-23','HXSAM','Cash','Cash',-30.00,'',1,0,0),(5279,'2014-06-23','HXSAM','Ticketmaster','Entertainment:Days Out',-36.30,'Milton jones',1,0,0),(5280,'2014-06-23','HXSAM','The Swan','Food:Dining',-11.60,'',1,0,0),(5281,'2014-06-24','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(5282,'2014-06-24','FDMARK','Pret A Manger','Food',-6.64,'',1,0,0),(5283,'2014-06-24','HXSAM','Paypal','Home:Furniture',-29.99,'Cat climber',1,0,0),(5284,'2014-06-24','HXSAM','Amazon','Gifts',-10.90,'Memory card',1,0,0),(5285,'2014-06-24','FDMARK','Tesco Garage','Bills:Motor',-67.57,'BMW ',1,0,0),(5286,'2014-06-25','HXSAM','Apple ITunes','Entertainment:Hobbies',-2.99,'',1,0,0),(5287,'2014-06-25','FDMARK','O2','Bills:Mobile Phones',-38.25,'Mark\'s iPhone ',1,0,0),(5288,'2014-06-25','FDMARK','Aldi','Food:Groceries',-9.20,'',1,0,0),(5289,'2014-06-25','HXSAM','Brantano','Clothing',-22.00,'',1,0,0),(5290,'2014-06-26','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(5291,'2014-06-26','FDMARK','Cash','Cash',-150.00,'Driveway and kittehs',1,0,0),(5292,'2014-06-26','HXSAM','Amazon Marketplace','Gifts',-16.04,'',1,0,0),(5293,'2014-06-26','HXSAM','John Greed Jewellery','Gifts',-45.00,'',1,0,0),(5294,'2014-06-27','FDMARK','Aviva','Salary',3965.00,'',1,0,0),(5295,'2014-06-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',1000.00,'',1,0,0),(5296,'2014-06-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1000.00,'',1,0,0),(5297,'2014-06-27','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-335.00,'',1,0,0),(5298,'2014-06-27','HXSAM','DGS/RPP DD','Bills:Insurance',-11.59,'',1,0,0),(5299,'2014-06-27','HXSAM','Paypal','Miscellaneous',-0.45,'Snapfish',1,0,0),(5300,'2014-06-27','HXSAM','Paypal','Miscellaneous',-4.46,'Snapfish',1,0,0),(5301,'2014-06-27','HXSAM','Paypal','Clothing:Sam',-9.98,'',1,0,0),(5302,'2014-06-27','HXSAM','Paypal','Miscellaneous',-19.20,'Snapfish',1,0,0),(5303,'2014-06-27','HXSAM','Amazon Marketplace','Gifts',-14.99,'',1,0,0),(5304,'2014-06-27','FDMARK','Tesco Garage','Food:Groceries',-11.48,'',1,0,0),(5305,'2014-06-29','NEXTCARD','','Returned Clothing',27.00,'',1,0,0),(5306,'2014-06-29','FDMARK','Patio Guy','Cash',-250.00,'',1,0,0),(5307,'2014-06-30','FDMARK','Tesco','Food:Groceries',-139.09,'',1,0,0),(5308,'2014-06-30','NEXTCARD','','Clothing',-25.99,'',1,0,0),(5309,'2014-06-30','FORTHEFUTURE','First Direct','Interest',0.32,'',1,0,0),(5310,'2014-06-30','HXSAM','Wilkinsons','Refund',4.69,'',1,0,0),(5311,'2014-06-30','HXSAM','Cineworld','Entertainment:Days Out',-19.89,'',1,0,0),(5312,'2014-06-30','HXSAM','Cineworld','Entertainment:Days Out',-12.56,'',1,0,0),(5313,'2014-06-30','HXSAM','Selby College','Salary',344.42,'Sam salary',1,0,0),(5314,'2014-06-30','HXSAM','Jolleys Pet Food','Pets',-11.95,'',1,0,0),(5315,'2014-06-30','HXSAM','Jolleys Pet Food','Pets',-13.82,'',1,0,0),(5316,'2014-06-30','HXSAM','Sainsbury\'s','Food:Groceries',-12.50,'',1,0,0),(5317,'2014-06-30','HXSAM','Hunters','Beauty:Haircut',-56.00,'',1,0,0),(5318,'2014-07-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-422.71,'Mortgage payment',1,0,0),(5319,'2014-07-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(5320,'2014-07-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(5321,'2014-07-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(5322,'2014-07-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(5323,'2014-07-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-154.00,'',1,0,0),(5324,'2014-07-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(5325,'2014-07-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(5326,'2014-07-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(5327,'2014-07-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(5328,'2014-07-01','FDMARK','Pret A Manger','Food',-6.80,'',1,0,0),(5329,'2014-07-01','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(5330,'2014-07-01','FDMARK','Home Bargains','Food:Groceries',-29.72,'',1,0,0),(5331,'2014-07-01','FDMARK','Aldi','Food:Groceries',-6.10,'',1,0,0),(5332,'2014-07-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(5333,'2014-07-01','HXSAM','The Owl Hotel','Food:Dining',-46.28,'',1,0,0),(5334,'2014-07-01','HXSAM','DGS/RPP DD','Bills:Insurance',-6.74,'Dishwasher cover',1,0,0),(5335,'2014-07-02','HXSAM','Ibis','Entertainment:Days Out',-95.95,'',1,0,0),(5336,'2014-07-02','FDMARK','B&M bargains','Household',-19.73,'',1,0,0),(5337,'2014-07-02','HXSAM','Paypal','Miscellaneous',-13.12,'',1,0,0),(5338,'2014-07-02','HXSAM','Greenthumb','Garden',-16.00,'',1,0,0),(5339,'2014-07-02','HXSAM','Wilkinsons','Food:Groceries',-14.10,'',1,0,0),(5340,'2014-07-02','HXSAM','Sainsbury\'s','Food:Groceries',-16.50,'',1,0,0),(5341,'2014-07-02','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(5342,'2014-07-03','HXSAM','Jolleys Pet Food','Pets',-20.98,'',1,0,0),(5343,'2014-07-03','HXSAM','Boots','Medical',-6.99,'',1,0,0),(5344,'2014-07-03','HXSAM','B&M bargains','Household',-31.79,'',1,0,0),(5345,'2014-07-03','HXSAM','Paypal','Miscellaneous',-4.75,'',1,0,0),(5346,'2014-07-03','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-2.49,'',1,0,0),(5347,'2014-07-03','HXSAM','Amazon Marketplace','Gifts',-5.69,'',1,0,0),(5348,'2014-07-04','FDMARK','Aviva Healthcare','Bills:Insurance',-63.09,'Health insurance',1,0,0),(5349,'2014-07-07','FDMARK','Tesco','Food:Groceries',-146.16,'',1,0,0),(5350,'2014-07-07','HXSAM','Paperchase','Gifts',-9.50,'',1,0,0),(5351,'2014-07-07','HXSAM','Sainsbury\'s','Household',-21.00,'Cocktail stuff',1,0,0),(5352,'2014-07-07','HXSAM','Dorothy Perkins','Clothing:Sam',-46.00,'',1,0,0),(5353,'2014-07-07','HXSAM','Wh Smith','Books',-4.98,'',1,0,0),(5354,'2014-07-07','HXSAM','Bhs','Clothing',-78.00,'',1,0,0),(5355,'2014-07-07','HXSAM','Love You Hair & Beauty','Beauty',-24.50,'',1,0,0),(5356,'2014-07-07','HXSAM','Morrisons','Food:Groceries',-70.38,'',1,0,0),(5357,'2014-07-07','HXSAM','EE & T-Mobile','Bills:Mobile Phones',-10.00,'',1,0,0),(5358,'2014-07-07','HXSAM','Pets At Home','Pets',-9.00,'',1,0,0),(5359,'2014-07-07','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(5360,'2014-07-07','FDMARK','BT','Bills:Utilities',-48.28,'House phone & broadband',1,0,0),(5361,'2014-07-07','HXSAM','Weekly Cash - Mark','Cash:Regular',-50.00,'',1,0,0),(5362,'2014-07-08','HXSAM','Primark','Clothing',-97.40,'',1,0,0),(5363,'2014-07-08','HXSAM','Amazon Marketplace','Gifts',-30.30,'',1,0,0),(5364,'2014-07-08','FDMARK','Tesco Garage','Bills:Motor',-58.42,'Petrol - Golf',1,0,0),(5365,'2014-07-08','FDMARK','Aviva Accounts Rec','Work:Expenses',341.75,'',1,0,0),(5366,'2014-07-08','FDMARK','<Credit Card FIRST DIRECT>','Transfer',-334.15,'',1,0,0),(5367,'2014-07-09','FDMARK','Tesco Garage','Food:Groceries',-7.84,'',1,0,0),(5368,'2014-07-09','HXSAM','Hmv','Gifts',-40.98,'',1,0,0),(5369,'2014-07-09','HXSAM','Travel Ins-ancile','Insurance',-32.55,'',1,0,0),(5370,'2014-07-09','HXSAM','<FDMARK>','Transfer',100.00,'',1,0,0),(5371,'2014-07-09','FDMARK','<HXSAM>','Transfer',-100.00,'',1,0,0),(5372,'2014-07-09','FDMARK','O2','Bills:Mobile Phones',-23.23,'Sam\'s iPhone ',1,0,0),(5373,'2014-07-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(5374,'2014-07-10','HXSAM','Marks & Spencer','Food',-14.95,'',1,0,0),(5375,'2014-07-10','FDMARK','Wh Smith','Books',-5.99,'',1,0,0),(5376,'2014-07-10','HXSAM','New Look','Clothing',-20.50,'',1,0,0),(5377,'2014-07-10','HXSAM','Marks & Spencer','Clothing',-20.00,'',1,0,0),(5378,'2014-07-10','HXSAM','Clintons','Gifts',-15.93,'',1,0,0),(5379,'2014-07-10','FDMARK','Sainsbury\'s','Household',-3.35,'',1,0,0),(5380,'2014-07-10','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(5381,'2014-07-12','RAINYDAY','<FDMARK>','Transfer',-80.00,'',1,0,0),(5382,'2014-07-12','FDMARK','<RAINYDAY>','Transfer',80.00,'',1,0,0),(5383,'2014-07-12','HXSAM','<RAINYDAY>','Transfer',50.00,'',1,0,0),(5384,'2014-07-12','RAINYDAY','<HXSAM>','Transfer',-50.00,'',1,0,0),(5385,'2014-07-14','FDMARK','Tesco','Food:Groceries',-107.20,'',1,0,0),(5386,'2014-07-14','HXSAM','Cineworld','Entertainment:Days Out',-16.66,'',1,0,0),(5387,'2014-07-14','HXSAM','Chiquitos','Food:Dining',-58.00,'',1,0,0),(5388,'2014-07-14','FDMARK','Tesco Garage','Food:Groceries',-9.70,'',1,0,0),(5389,'2014-07-14','HXSAM','Banardos','Gifts',-9.97,'',1,0,0),(5390,'2014-07-14','HXSAM','Hunters','Beauty:Haircut',-14.00,'',1,0,0),(5391,'2014-07-14','HXSAM','The Range','Household',-81.10,'',1,0,0),(5392,'2014-07-14','FDMARK','Manchester Airport T1','Entertainment:Holidays',-51.48,'Parking',1,0,0),(5393,'2014-07-14','FDMARK','Caxton Fx','Entertainment:Holidays',-10.00,'',1,0,0),(5394,'2014-07-14','HXSAM','Amazon','Gifts',-24.60,'Stuart gifts',1,0,0),(5395,'2014-07-14','HXSAM','Amazon','Gifts',-5.15,'',1,0,0),(5396,'2014-07-14','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(5397,'2014-07-14','FDMARK','Tesco Garage','Food:Groceries',-11.99,'',1,0,0),(5398,'2014-07-14','FDMARK','Tesco Garage','Bills:Motor',-66.73,'BMW ',1,0,0),(5399,'2014-07-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Bus monthly fee',1,0,0),(5400,'2014-07-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Bus monthly fee',1,0,0),(5401,'2014-07-15','FDMARK','Sainsbury\'s','Food:Groceries',-5.64,'',1,0,0),(5402,'2014-07-15','FDMARK','Aldi','Food:Groceries',-13.64,'',1,0,0),(5403,'2014-07-15','HXSAM','Homebase','Household',-75.76,'',1,0,0),(5404,'2014-07-15','HXSAM','<RAINYDAY>','Transfer',80.00,'',1,0,0),(5405,'2014-07-15','RAINYDAY','<HXSAM>','Transfer',-80.00,'',1,0,0),(5406,'2014-07-16','FDMARK','Sainsbury\'s','Food:Groceries',-11.18,'',1,0,0),(5407,'2014-07-17','FDMARK','E.On','Refund',73.47,'',1,0,0),(5408,'2014-07-17','FDMARK','Tesco Garage','Food:Groceries',-4.18,'',1,0,0),(5409,'2014-07-18','FDMARK','B&M bargains','Household',-8.92,'',1,0,0),(5410,'2014-07-18','HXSAM','Dreams','Home:Furniture',-179.00,'',1,0,0),(5411,'2014-07-18','HXSAM','<RAINYDAY>','Transfer',180.00,'Pay for Harvey\'s bed',1,0,0),(5412,'2014-07-18','RAINYDAY','<HXSAM>','Transfer',-180.00,'Pay for Harvey\'s bed',1,0,0),(5413,'2014-07-19','HXSAM','Cash','Cash',-50.00,'',1,0,0),(5414,'2014-07-20','HXSAM','<RAINYDAY>','Transfer',280.00,'',1,0,0),(5415,'2014-07-20','RAINYDAY','<HXSAM>','Transfer',-280.00,'',1,0,0),(5416,'2014-07-20','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(5417,'2014-07-21','FDMARK','Tesco','Food:Groceries',-122.39,'',1,0,0),(5418,'2014-07-21','HXSAM','Home Bargains','Food:Groceries',-22.46,'',1,0,0),(5419,'2014-07-21','HXSAM','Love You Hair & Beauty','Beauty',-17.50,'',1,0,0),(5420,'2014-07-21','HXSAM','Selby Carpets','Home:Decorations',-280.00,'',1,0,0),(5421,'2014-07-21','HXSAM','B&M bargains','Household',-6.49,'',1,0,0),(5422,'2014-07-21','HXSAM','Weatherills','Clothing:Sam',-14.00,'',1,0,0),(5423,'2014-07-21','HXSAM','Prime Instant Video','Entertainment:Hobbies',-5.99,'',1,0,0),(5424,'2014-07-21','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(5425,'2014-07-21','HXSAM','Amazon','Gifts',-13.88,'',1,0,0),(5426,'2014-07-22','FDMARK','Home Bargains','Food:Groceries',-19.71,'',1,0,0),(5427,'2014-07-22','FDMARK','ParentPay','Entertainment:Days Out',-4.20,'',1,0,0),(5428,'2014-07-22','HXSAM','Amazon','Gifts',-10.00,'',1,0,0),(5429,'2014-07-22','HXSAM','Wh Smith','Books',-28.99,'',1,0,0),(5430,'2014-07-22','HXSAM','Weatherills','Clothing:Sam',-7.50,'',1,0,0),(5431,'2014-07-23','FDMARK','Tesco Garage','Food:Groceries',-7.75,'',1,0,0),(5432,'2014-07-23','HXSAM','Amazon','Refund',0.01,'',1,0,0),(5433,'2014-07-23','HXSAM','Amazon','Household',-21.90,'',1,0,0),(5434,'2014-07-23','HXSAM','Learnable','Entertainment:Hobbies',-5.28,'',1,0,0),(5435,'2014-07-23','HXSAM','Non-stg Trans Fee','Bills:Banking',-0.14,'',1,0,0),(5436,'2014-07-23','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',1,0,0),(5437,'2014-07-24','FDMARK','Tesco Garage','Food:Groceries',-10.12,'',1,0,0),(5438,'2014-07-25','FDMARK','Aviva','Salary',3946.00,'',1,0,0),(5439,'2014-07-25','HXSAM','<FDMARK>','Transfer:Monthly Spends',1000.00,'',1,0,0),(5440,'2014-07-25','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1000.00,'',1,0,0),(5441,'2014-07-25','HXSAM','New Look','Clothing',-22.98,'',1,0,0),(5442,'2014-07-25','FDMARK','O2','Bills:Mobile Phones',-38.46,'Mark\'s iPhone ',1,0,0),(5443,'2014-07-25','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-335.00,'',1,0,0),(5444,'2014-07-27','HXSAM','DGS/RPP DD','Bills:Insurance',-11.59,'',1,0,0),(5445,'2014-07-28','FDMARK','Tesco','Food:Groceries',-124.14,'',1,0,0),(5446,'2014-07-28','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(5447,'2014-07-28','HXSAM','Cosmic','Gifts',-33.98,'Aimee\'s bag & Harvey\'s pig',1,0,0),(5448,'2014-07-28','HXSAM','Dolphin Fish N Chips','Food:Dining',-25.50,'',1,0,0),(5449,'2014-07-28','HXSAM','Homebase','Household',-24.81,'',1,0,0),(5450,'2014-07-28','HXSAM','Jolleys Pet Food','Pets',-18.98,'',1,0,0),(5451,'2014-07-28','FDMARK','B&M bargains','Household',-10.34,'',1,0,0),(5452,'2014-07-28','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.99,'',1,0,0),(5453,'2014-07-28','HXSAM','Homebase','Refund',19.82,'',1,0,0),(5454,'2014-07-28','HXSAM','Post Office Counters','Bills:Postage',-4.85,'',1,0,0),(5455,'2014-07-28','FDMARK','Tesco Garage','Bills:Motor',-63.65,'BMW ',1,0,0),(5456,'2014-07-29','HXSAM','MandMDirect.com','Clothing:Mark',-65.43,'',1,0,0),(5457,'2014-07-29','HXSAM','John Greed Jewellery','Gifts',-45.00,'',1,0,0),(5458,'2014-07-29','FDMARK','Tesco Garage','Food:Groceries',-9.02,'',1,0,0),(5459,'2014-07-29','HXSAM','Amazon','Clothing',-23.97,'',1,0,0),(5460,'2014-07-29','HXSAM','Apple ITunes','Entertainment:Hobbies',-8.10,'',1,0,0),(5461,'2014-07-30','FDMARK','Aldi','Food:Groceries',-15.63,'',1,0,0),(5462,'2014-07-30','HXSAM','Amazon','Clothing',-13.98,'',1,0,0),(5463,'2014-07-30','HXSAM','Amazon','Household',-63.34,'Telephones',1,0,0),(5464,'2014-07-31','FORTHEFUTURE','First Direct','Interest',0.32,'',1,0,0),(5465,'2014-07-31','HXSAM','Selby College','Salary',344.42,'Sam salary',1,0,0),(5466,'2014-07-31','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.75,'',1,0,0),(5467,'2014-08-01','HXSAM','Amazon','Household',-73.98,'',1,0,0),(5468,'2014-08-01','HXSAM','Pet Health Plan','Insurance',-10.00,'',1,0,0),(5469,'2014-08-01','HXSAM','Pet Health Plan','Insurance',-38.41,'',1,0,0),(5470,'2014-08-01','FDMARK','Rowlands Pharmacy','Bills:Prescriptions',-8.05,'',1,0,0),(5471,'2014-08-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-422.71,'Mortgage payment',1,0,0),(5472,'2014-08-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(5473,'2014-08-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(5474,'2014-08-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(5475,'2014-08-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(5476,'2014-08-01','HXSAM','<RAINYDAY>','Cash',800.00,'Spends',1,0,0),(5477,'2014-08-01','RAINYDAY','<HXSAM>','Cash',-800.00,'Spends',1,0,0),(5478,'2014-08-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-154.00,'',1,0,0),(5479,'2014-08-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(5480,'2014-08-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(5481,'2014-08-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(5482,'2014-08-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(5483,'2014-08-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(5484,'2014-08-01','HXSAM','DGS/RPP DD','Bills:Insurance',-6.74,'Dishwasher cover',1,0,0),(5485,'2014-08-04','HXSAM','Neulion/NFL','Hobbies',-33.49,'',1,0,0),(5486,'2014-08-04','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-1.99,'',1,0,0),(5487,'2014-08-04','HXSAM','Home Bargains','Food:Groceries',-15.96,'',1,0,0),(5488,'2014-08-04','HXSAM','Boots','Medical',-35.28,'',1,0,0),(5489,'2014-08-04','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-7.65,'',1,0,0),(5490,'2014-08-04','HXSAM','Caxton Fx','Entertainment:Holidays',-668.00,'',1,0,0),(5491,'2014-08-04','FDMARK','Morrisons','Food:Groceries',-78.91,'',1,0,0),(5492,'2014-08-04','HXSAM','<NEXTCARD>','Transfer',-5.00,'',1,0,0),(5493,'2014-08-04','NEXTCARD','<HXSAM>','Transfer',5.00,'',1,0,0),(5494,'2014-08-04','HXSAM','Dorothy Perkins','Clothing:Sam',-36.00,'',1,0,0),(5495,'2014-08-04','HXSAM','Wh Smith','Books',-27.14,'',1,0,0),(5496,'2014-08-04','FDMARK','Tesco','Food:Groceries',-75.39,'',1,0,0),(5497,'2014-08-04','FDMARK','Tesco Garage','Food:Groceries',-9.24,'',1,0,0),(5498,'2014-08-04','NEXTCARD','Next','Service Charge',-0.67,'',1,0,0),(5499,'2014-08-05','HXSAM','Thomas Cook','Entertainment:Holidays',-132.47,'',1,0,0),(5500,'2014-08-05','HXSAM','Love You Hair & Beauty','Beauty',-32.50,'',1,0,0),(5501,'2014-08-05','HXSAM','Love You Hair & Beauty','Beauty',-28.50,'',1,0,0),(5502,'2014-08-05','HXSAM','Travel Ins-ancile','Refund',13.31,'',1,0,0),(5503,'2014-08-05','HXSAM','Amazon EU','Gifts',-0.61,'',1,0,0),(5504,'2014-08-05','HXSAM','Post Office Counters','Bills:Postage',-1.24,'',1,0,0),(5505,'2014-08-05','HXSAM','Amazon Marketplace','Gifts',-4.50,'',1,0,0),(5506,'2014-08-05','HXSAM','Amazon EU','Gifts',-21.00,'',1,0,0),(5507,'2014-08-05','HXSAM','Weekly Cash - Sam','Cash:Regular',-40.00,'',1,0,0),(5508,'2014-08-06','FDMARK','Insure & Go','Insurance',-27.00,'',1,0,0),(5509,'2014-08-06','FDMARK','Insure & Go','Insurance',-27.00,'',1,0,0),(5510,'2014-08-06','HXSAM','Guides','Hobbies',-20.00,'',1,0,0),(5511,'2014-08-06','HXSAM','Cineworld','Entertainment:Days Out',-16.89,'',1,0,0),(5512,'2014-08-06','HXSAM','Boots','Medical',-5.69,'',1,0,0),(5513,'2014-08-06','HXSAM','J D Sports','Clothing',-12.00,'',1,0,0),(5514,'2014-08-06','HXSAM','Waterstones','Gifts',-35.97,'',1,0,0),(5515,'2014-08-06','FDMARK','Aviva Healthcare','Bills:Insurance',-65.14,'Health insurance',1,0,0),(5516,'2014-08-06','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(5517,'2014-08-06','FDMARK','BT','Bills:Utilities',-47.37,'House phone & broadband',1,0,0),(5518,'2014-08-07','FDMARK','Aviva CS UK Ltd','Work:Expenses',161.50,'',1,0,0),(5519,'2014-08-08','FDMARK','O2','Bills:Mobile Phones',-35.22,'Sam\'s iPhone ',1,0,0),(5520,'2014-08-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(5521,'2014-08-11','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-9.47,'',1,0,0),(5522,'2014-08-11','NEXTCARD','Next','Clothing : Aimee',-48.00,'',1,0,0),(5523,'2014-08-11','NEXTCARD','Next','Clothing : Sam',-105.00,'',1,0,0),(5524,'2014-08-11','NEXTCARD','Next','Clothing:Mark',-72.00,'',1,0,0),(5525,'2014-08-11','NEXTCARD','Next','Clothing : Harvey',-82.50,'',1,0,0),(5526,'2014-08-11','NEXTCARD','Next','Household',-73.00,'',1,0,0),(5527,'2014-08-11','NEXTCARD','Next','Delivery Charge',-31.68,'',1,0,0),(5528,'2014-08-11','NEXTCARD','Next','Returned Clothing',-10.00,'',1,0,0),(5529,'2014-08-14','HXSAM','Alpha Lsg','Miscellaneous',-25.60,'',1,0,0),(5530,'2014-08-14','HXSAM','Anjoca C.-bluemoon','Entertainment:Holidays',-29.61,'',1,0,0),(5531,'2014-08-14','HXSAM','Non-stg Trans Fee','Bills:Banking',-0.81,'',1,0,0),(5532,'2014-08-14','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',1,0,0),(5533,'2014-08-14','HXSAM','Sheraton','Entertainment:Holidays',-44.62,'',1,0,0),(5534,'2014-08-14','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',1,0,0),(5535,'2014-08-14','HXSAM','Non-stg Trans Fee','Bills:Banking',-1.22,'',1,0,0),(5536,'2014-08-14','FDMARK','<Credit Card FIRST DIRECT>','Transfer',-161.50,'',1,0,0),(5537,'2014-08-14','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(5538,'2014-08-14','HXSAM','Weekly Cash - Sam','Cash:Regular',-50.00,'',1,0,0),(5539,'2014-08-15','HXSAM','Three','Bills:Mobile Phones',-10.00,'',1,0,0),(5540,'2014-08-15','HXSAM','First/Keolis Trans','Entertainment:Days Out',-87.00,'Wembley trains',1,0,0),(5541,'2014-08-15','FDMARK','Tesco','Food:Groceries',-131.52,'',1,0,0),(5542,'2014-08-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Bus monthly fee',1,0,0),(5543,'2014-08-16','HXSAM','<RAINYDAY>','Transfer',100.00,'',1,0,0),(5544,'2014-08-16','RAINYDAY','<HXSAM>','Transfer',-100.00,'',1,0,0),(5545,'2014-08-18','HXSAM','Boots','Medical',-3.51,'',1,0,0),(5546,'2014-08-18','HXSAM','Wh Smith','Books',-16.97,'',1,0,0),(5547,'2014-08-18','HXSAM','Wilkinsons','Food:Groceries',-12.75,'',1,0,0),(5548,'2014-08-18','FDMARK','Classroom Clothing','Clothing',-153.70,'',1,0,0),(5549,'2014-08-18','HXSAM','B&M bargains','Household',-25.75,'',1,0,0),(5550,'2014-08-19','HXSAM','Prime Instant Video','Entertainment:Hobbies',-5.99,'',1,0,0),(5551,'2014-08-19','HXSAM','Paypal','Miscellaneous',-12.43,'',1,0,0),(5552,'2014-08-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(5553,'2014-08-20','HXSAM','Boots','Medical',-3.51,'',1,0,0),(5554,'2014-08-21','FDMARK','Aldi','Food:Groceries',-16.31,'',1,0,0),(5555,'2014-08-21','HXSAM','McDonalds','Food:Dining',-28.89,'',1,0,0),(5556,'2014-08-21','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(5557,'2014-08-22','FDMARK','Tesco','Food:Groceries',-111.98,'',1,0,0),(5558,'2014-08-22','HXSAM','Cineworld','Entertainment:Days Out',-18.67,'',1,0,0),(5559,'2014-08-22','FDMARK','Tesco Garage','Bills:Motor',-62.88,'Petrol - Golf',1,0,0),(5560,'2014-08-23','HXSAM','Cash','Cash',-40.00,'',1,0,0),(5561,'2014-08-26','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(5562,'2014-08-26','FDMARK','Tesco Express','Food:Groceries',-30.06,'',1,0,0),(5563,'2014-08-26','HXSAM','Love You Hair & Beauty','Beauty',-19.00,'',1,0,0),(5564,'2014-08-26','FDMARK','Park & Ride','Bills:Transport',-25.00,'',1,0,0),(5565,'2014-08-26','HXSAM','Learnable','Entertainment:Hobbies',-5.43,'',1,0,0),(5566,'2014-08-26','HXSAM','Non-stg Trans Fee','Bills:Banking',-0.14,'',1,0,0),(5567,'2014-08-26','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',1,0,0),(5568,'2014-08-26','HXSAM','Home Bargains','Food:Groceries',-19.11,'',1,0,0),(5569,'2014-08-26','FDMARK','Tesco Express','Food:Groceries',-22.35,'',1,0,0),(5570,'2014-08-26','HXSAM','Frankie & Benny\'s','Food:Dining',-49.65,'',1,0,0),(5571,'2014-08-26','FDMARK','O2','Bills:Mobile Phones',-46.36,'Mark\'s iPhone ',1,0,0),(5572,'2014-08-27','FDMARK','Aviva','Salary',3946.00,'',1,0,0),(5573,'2014-08-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',1200.00,'',1,0,0),(5574,'2014-08-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1200.00,'',1,0,0),(5575,'2014-08-27','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-335.00,'',1,0,0),(5576,'2014-08-27','HXSAM','DGS/RPP DD','Bills:Insurance',-11.59,'',1,0,0),(5577,'2014-08-27','FDMARK','Tesco Express','Food:Groceries',-10.80,'',1,0,0),(5578,'2014-08-27','FDMARK','Jolleys Pet Food','Pets',-13.98,'',1,0,0),(5579,'2014-08-27','HXSAM','Paypal','Miscellaneous',-8.70,'',1,0,0),(5580,'2014-08-27','HXSAM','Paypal','Miscellaneous',-10.00,'',1,0,0),(5581,'2014-08-27','HXSAM','<RAINYDAY>','Transfer',300.00,'',1,0,0),(5582,'2014-08-27','RAINYDAY','<HXSAM>','Transfer',-300.00,'',1,0,0),(5583,'2014-08-28','HXSAM','Paypal','Miscellaneous',-11.75,'',1,0,0),(5584,'2014-08-28','FDMARK','Cattery','Entertainment:Holidays',-120.00,'',1,0,0),(5585,'2014-08-28','HXSAM','McDonalds','Food:Dining',-12.07,'',1,0,0),(5586,'2014-08-28','HXSAM','Brantano','Clothing',-63.35,'',1,0,0),(5587,'2014-08-28','HXSAM','DW Fitness','Clothing',-54.95,'',1,0,0),(5588,'2014-08-28','HXSAM','Wh Smith','Books',-18.45,'',1,0,0),(5589,'2014-08-28','HXSAM','<NEXTCARD>','Clothing',-481.57,'Balance of Next card',1,0,0),(5590,'2014-08-28','NEXTCARD','<HXSAM>','Clothing',481.57,'Balance of Next card',1,0,0),(5591,'2014-08-29','HXSAM','Cash','Cash',-100.00,'',1,0,0),(5592,'2014-08-29','HXSAM','Tesco Express','Food:Groceries',-12.99,'',1,0,0),(5593,'2014-08-29','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(5594,'2014-08-29','NEXTCARD','Next','Clothing ',-11.00,'',1,0,0),(5595,'2014-08-29','NEXTCARD','Returns','',10.06,'',1,0,0),(5924,'2014-11-17','FDMARK','Tesco Express','Food:Groceries',-9.98,'',1,0,0),(5597,'2014-08-29','NEXTCARD','Next','',100.00,'',1,0,0),(5598,'2014-08-29','NEXTCARD','Next','',100.00,'',1,0,0),(5600,'2014-08-29','HXSAM','Selby College','Salary',344.42,'Sam salary',1,0,0),(5601,'2014-08-30','NEXTCARD','Returns','',-92.00,'',1,0,0),(5602,'2014-08-30','NEXTCARD','Next','Returned Clothing',92.00,'',1,0,0),(5603,'2014-08-31','FORTHEFUTURE','First Direct','Interest',0.32,'',1,0,0),(5604,'2014-09-01','FDMARK','Tesco','Food:Groceries',-86.70,'',1,0,0),(5605,'2014-09-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-422.71,'Mortgage payment',1,0,0),(5606,'2014-09-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(5607,'2014-09-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(5608,'2014-09-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(5609,'2014-09-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(5610,'2014-09-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-154.00,'',1,0,0),(5611,'2014-09-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(5612,'2014-09-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(5613,'2014-09-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(5614,'2014-09-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(5615,'2014-09-01','HXSAM','Pet Health Plan','Insurance',-18.98,'',1,0,0),(5616,'2014-09-01','HXSAM','Apple ITunes','Entertainment:Hobbies',-29.99,'',1,0,0),(5617,'2014-09-01','HXSAM','Wh Smith','Books',-12.47,'',1,0,0),(5618,'2014-09-01','HXSAM','Cineworld','Entertainment:Days Out',-16.66,'',1,0,0),(5619,'2014-09-01','HXSAM','EC Mainline','Entertainment:Days Out',-19.00,'',1,0,0),(5620,'2014-09-01','HXSAM','EC Mainline','Entertainment:Days Out',-29.00,'',1,0,0),(5621,'2014-09-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(5622,'2014-09-01','HXSAM','York Maze','Entertainment:Days Out',-47.50,'',1,0,0),(5623,'2014-09-01','HXSAM','Owl Hotel','Food:Dining',-62.05,'',1,0,0),(5624,'2014-09-01','HXSAM','Home Bargains','Food:Groceries',-41.56,'',1,0,0),(5625,'2014-09-01','HXSAM','EE & T-Mobile','Bills:Mobile Phones',-10.00,'',1,0,0),(5626,'2014-09-01','HXSAM','Paypal','Miscellaneous',-1.79,'',1,0,0),(5627,'2014-09-01','HXSAM','Paypal','Miscellaneous',-6.64,'',1,0,0),(5628,'2014-09-01','FDMARK','Aldi','Food:Groceries',-26.09,'',1,0,0),(5629,'2014-09-01','HXSAM','Neulion/NFL','Hobbies',-33.49,'',1,0,0),(5630,'2014-09-01','HXSAM','Amazon','Gifts',-1.19,'',1,0,0),(5631,'2014-09-01','HXSAM','Amazon','Gifts',-3.75,'',1,0,0),(5632,'2014-09-01','FDMARK','Tesco Garage','Bills:Motor',-61.82,'BMW ',1,0,0),(5633,'2014-09-01','HXSAM','DGS/RPP DD','Bills:Insurance',-6.74,'Dishwasher cover',1,0,0),(5634,'2014-09-01','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(5635,'2014-09-03','FDMARK','ParentPay','Entertainment:Days Out',-15.00,'',1,0,0),(5636,'2014-09-03','FDMARK','Tesco Express','Food:Groceries',-5.00,'',1,0,0),(5637,'2014-09-04','FDMARK','Aviva Healthcare','Bills:Insurance',-65.14,'Health insurance',1,0,0),(5638,'2014-09-04','HXSAM','Amazon','Gifts',-32.85,'',1,0,0),(5639,'2014-09-04','HXSAM','Weekly Cash - Mark','Cash:Regular',-10.00,'',1,0,0),(5640,'2014-09-04','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(5641,'2014-09-05','FDMARK','Aviva CS UK Ltd','Work:Expenses',587.05,'',1,0,0),(5642,'2014-09-05','FDMARK','<Credit Card FIRST DIRECT>','Transfer',-587.05,'',1,0,0),(5643,'2014-09-05','HXSAM','Pets At Home','Pets',-47.37,'',1,0,0),(5644,'2014-09-05','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(5645,'2014-09-06','HXSAM','Cash','Cash',-20.00,'',1,0,0),(5646,'2014-09-06','HXSAM','Cash','Cash',-40.00,'',1,0,0),(5647,'2014-09-08','FDMARK','Tesco','Food:Groceries',-121.67,'',1,0,0),(5648,'2014-09-08','FDMARK','Tesco Express','Food:Groceries',-29.44,'',1,0,0),(5649,'2014-09-08','HXSAM','Jolleys Pet Food','Pets',-25.48,'',1,0,0),(5650,'2014-09-08','HXSAM','Pets At Home','Refund',20.00,'',1,0,0),(5651,'2014-09-08','HXSAM','Sally Gregory','Gifts',-12.00,'',1,0,0),(5652,'2014-09-08','FDMARK','O2','Bills:Mobile Phones',-42.04,'Sam\'s iPhone ',1,0,0),(5653,'2014-09-08','FDMARK','BT','Bills:Utilities',-51.58,'House phone & broadband',1,0,0),(5654,'2014-09-08','HXSAM','Who Internet','Entertainment:Books',-10.00,'',1,0,0),(5655,'2014-09-09','FDMARK','ParentPay','Food:School Dinners',-11.50,'',1,0,0),(5656,'2014-09-09','FDMARK','Old Guys Rule','Gifts',-25.00,'',1,0,0),(5657,'2014-09-09','FDMARK','Sainsbury\'s','Food:Groceries',-15.35,'',1,0,0),(5658,'2014-09-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(5659,'2014-09-09','HXSAM','Cash','Cash',-70.00,'',1,0,0),(5660,'2014-09-10','HXSAM','CPC','Entertainment:Hobbies',-24.40,'',1,0,0),(5661,'2014-09-10','HXSAM','Paypal','Miscellaneous',-4.49,'',1,0,0),(5662,'2014-09-10','HXSAM','Paypal','Miscellaneous',-10.99,'',1,0,0),(5663,'2014-09-10','HXSAM','Paypal','Gifts',-15.35,'',1,0,0),(5664,'2014-09-10','HXSAM','Greenthumb','Garden',-16.00,'',1,0,0),(5665,'2014-09-10','HXSAM','Debbie Martindale','Miscellaneous',-10.00,'',1,0,0),(5666,'2014-09-11','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(5667,'2014-09-11','FDMARK','Home Bargains','Food:Groceries',-8.24,'',1,0,0),(5668,'2014-09-11','FDMARK','Sainsbury\'s','Food:Groceries',-12.85,'',1,0,0),(5669,'2014-09-12','HXSAM','Cash','Cash',-10.00,'',1,0,0),(5670,'2014-09-12','HXSAM','Cash','Cash',-10.00,'',1,0,0),(5671,'2014-09-12','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(5672,'2014-09-15','FDMARK','Tesco Express','Food:Groceries',-7.30,'',1,0,0),(5673,'2014-09-15','FDMARK','Oyster','Bills:Credit Card Payment',-20.00,'',1,0,0),(5674,'2014-09-15','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.89,'',1,0,0),(5675,'2014-09-15','FDMARK','Aldi','Food:Groceries',-29.44,'',1,0,0),(5676,'2014-09-15','HXSAM','Hostroute','Hobbies',-10.80,'',1,0,0),(5677,'2014-09-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Bus monthly fee',1,0,0),(5678,'2014-09-15','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(5679,'2014-09-16','FDMARK','Animal Friends','Insurance',-4.36,'',1,0,0),(5680,'2014-09-16','FDMARK','Animal Friends','Insurance',-4.36,'',1,0,0),(5681,'2014-09-16','FDMARK','Tesco','Food:Groceries',-71.63,'',1,0,0),(5682,'2014-09-16','FDMARK','B&M bargains','Household',-9.97,'',1,0,0),(5683,'2014-09-16','FDMARK','Home Bargains','Food:Groceries',-12.62,'',1,0,0),(5684,'2014-09-16','FDMARK','ParentPay','Food:School Dinners',-10.45,'',1,0,0),(5685,'2014-09-16','FDMARK','Aldi','Food:Groceries',-8.40,'',1,0,0),(5686,'2014-09-17','HXSAM','Weekly Cash - Sam','Cash:Regular',-10.00,'',1,0,0),(5687,'2014-09-18','FDMARK','Aviva CS UK Ltd','Work:Expenses',351.15,'',1,0,0),(5688,'2014-09-18','FDMARK','<Credit Card FIRST DIRECT>','Transfer',-334.95,'',1,0,0),(5689,'2014-09-18','FDMARK','Jolleys Pet Food','Pets',-11.00,'',1,0,0),(5690,'2014-09-18','FDMARK','Argos','Household',-59.99,'',1,0,0),(5691,'2014-09-18','HXSAM','Homebase','Household',-8.98,'',1,0,0),(5692,'2014-09-18','RAINYDAY','<FDMARK>','Transfer',-60.00,'',1,0,0),(5693,'2014-09-18','FDMARK','<RAINYDAY>','Transfer',60.00,'',1,0,0),(5694,'2014-09-18','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(5695,'2014-09-19','HXSAM','Prime Instant Video','Entertainment:Hobbies',-5.99,'',1,0,0),(5696,'2014-09-19','FDMARK','B&M bargains','Household',-13.19,'',1,0,0),(5697,'2014-09-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(5698,'2014-09-20','HXSAM','Cash','Cash',-30.00,'',1,0,0),(5699,'2014-09-20','HXSAM','<RAINYDAY>','Transfer',350.00,'',1,0,0),(5700,'2014-09-20','RAINYDAY','<HXSAM>','Transfer',-350.00,'',1,0,0),(5701,'2014-09-22','FDMARK','Tesco Express','Food:Groceries',-11.13,'',1,0,0),(5702,'2014-09-22','FDMARK','Tesco','Food:Groceries',-102.43,'',1,0,0),(5703,'2014-09-22','FDMARK','Sainsbury\'s','Food:Groceries',-7.25,'',1,0,0),(5704,'2014-09-22','HXSAM','Amazon','Gifts',5.99,'',1,0,0),(5705,'2014-09-22','HXSAM','Amazon','Gifts',-25.39,'',1,0,0),(5706,'2014-09-22','HXSAM','COE & Co','Gifts',-25.00,'',1,0,0),(5707,'2014-09-22','HXSAM','EE & T-Mobile','Bills:Mobile Phones',-5.00,'',1,0,0),(5708,'2014-09-22','FDMARK','Tesco Garage','Bills:Motor',-52.90,'BMW ',1,0,0),(5709,'2014-09-23','FDMARK','ParentPay','Food:School Dinners',-15.00,'',1,0,0),(5710,'2014-09-23','HXSAM','Learnable','Entertainment:Hobbies',-5.53,'',1,0,0),(5711,'2014-09-23','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',1,0,0),(5712,'2014-09-23','HXSAM','Non-stg Trans Fee','Bills:Banking',-0.15,'',1,0,0),(5713,'2014-09-23','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(5714,'2014-09-24','FDMARK','Stuart Barber','Home:Appliances',-65.00,'Valve for CH',1,0,0),(5715,'2014-09-24','FDMARK','Tesco Express','Food:Groceries',-8.56,'',1,0,0),(5716,'2014-09-24','HXSAM','Paypal','Gifts',-19.84,'Xbox live gold',1,0,0),(5717,'2014-09-24','HXSAM','Paypal','Gifts',-1.62,'',1,0,0),(5718,'2014-09-24','HXSAM','Holmefield Vets','Pets',-38.27,'',1,0,0),(5719,'2014-09-25','FDMARK','O2','Bills:Mobile Phones',-47.19,'Mark\'s iPhone ',1,0,0),(5720,'2014-09-25','FDMARK','Tesco Express','Food:Groceries',-19.90,'',1,0,0),(5721,'2014-09-25','HXSAM','Amazon','Gifts',-303.88,'',1,0,0),(5722,'2014-09-26','FDMARK','Brayton High School','Entertainment:Days Out',-20.00,'Aimee\'s school trip',1,0,0),(5723,'2014-09-26','FDMARK','Aviva','Salary',3947.00,'',1,0,0),(5724,'2014-09-26','HXSAM','<FDMARK>','Transfer:Monthly Spends',1000.00,'',1,0,0),(5725,'2014-09-26','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1000.00,'',1,0,0),(5726,'2014-09-26','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(5727,'2014-09-26','FDMARK','<Credit Card BARCLAYCARD>','Bills:Credit Card Payment',-336.83,'',1,0,0),(5728,'2014-09-26','RAINYDAY','<FDMARK>','Transfer',100.00,'',1,0,0),(5729,'2014-09-26','FDMARK','<RAINYDAY>','Transfer',-100.00,'',1,0,0),(5730,'2014-09-27','HXSAM','Cash','Cash',-30.00,'Sam night out',1,0,0),(5731,'2014-09-28','HXSAM','Weekly Cash - Mark','Cash:Regular',-30.00,'',1,0,0),(5732,'2014-09-29','FDMARK','Aldi','Food:Groceries',-83.62,'',1,0,0),(5733,'2014-09-29','HXSAM','DGS/RPP DD','Bills:Insurance',-11.59,'',1,0,0),(5734,'2014-09-29','FDMARK','DVLA','Bills:Motor',-145.00,'Golf tax',1,0,0),(5735,'2014-09-29','HXSAM','Love You Hair & Beauty','Beauty',-26.00,'',1,0,0),(5736,'2014-09-29','FDMARK','Morrisons','Food:Groceries',-14.47,'',1,0,0),(5737,'2014-09-29','FDMARK','D Fox Window Cleaner','Household',-28.00,'',1,0,0),(5738,'2014-09-29','FDMARK','Three','Bills:Mobile Phones',-0.10,'',1,0,0),(5739,'2014-09-29','FDMARK','Three','Bills:Mobile Phones',-0.10,'',1,0,0),(5740,'2014-09-29','HXSAM','Amazon','Gifts',-8.93,'',1,0,0),(5741,'2014-09-29','HXSAM','Drax Sports Club','Entertainment:Days Out',-12.23,'',1,0,0),(5742,'2014-09-29','HXSAM','COE & Co','Gifts',-70.00,'',1,0,0),(5743,'2014-09-29','HXSAM','Amazon','Gifts',-1.50,'',1,0,0),(5744,'2014-09-29','HXSAM','Amazon','Gifts',-8.99,'',1,0,0),(5745,'2014-09-29','HXSAM','Amazon','Gifts',-16.95,'',1,0,0),(5746,'2014-09-29','HXSAM','ITunes.com','Entertainment:Hobbies',-3.49,'',1,0,0),(5747,'2014-09-30','FDMARK','ParentPay','Food:School Dinners',-14.00,'',1,0,0),(5748,'2014-09-30','HXSAM','Amazon','Gifts',-2.95,'',1,0,0),(5749,'2014-09-30','FDMARK','Tesco Garage','Bills:Motor',-66.48,'Petrol - Golf',1,0,0),(5750,'2014-09-30','FDMARK','ParentPay','Food:School Dinners',-9.50,'',1,0,0),(5751,'2014-09-30','FDMARK','Chelle\'s Dancing','Entertainment:Hobbies',-21.00,'',1,0,0),(5752,'2014-09-30','HXSAM','Selby College','Salary',320.42,'Sam salary',1,0,0),(5753,'2014-09-30','HXSAM','J Martindale','Other Income',27.00,'',1,0,0),(5754,'2014-10-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-422.71,'Mortgage payment',1,0,0),(5755,'2014-10-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(5756,'2014-10-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,0),(5757,'2014-10-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,0),(5758,'2014-10-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(5759,'2014-10-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-154.00,'',1,0,0),(5760,'2014-10-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:Tax',-12.12,'',1,0,0),(5761,'2014-10-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,0),(5762,'2014-10-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,0),(5763,'2014-10-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'Life & critical illness insurance',1,0,0),(5764,'2014-10-01','HXSAM','Pet Health Plan','Insurance',-18.98,'',1,0,0),(5765,'2014-10-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'Life insurance',1,0,0),(5766,'2014-10-01','FDMARK','Jolleys Pet Food','Pets',-9.00,'',1,0,0),(5767,'2014-10-01','HXSAM','Tracey Harrison Personal Trainer','Entertainment:Hobbies',-180.00,'',1,0,0),(5768,'2014-10-01','HXSAM','B&M bargains','Household',-16.73,'',1,0,0),(5769,'2014-10-01','HXSAM','Homebase','Household',-61.94,'',1,0,0),(5770,'2014-10-01','HXSAM','DGS/RPP DD','Bills:Insurance',-6.74,'Dishwasher cover',1,0,0),(5771,'2014-10-02','FDMARK','Animal Friends','Insurance Gracie',-4.36,'',1,0,0),(5772,'2014-10-02','FDMARK','Animal Friends','Insurance Rufus',-4.36,'',1,0,0),(5773,'2014-10-02','HXSAM','Moonpig','Gifts',-3.61,'',1,0,0),(5774,'2014-10-02','HXSAM','<RAINYDAY>','Transfer',200.00,'',1,0,0),(5775,'2014-10-02','RAINYDAY','<HXSAM>','Transfer',-200.00,'',1,0,0),(5776,'2014-10-02','HXSAM','Guides','Hobbies',-50.00,'',1,0,0),(5777,'2014-10-02','HXSAM','The Range','Household',-91.17,'',1,0,0),(5778,'2014-10-03','HXSAM','Homebase','Household',-31.47,'',1,0,0),(5779,'2014-10-03','HXSAM','Neulion/NFL','Hobbies',-33.49,'',1,0,0),(5780,'2014-10-03','HXSAM','Jolleys Pet Food','Pets',-8.99,'',1,0,0),(5781,'2014-10-03','FDMARK','Tesco Express','Food:Groceries',-22.17,'',1,0,0),(5782,'2014-10-03','HXSAM','Homebase','Household',-5.79,'',1,0,0),(5783,'2014-10-04','FDMARK','Aviva Healthcare','Bills:Insurance',-65.14,'Health insurance',1,0,0),(5784,'2014-10-06','FDMARK','Tesco','Food:Groceries',-152.90,'',1,0,0),(5785,'2014-10-06','HXSAM','Homebase','Household',-31.01,'',1,0,0),(5786,'2014-10-06','HXSAM','Homebase','Household',-44.27,'',1,0,0),(5787,'2014-10-06','FDMARK','Tempest Photos','Entertainment',-32.00,'',1,0,0),(5788,'2014-10-06','FDMARK','BT','Bills:Utilities',-49.98,'House phone & broadband',1,0,0),(5789,'2014-10-06','FDMARK','Tesco Express','Food:Groceries',-15.68,'',1,0,0),(5790,'2014-10-06','HXSAM','<RAINYDAY>','Transfer',850.00,'',1,0,0),(5791,'2014-10-06','RAINYDAY','<HXSAM>','Transfer',-850.00,'',1,0,0),(5792,'2014-10-06','HXSAM','<NEXTCARD>','Bills:Credit Card Payment',-13.06,'',1,0,0),(5793,'2014-10-06','NEXTCARD','<HXSAM>','Bills:Credit Card Payment',13.06,'',1,0,0),(5794,'2014-10-06','HXSAM','Selby Carpets','Home:Decorations',-388.00,'',1,0,0),(5795,'2014-10-06','HXSAM','Paypal','Household',-13.98,'',1,0,0),(5796,'2014-10-06','HXSAM','Paypal','Household',-57.39,'',1,0,0),(5797,'2014-10-07','HXSAM','Who Internet','Entertainment:Books',-10.00,'',1,0,0),(5798,'2014-10-07','HXSAM','Amazon','Home:Furniture',-13.98,'Duvet cover for Aimee ',1,0,0),(5799,'2014-10-07','HXSAM','Amazon','Gifts',-21.54,'Guillotine',1,0,0),(5800,'2014-10-07','FDMARK','Aviva Household','Bills:Insurance',-14.01,'',1,0,0),(5801,'2014-10-07','HXSAM','Bahnstormer','Bills:Motor',-261.41,'',1,0,0),(5802,'2014-10-08','HXSAM','Stuart Barber','Home',-48.00,'',1,0,0),(5803,'2014-10-08','FDMARK','Aviva CS UK Ltd','Work:Expenses',201.95,'',1,0,0),(5804,'2014-10-08','HXSAM','Amazon','Gifts',-16.95,'',1,0,0),(5805,'2014-10-09','FDMARK','ParentPay','Food:School Dinners',-10.00,'',1,0,0),(5806,'2014-10-09','FDMARK','<Credit Card FIRST DIRECT>','Transfer',-201.95,'',1,0,0),(5807,'2014-10-09','FDMARK','O2','Bills:Mobile Phones',-36.82,'Sam\'s iPhone ',1,0,0),(5808,'2014-10-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'BMW Loan Payment',1,0,0),(5809,'2014-10-09','HXSAM','B&M bargains','Household',-12.95,'',1,0,0),(5810,'2014-10-10','HXSAM','Amazon','Gifts',-7.99,'',1,0,0),(5811,'2014-10-10','HXSAM','Amazon','Gifts',-17.99,'Aimee\'s lamp',1,0,0),(5812,'2014-10-13','HXSAM','Amazon','Gifts',-69.00,'Apple tv',1,0,0),(5813,'2014-10-13','FDMARK','Tesco','Food:Groceries',-125.89,'',1,0,0),(5814,'2014-10-13','HXSAM','The Owl Hotel','Food:Dining',-117.24,'',1,0,0),(5815,'2014-10-13','HXSAM','Selby HWRC','Household',-2.52,'Recycling glass shower screen',1,0,0),(5816,'2014-10-13','HXSAM','Paypal','Household',-10.42,'',1,0,0),(5817,'2014-10-13','HXSAM','Amazon','Gifts',-48.68,'',1,0,0),(5818,'2014-10-13','FDMARK','Jolleys Pet Food','Pets',-9.00,'',1,0,0),(5819,'2014-10-15','FDMARK','ParentPay','Food:School Dinners',-15.00,'',1,0,0),(5820,'2014-10-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Bus monthly fee',1,0,0),(5821,'2014-10-15','FDMARK','Deezer','Entertainment:Music',-9.99,'Music subscription',1,0,0),(5822,'2014-10-16','HXSAM','Amazon','Gifts',-89.00,'Monitor',1,0,0),(5823,'2014-10-16','FDMARK','Tesco Garage','Bills:Motor',-65.00,'BMW ',1,0,0),(5824,'2014-10-17','HXSAM','<NEXTCARD>','Clothing',-46.70,'',1,0,0),(5825,'2014-10-17','NEXTCARD','<HXSAM>','Clothing',46.70,'',1,0,0),(5826,'2014-10-19','HXSAM','Prime Instant Video','Entertainment:Hobbies',-5.99,'',1,0,0),(5827,'2014-10-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(5828,'2014-10-20','FDMARK','Tesco','Food:Groceries',-120.00,'',1,0,0),(5829,'2014-10-20','FDMARK','ParentPay','Food:School Dinners',-15.00,'',1,0,0),(5830,'2014-10-22','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(5831,'2014-10-22','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(5832,'2014-10-25','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(5833,'2014-10-25','HXSAM','<NEXTCARD>','Clothing',0.00,'Balance of Next card',1,0,0),(5834,'2014-10-25','NEXTCARD','<HXSAM>','Clothing',0.00,'Balance of Next card',1,0,0),(5835,'2014-10-26','HXSAM','CONTRA - MARK SPENDS','Personal:Spends',-78.00,'',1,0,0),(5836,'2014-10-26','FDMARK','O2','Bills:Mobile Phones',-39.39,'Mark\'s iPhone ',1,0,0),(5839,'2014-11-01','FDMARK','Terry Testdata','Test Transactions',-23.99,'A third transaction... third time lucky!',1,0,0),(5840,'2014-11-01','NEXTCARD','Next','',100.00,'Payment to Next',1,0,0),(5844,'2014-11-01','FDMARK','Terry Testdata','Test Transactions',222.22,'fff',1,0,0),(5845,'2014-11-01','FDMARK','Morgan Freeman','Test Transactions',444.00,'no error message?',1,0,0),(5851,'2014-10-26','TSTMARK','Morgan Freeman','',-500.00,'Pay morgan freeman his expenses',1,1,0),(5852,'2014-09-30','TSTMARK','Mark Tonks','DEPOSIT',1000.00,'Pay in a lump o cash',1,0,0),(5853,'2014-10-26','TSTMARK','Aimee Tonks','',-75.00,'Aimee\'s pocket money is a lot this week',1,0,0),(5854,'2014-10-03','TSTMARK','Billy Bob Thornton','Danger Money',-150.00,'Pay Billy Bob to do something really dangerous!',1,0,0),(5855,'2014-10-04','TSTMARK','David Attenborough','Salary',-15.00,'Pay David his wages',1,0,0),(5856,'2014-10-05','TSTMARK','David Attenborough','Refund',15.00,'David had to pay his wages back... he didn\'t do the job!',1,0,0),(5857,'0000-00-00','FORTHEFUTURE','','',0.00,'',0,0,0),(5858,'2014-10-22','TSTMARK','John Greed Jewellery','Gifts',-85.99,'A very extravagant gift for Sam',1,0,0),(5859,'2014-10-27','TSTMARK','<TXFMARK>','Transfer',10.00,'Transfer £10 from the test account to the transfer account',1,0,0),(5884,'2014-11-27','TXFMARK','Bill Gates','Gifts',2000.00,'Some cash from Bill... what a guy!\r\n',0,0,0),(5886,'2014-11-10','TSTMARK','Cattery','Entertainment:Holidays',-60.00,'Put the cats in the cattery so we can go on holiday.',1,0,0),(5863,'2014-11-21','TXFMARK>','TSTMARK','Transfer',-25.00,'Transfer 4.0 [x]',0,0,0),(5911,'2014-11-11','FDMARK','Pret A Manger','Food',-8.03,'',1,0,0),(5910,'2014-11-10','FDMARK','Reconciled','Miscellaneous',-1077.80,'',0,0,0),(5879,'2014-10-27','TXFMARK','<TSTMARK>','Transfer',12.00,'NNN',1,0,5878),(5882,'2014-11-10','TSTMARK','<TXFMARK>','Transfer',-19.00,'RRRR - some notes replicated across transactions',1,0,5883),(5890,'2014-10-30','TSTMARK','Jean Tonks','Savings',1500.00,'Gift from mum',1,0,0),(5883,'2014-11-10','TXFMARK','<TSTMARK>','Transfer',19.00,'RRRR - some notes replicated across transactions',1,0,5882),(5891,'2014-10-30','TSTMARK','<TXFMARK>','Savings',-800.00,'Transfer some money to savings',1,0,5892),(5889,'2014-10-30','TSTMARK','Pear Tree Farm','Food:Dining',-12.99,'A big fat cake',1,0,0),(5892,'2014-10-30','TXFMARK','<TSTMARK>','Savings',800.00,'Transfer some money to savings',1,0,5891),(5893,'2014-10-31','TSTMARK','6th Selby Scouts','Subscriptions',-6.00,'Harvey\'s scouts subs',1,0,0),(5894,'2014-10-30','TSTMARK','Aviva','Salary',3000.00,'Pay Day!',1,0,0),(5895,'2014-11-01','TSTMARK','<TXFMARK>','Transfer',-50.00,'Rainy day',1,0,5896),(5896,'2014-11-01','TXFMARK','<TSTMARK>','Transfer',50.00,'Rainy day',1,0,5895),(5897,'2014-10-31','TSTMARK','Old Guys Rule','Gifts',-12.99,'Pressie for dad',1,0,0),(5899,'2014-10-31','TSTMARK','CPC','Entertainment:Hobbies',-9.99,'Pi bits',1,0,0),(5900,'2014-10-30','HXSAM','York Teaching Hospital','Bills:Motor',-10.00,'',1,0,0),(5901,'2014-10-28','HXSAM','Reconciled','Miscellaneous',400.76,'',1,0,0),(5902,'2014-10-31','HXSAM','Selby College','Salary',344.42,'',1,0,0),(5903,'2014-10-31','HXSAM','ITunes.com','Entertainment:Hobbies',-17.99,'Fairy tale box set',1,0,0),(5904,'2014-10-31','HXSAM','Boots','Medical',-22.08,'',1,0,0),(5905,'2014-11-03','HXSAM','Cineworld','Entertainment:Days Out',-21.00,'',1,0,0),(5906,'2014-11-05','HXSAM','Who Internet','Entertainment:Gambling',-10.00,'',1,0,0),(5907,'2014-11-11','HXSAM','Holmefield Vets','Pets',-60.00,'Gracie neutering',1,0,0),(5908,'2014-11-13','HXSAM','Oyster','Entertainment:Days Out',-20.00,'Top up',1,0,0),(5909,'2014-11-15','TSTMARK','Tesco Garage','Bills:Motor',-58.00,'',1,0,0),(5912,'2014-11-10','FDMARK','Reconciled','Miscellaneous',470.58,'',0,0,0),(5913,'2014-11-12','FDMARK','ParentPay','Food:School Dinners',-15.00,'',1,0,0),(5914,'2014-11-13','FDMARK','Oyster','Entertainment:Days Out',-20.00,'',1,0,0),(5915,'2014-11-17','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'',1,0,0),(5916,'2014-11-17','FDMARK','Deezer','Entertainment:Music',-9.99,'',1,0,0),(5917,'2014-11-17','FDMARK','Tesco','Food:Groceries',-117.42,'',1,0,0),(5918,'2014-11-18','FDMARK','ParentPay','Food:School Dinners',-15.00,'',1,0,0),(5919,'2014-11-24','FDMARK','H3G','Bills:Mobile Phones',-15.10,'',1,0,0),(5920,'2014-11-24','FDMARK','H3G','Bills:Mobile Phones',-10.00,'',1,0,0),(5921,'2014-11-24','FDMARK','Tesco','Food:Groceries',-107.47,'',1,0,0),(5922,'2014-11-26','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(5923,'2014-11-24','FDMARK','ParentPay','Food:School Dinners',-52.00,'',1,0,0),(5925,'2014-11-18','FDMARK','Sainsbury\'s','Food:Groceries',-5.80,'',1,0,0),(5926,'2014-11-17','FDMARK','Tesco Express','Refund',3.50,'',1,0,0),(5927,'2014-11-19','TSTMARK','Homebase','Household',-19.99,'',1,0,0),(5928,'2014-11-18','FDMARK','Aldi','Food:Groceries',-13.60,'',1,0,0),(5929,'2014-11-21','FDMARK','Tesco Express','Food:Groceries',-40.24,'',1,0,0),(5930,'2014-11-25','FDMARK','Cheque','Miscellaneous',-23.00,'',1,0,0),(5931,'2014-12-01','TSTMARK','National Rail','Bills:Transport',-106.98,'',1,0,0),(5932,'2014-11-27','FDMARK','Aviva','Salary',3946.00,'',1,0,0),(5933,'2014-11-27','FDMARK','<Credit Card HALIFAX SAM>','Transfer',-1450.00,'',1,0,5934),(5934,'2014-11-27','Credit Card HALIFAX SAM','<FDMARK>','Transfer',1450.00,'',1,0,5933),(5935,'2014-11-27','FDMARK','Tesco Express','Food:Groceries',-22.08,'',1,0,0),(5936,'2014-12-01','FDMARK','Tesco Garage','Bills:Motor',-69.75,'',1,0,0),(5937,'2014-12-02','FDMARK','Animal Friends','Insurance Rufus',-4.36,'',1,0,0),(5938,'2014-12-01','FDMARK','Tesco','Food:Groceries',-93.71,'',1,0,0),(5939,'2014-12-01','FDMARK','DGS/RPP DD','Bills:Insurance',-5.34,'',1,0,0),(5940,'2014-12-02','FDMARK','Animal Friends','Insurance Gracie',-4.36,'',1,0,0),(5942,'2014-12-01','FDMARK','Standing Order - Halifax Mortgage','Bills:Mortgage',-422.71,'',1,0,0),(5943,'2014-12-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(5944,'2014-12-01','FDMARK','<RAINYDAY>','Transfer',-50.00,'',1,0,5945),(5945,'2014-12-01','RAINYDAY','<FDMARK>','Transfer',50.00,'',1,0,5944),(5946,'2014-12-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(5947,'2014-12-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-154.00,'',1,0,0),(5948,'2014-12-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'',1,0,0),(5949,'2014-12-01','FDMARK','Legal & General','Bills:Insurance',-37.85,'',1,0,0),(5981,'2014-12-19','TSTMARK','Centerparcs','Entertainment:Holidays',-40.03,'',0,0,0),(5951,'2014-12-04','FDMARK','Aviva Healthcare','Bills:Insurance',-65.14,'',1,0,0),(5952,'2014-12-05','FDMARK','Aviva Household','Bills:Insurance',-14.13,'',1,0,0),(5953,'2014-12-05','FDMARK','BT','Bills:Utilities',-51.79,'',1,0,0),(5954,'2014-12-08','FDMARK','Tesco','Food:Groceries',-140.65,'',1,0,0),(5955,'2014-12-10','FDMARK','ParentPay','Food:School Dinners',-15.00,'',1,0,0),(5956,'2015-01-02','FDMARK','ParentPay','Entertainment:Days Out',-238.00,'Bewerley Park',1,0,0),(5957,'2014-12-01','FDMARK','H3G','Bills:Mobile Phones',-33.78,'Sam\'s phone',1,0,0),(5958,'2014-12-09','FDMARK','Nationwide Banking Services','Bills:Motor',-371.82,'',1,0,0),(5959,'2014-12-01','FDMARK','Tesco Garage','Bills:Motor',-54.74,'',1,0,0),(5962,'2014-12-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'',1,0,0),(5963,'2014-12-15','FDMARK','Deezer','Entertainment:Music',-9.99,'',1,0,0),(5964,'2014-12-24','FDMARK','Tesco','Food:Groceries',-102.40,'',1,0,0),(5982,'2014-12-10','FDMARK','Jolleys Pet Food','Pets',-8.00,'',1,0,0),(5966,'2014-12-22','FDMARK','H3G','Bills:Mobile Phones',-18.10,'',1,0,0),(5967,'2014-12-22','FDMARK','H3G','Bills:Mobile Phones',-10.00,'',1,0,0),(5968,'2015-01-05','FDMARK','Tesco Garage','Bills:Motor',-60.21,'BMW Fillup',1,0,0),(5969,'2014-12-29','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(5970,'2014-11-28','FDMARK','Morrisons','Food:Groceries',-18.25,'',1,0,0),(5971,'2014-12-02','FDMARK','Aldi','Food:Groceries',-13.86,'',1,0,0),(5972,'2014-12-03','FDMARK','Tesco Express','Food:Groceries',-21.94,'',1,0,0),(5973,'2014-12-04','FDMARK','Tesco Express','Food:Groceries',-4.62,'',1,0,0),(5974,'2014-12-08','FDMARK','Tesco Express','Food:Groceries',-8.30,'',1,0,0),(5975,'2014-12-09','TSTMARK','Boots','Medical',-7.00,'',1,0,0),(5976,'2014-12-10','TSTMARK','Tesco Express','Food:Groceries',-18.47,'',1,0,0),(5977,'2014-12-09','FDMARK','Tesco Express','Food:Groceries',-9.66,'',1,0,0),(5978,'2014-12-09','FDMARK','B&M bargains','Household',-18.47,'',1,0,0),(5979,'2014-12-08','FDMARK','Cheque','Miscellaneous',-25.00,'',1,0,0),(5980,'2014-12-08','FDMARK','Cheque','Miscellaneous',-30.00,'',1,0,0),(5983,'2014-12-10','FDMARK','Telefonica','Refund',29.26,'',1,0,0),(5984,'2014-12-10','FDMARK','Home Bargains','Food:Groceries',-37.31,'',1,0,0),(5985,'2014-12-11','FDMARK','ParentPay','Entertainment:Days Out',-2.10,'',1,0,0),(5986,'2014-12-15','FDMARK','B&M bargains','Household',-7.11,'',1,0,0),(5987,'2014-12-15','FDMARK','Aldi','Food:Groceries',-58.42,'',1,0,0),(5988,'2014-12-17','FDMARK','Park & Ride','Bills:Transport',-10.00,'',1,0,0),(5989,'2014-12-17','FDMARK','Morrisons','Food:Groceries',-61.26,'',1,0,0),(5990,'2014-12-17','HXSAM','<TXFMARK>','Transfer',-30.00,'',1,0,5991),(5991,'2014-12-17','TXFMARK','<HXSAM>','Transfer',30.00,'',0,0,5990),(5992,'2014-12-19','TSTMARK','Old Guys Rule','Gifts',-12.99,'',0,0,0),(5993,'2014-12-20','TSTMARK','EE & T-Mobile','Bills:Mobile Phones',-5.00,'',0,0,0),(5994,'2014-12-22','FDMARK','B&M bargains','Household',-16.78,'',1,0,0),(5996,'2014-12-22','FDMARK','Aldi','Food:Groceries',-45.96,'',1,0,0),(5997,'2014-12-19','HXSAM','Selby College','Salary',369.42,'',1,0,0),(5999,'2014-12-18','HXSAM','Adjustment','Miscellaneous',-690.40,'Align to actual balance from December pay day',0,0,0),(6000,'2014-12-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(6001,'2014-12-19','HXSAM','Love You Hair & Beauty','Beauty',-24.50,'',1,0,0),(6002,'2014-12-22','HXSAM','Hunters','Beauty:Haircut',-54.00,'',1,0,0),(6003,'2014-12-24','HXSAM','Learnable','Entertainment:Hobbies',-5.77,'',1,0,0),(6004,'2014-12-24','HXSAM','Non-stg Trans Fee','Bills:Banking',-0.15,'',1,0,0),(6005,'2014-12-24','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',1,0,0),(6007,'2014-12-21','HXSAM','Weekly Cash - Sam','Cash:Regular',-50.00,'',1,0,0),(6025,'2014-12-22','HXSAM','The Wishing Well','Food:Dining',-42.45,'',1,0,0),(6009,'2014-09-30','FORTHEFUTURE','First Direct','Interest',0.33,'',1,0,0),(6010,'2014-10-31','FORTHEFUTURE','First Direct','Interest',0.33,'',1,0,0),(6011,'2014-11-01','FORTHEFUTURE','Samantha Tonks','Savings',25.00,'',1,0,0),(6012,'2014-11-30','FORTHEFUTURE','First Direct','Interest',0.32,'',1,0,0),(6013,'2014-12-01','FORTHEFUTURE','Samantha Tonks','Savings',25.00,'',1,0,0),(6014,'2014-10-15','RAINYDAY','Samantha Tonks','Savings',-150.00,'',1,0,0),(6015,'2014-11-03','RAINYDAY','Samantha Tonks','Savings',50.00,'',1,0,0),(6016,'2014-11-21','RAINYDAY','Samantha Tonks','Savings',-200.00,'',1,0,0),(6017,'2014-12-16','RAINYDAY','Samantha Tonks','Savings',-100.00,'',1,0,0),(6559,'2015-03-20','HXSAM','Thompson Holidays','Entertainment:Holidays',-1628.00,'',1,0,0),(6019,'2015-08-01','RAINYDAY','Holiday','Entertainment:Holidays',-1000.00,'Holiday spends',0,1,0),(6020,'2014-12-01','NEXTCARD','Reconciled','Miscellaneous',-392.56,'',1,1,0),(6022,'2014-12-22','HXSAM','Love You Hair & Beauty','Beauty',-17.50,'',1,0,0),(6023,'2014-12-22','HXSAM','Home Bargains','Food:Groceries',-21.36,'',1,0,0),(6024,'2014-12-24','HXSAM','Who Internet','Entertainment:Gambling',-10.00,'',1,0,0),(6026,'2014-12-09','FDCREDIT','EC Mainline','Work:Expenses',-193.25,'',1,0,0),(6027,'2014-12-10','FDCREDIT','Frenchgate Car Park','Work:Expenses',-11.00,'',1,0,0),(6028,'2014-12-18','FDCREDIT','EC Mainline','Work:Expenses',-103.45,'',1,0,0),(6029,'2014-12-24','HXSAM','Microsoft Xbox Live','Entertainment:Games',-2.99,'',1,0,0),(6030,'2014-12-24','FDMARK','Home Bargains','Food:Groceries',-20.30,'',1,0,0),(6031,'2014-12-29','FDMARK','Tesco Express','Food:Groceries',-19.82,'',1,0,0),(6032,'2014-12-24','HXSAM','Homebase','Household',-14.68,'',1,0,0),(6033,'2014-12-24','HXSAM','Apple ITunes','Entertainment:Hobbies',-6.99,'Pointless app',1,0,0),(6034,'2014-12-22','FDMARK','Tesco Express','Food:Groceries',-9.52,'',1,0,0),(6035,'2014-12-22','HXSAM','Amazon','Gifts',-2.94,'',1,0,0),(6036,'2014-12-23','FDMARK','Aviva Accounts Rec','Work:Expenses',204.25,'',1,0,0),(6037,'2014-12-23','FDMARK','Aviva','Salary',3947.00,'',1,0,0),(6038,'2014-12-24','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1000.00,'',1,0,6039),(6039,'2014-12-24','HXSAM','<FDMARK>','Transfer:Monthly Spends',1000.00,'',1,0,6038),(6040,'2014-12-29','HXSAM','DGS/RPP DD','Bills:Insurance',-12.59,'',1,0,0),(6041,'2014-12-30','FDMARK','Tesco','Food:Groceries',-85.81,'Weekly shopping',1,0,0),(6114,'2014-12-29','NEXTCARD','Next','Clothing',-210.23,'Misc stuff that has been ordered during december',1,0,0),(6043,'2015-01-02','HXSAM','Weekly Cash - Sam','Cash:Regular',-50.00,'',1,0,0),(6044,'2015-01-02','FDMARK','Animal Friends','Insurance Rufus',-4.36,'',1,0,0),(6045,'2015-01-02','FDMARK','Animal Friends','Insurance Gracie',-4.36,'',1,0,0),(6046,'2015-01-02','FDMARK','DGS/RPP DD','Insurance',-5.34,'',1,0,0),(6047,'2015-01-02','FDMARK','Halifax','Bills:Mortgage',-422.71,'',1,0,0),(6048,'2015-01-05','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(6049,'2015-01-02','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,6050),(6050,'2015-01-02','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,6049),(6051,'2015-01-05','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(6052,'2015-01-02','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-154.00,'',1,0,0),(6053,'2015-01-02','HXSAM','Direct Debit - TV Licence Mbp','Bills:TV',-12.12,'',1,0,0),(6054,'2014-12-30','FDMARK','H3G','Bills:Mobile Phones',-32.00,'Sam\'s phone',1,0,0),(6055,'2015-01-02','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,6056),(6056,'2015-01-02','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,6055),(6057,'2015-01-02','FDMARK','Legal & General','Bills:Insurance',-21.74,'',1,0,0),(6058,'2015-01-02','HXSAM','Pet Health Plan','Insurance',-18.98,'',1,0,0),(6059,'2015-01-02','FDMARK','Legal & General','Insurance',-37.85,'',1,0,0),(6060,'2015-01-02','HXSAM','DGS/RPP DD','Insurance',-6.74,'',1,0,0),(6062,'2015-01-06','FDMARK','Aviva Healthcare','Insurance',-65.14,'',1,0,0),(6063,'2015-01-07','FDMARK','Aviva Household','Insurance',-14.13,'',1,0,0),(6064,'2015-01-06','FDMARK','BT','Bills:Utilities',-50.05,'',1,0,0),(6065,'2015-01-09','FDMARK','Nationwide Banking Services','Bills:Loans',-371.82,'',1,0,0),(6232,'2015-01-26','HXSAM','Cash','Cash',-30.00,'',1,0,0),(6067,'2014-12-24','FDMARK','Tesco Garage','Bills:Motor',-59.88,'Golf fillup',1,0,0),(6324,'2015-02-02','FDMARK','Market Lane Dental','Bills:Prescriptions',-32.00,'Mark\'s filling',1,0,0),(6069,'2015-01-15','FDMARK','Deezer','Entertainment:Music',-9.99,'',1,0,0),(6070,'2015-01-14','HXSAM','Web Hosting','Entertainment:Hobbies',-3.60,'Tonksdev.co.uk',1,0,0),(6071,'2015-01-19','HXSAM','Prime Instant Video','Entertainment:Hobbies',-5.99,'',1,0,0),(6072,'2015-01-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(6073,'2015-01-22','FDMARK','H3G','Bills:Mobile Phones',-15.00,'',1,0,0),(6074,'2015-01-22','FDMARK','H3G','Bills:Mobile Phones',-10.00,'',1,0,0),(6075,'2015-01-23','HXSAM','Learnable','Entertainment:Hobbies',-5.97,'',1,0,0),(6076,'2015-01-23','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',1,0,0),(6077,'2015-01-23','HXSAM','Non-stg Trans Fee','Bills:Banking',-0.16,'',1,0,0),(6078,'2015-01-27','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(6208,'2014-12-31','FORTHEFUTURE','First Direct','Interest',0.34,'',1,0,0),(6196,'2015-01-19','HXSAM','Apple ITunes','Entertainment:Hobbies',-10.00,'Gift £10 to harvey',1,0,0),(6081,'2015-01-05','FDMARK','Tesco','Food:Groceries',-100.48,'Weekly shopping',1,0,0),(6082,'2015-01-07','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(6083,'2015-01-05','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(6084,'2015-01-12','FDMARK','Tesco','Food:Groceries',-101.18,'Weekly shopping',1,0,0),(6085,'2015-01-12','HXSAM','Weekly Cash - Mark','Cash:Regular',-30.00,'',1,0,0),(6086,'2015-01-12','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(6087,'2015-01-19','FDMARK','Tesco','Food:Groceries',-142.05,'Weekly shopping',1,0,0),(6088,'2015-01-21','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(6089,'2015-01-19','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(6090,'2015-01-27','FDMARK','Tesco','Food:Groceries',-122.98,'Weekly shopping',1,0,0),(6092,'2014-12-29','FDMARK','<FDCREDIT>','Bills:Credit Card Payment',-205.00,'',1,0,6093),(6093,'2014-12-29','FDCREDIT','<FDMARK>','Bills:Credit Card Payment',205.00,'',1,0,6092),(6094,'2014-12-24','HXSAM','Paypal','Miscellaneous',-8.00,'',1,0,0),(6095,'2014-12-24','HXSAM','Paypal','Miscellaneous',-27.95,'',1,0,0),(6096,'2014-12-24','HXSAM','Paypal','Miscellaneous',-28.95,'',1,0,0),(6097,'2015-05-26','HXSAM','CONTRA - AIMEE SPENDS','Personal:Spends',-3.13,'',0,1,0),(6098,'2014-12-29','HXSAM','Amazon','Gifts',-78.36,'Aimee\'s Fairy Tail and Window Vac',1,0,0),(6099,'2014-12-29','HXSAM','Amazon','Gifts',-15.81,'HALO for Harvey',1,0,0),(6100,'2014-12-29','FDMARK','Motorpoint Arena Sheffield','Entertainment:Days Out',-170.50,'WWE tickets',1,0,0),(6198,'2015-01-19','HXSAM','Amazon','Gifts',-12.88,'??',1,0,0),(6102,'2014-12-30','FDMARK','ATG Tickets','Entertainment:Days Out',-89.50,'Aimee\'s drama performance',1,0,0),(6103,'2014-12-29','HXSAM','Paypal','Miscellaneous',-3.99,'',1,0,0),(6104,'2014-12-31','HXSAM','IKEA','Home:Furniture',-184.90,'Harvey\'s bedroom furniture & computer chair. ',1,0,0),(6105,'2014-12-31','HXSAM','B&M bargains','Household',-9.45,'',1,0,0),(6106,'2014-12-29','HXSAM','Amazon','Gifts',-1.18,'',1,0,0),(6107,'2014-12-29','HXSAM','Amazon','Gifts',-0.59,'',1,0,0),(6108,'2014-12-30','HXSAM','Paypal','Miscellaneous',-33.95,'',1,0,0),(6111,'2014-12-11','NEXTCARD','Next','Clothing',-245.70,'Balance as of December 11th',1,0,0),(6112,'2015-01-02','FDMARK','Tesco Express','Food:Groceries',-32.02,'Extra shopping for new year\'s day',1,0,0),(6113,'2014-12-31','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-2.76,'',1,0,0),(6115,'2014-12-18','NEXTCARD','Next','Clothing',39.49,'',1,0,0),(6180,'2015-01-11','NEXTCARD','Next','Interest',-4.50,'',1,0,0),(6116,'2015-01-08','NEXTCARD','Next','Clothing',37.00,'Jumper, shirt, bras. ',1,0,0),(6117,'2015-01-02','FDMARK','ParentPay','Entertainment:Days Out',-180.00,'Harvey\'s school trip',1,0,0),(6119,'2014-12-31','HXSAM','Amazon Marketplace','Gifts',-39.20,'',1,0,0),(6120,'2014-12-31','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.49,'',1,0,0),(6121,'2014-12-31','FDMARK','Aldi','Food:Groceries',-23.24,'',1,0,0),(6204,'2015-01-20','RAINYDAY','<FDMARK>','Transfer',-77.00,'Payment for NFL tickets',1,0,6205),(6123,'2015-01-05','FDMARK','Tesco Express','Food:Groceries',-11.13,'',1,0,0),(6124,'2015-01-03','HXSAM','Amazon','Gifts',-2.94,'',1,0,0),(6125,'2015-01-03','HXSAM','Amazon EU','Entertainment:Books',-6.79,'Fairy tail book',1,0,0),(6126,'2015-01-03','HXSAM','Amazon Marketplace','Gifts',-13.85,'',1,0,0),(6127,'2015-01-03','HXSAM','Apple ITunes','Entertainment:Hobbies',-1.49,'',1,0,0),(6128,'2015-01-03','HXSAM','Planned O/D Fee','Bills:Banking',-1.00,'',1,0,0),(6129,'2015-01-05','HXSAM','Amazon','Gifts',-13.00,'WWE game for Harvey',1,0,0),(6130,'2015-01-03','NEXTCARD','Next','Clothing',-9.00,'Harvey socks',1,0,0),(6131,'2015-01-03','NEXTCARD','Next','Clothing',-8.50,'Aimee tights',1,0,0),(6132,'2015-01-03','NEXTCARD','Next','Clothing',-28.00,'sam knickers',1,0,0),(6134,'2015-01-06','HXSAM','Apple ITunes','Entertainment:Hobbies',-6.99,'NFL Sky Pass',1,0,0),(6135,'2015-01-06','HXSAM','Who Internet','Entertainment:Gambling',-10.00,'',1,0,0),(6162,'2015-01-12','FDMARK','Tesco Express','Food:Groceries',-12.50,'',1,0,0),(6161,'2015-01-12','FDMARK','Home Bargains','Food:Groceries',-29.74,'',1,0,0),(6186,'2015-01-22','FDCREDIT','Holiday Inn Norwich','Work:Expenses',-83.95,'',1,0,0),(6187,'2015-01-19','FDCREDIT','EC Mainline','Work:Expenses',-136.75,'',1,0,0),(6221,'2015-01-23','HXSAM','C Danks','Other Income',8.60,'',1,0,0),(6222,'2015-01-23','HXSAM','Paypal','Other Income',30.00,'',1,0,0),(6223,'2015-01-27','HXSAM','Rowlands Pharmacy','Bills:Prescriptions',-16.95,'',1,0,0),(6142,'2015-01-06','FDCREDIT','EC Mainline','Work:Expenses',-63.25,'',1,0,0),(6143,'2015-01-05','NEXTCARD','Next','Clothing',-12.00,'Black pencil skirt',1,0,0),(6144,'2015-01-05','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-2.32,'',1,0,0),(6145,'2015-01-05','HXSAM','Cineworld','Entertainment:Days Out',-22.02,'Big Hero 6',1,0,0),(6146,'2015-01-07','HXSAM','<NEXTCARD>','Clothing',-23.03,'Monthly minimum payment',1,0,6147),(6147,'2015-01-07','NEXTCARD','<HXSAM>','Clothing',23.03,'Monthly minimum payment',1,0,6146),(6148,'2015-01-07','HXSAM','Paypal','Household',-8.99,'Veggie shredder',1,0,0),(6149,'2015-01-07','NEXTCARD','Next','Clothing',-41.00,'Shirt & Jeans',1,0,0),(6150,'2015-01-12','NEXTCARD','Next','Clothing',41.00,'Shirt & Jeans',1,0,0),(6151,'2015-01-09','HXSAM','Sainsbury\'s','Food:Groceries',-23.95,'',1,0,0),(6152,'2015-01-08','NEXTCARD','Next','Clothing',-17.00,'Dress',1,0,0),(6153,'2015-01-09','HXSAM','Vision Value','Medical:Opticians',-50.00,'',1,0,0),(6154,'2015-01-19','HXSAM','Vision Value','Medical:Opticians',-68.30,'Balance of Aimee\'s glasses',1,0,0),(6155,'2015-01-08','RAINYDAY','<HXSAM>','Transfer',-200.00,'Reimburse Harvey\'s furniture & Aimee\'s glasses.',1,0,6156),(6156,'2015-01-08','HXSAM','<RAINYDAY>','Transfer',200.00,'Reimburse Harvey\'s furniture & Aimee\'s glasses.',1,0,6155),(6157,'2015-01-13','NEXTCARD','Next','Clothing',17.00,'Dress',1,0,0),(6158,'2015-01-09','NEXTCARD','Next','Clothing',-26.00,'Blue Floral Pyjamas',1,0,0),(6159,'2015-01-12','NEXTCARD','Next','Clothing',12.00,'Black Pencil Skirt',1,0,0),(6160,'2015-05-26','HXSAM','CONTRA - HARVEY SPENDS','Personal:Spends',-4.13,'Harvey\'s spends from his pocket money',0,1,0),(6163,'2015-01-12','HXSAM','Chiquitos','Food:Dining',-41.00,'',1,0,0),(6164,'2015-01-12','HXSAM','Argos','Household',-12.99,'Sky remote for lola',1,0,0),(6165,'2015-01-12','HXSAM','Argos','Household',12.99,'Sky remote for Argos',1,0,0),(6166,'2015-01-13','HXSAM','Apple ITunes','Entertainment:Hobbies',-6.99,'Sky Sports day pass',1,0,0),(6167,'2015-01-14','HXSAM','Amazon','Gifts',-2.94,'',1,0,0),(6168,'2015-01-14','NEXTCARD','Next','Clothing',-19.00,'black Capri trousers',1,0,0),(6169,'2015-01-14','NEXTCARD','Next','Clothing',-42.00,'pyjamas, 2x shirt',1,0,0),(6170,'2015-01-16','NEXTCARD','Next','Clothing',33.00,'shirt & trousers',1,0,0),(6181,'2014-12-16','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(6171,'2015-01-15','FDMARK','Aviva CS UK Ltd','Work:Expenses',166.70,'',1,0,0),(6172,'2015-01-13','FDCREDIT','Holiday Inn Norwich','Work:Expenses',-83.95,'',1,0,0),(6173,'2015-01-16','FDCREDIT','Frenchgate Car Park','Work:Expenses',-22.00,'',1,0,0),(6174,'2015-01-15','FDMARK','<FDCREDIT>','Bills:Credit Card Payment',-170.00,'Repay work expenses',1,0,6175),(6175,'2015-01-15','FDCREDIT','<FDMARK>','Bills:Credit Card Payment',170.00,'Repay work expenses',1,0,6174),(6176,'2015-01-26','FDMARK','Aviva CS UK Ltd','Work:Expenses',123.28,'',1,0,0),(6177,'2015-01-26','FDMARK','<FDCREDIT>','Bills:Credit Card Payment',-123.28,'',1,0,6178),(6178,'2015-01-26','FDCREDIT','<FDMARK>','Bills:Credit Card Payment',123.28,'',1,0,6177),(6179,'2015-01-15','HXSAM','Cash','Cash',-20.00,'',1,0,0),(6182,'2014-12-22','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(6183,'2015-01-01','NEXTCARD','Next','Delivery Charge',-3.99,'',1,0,0),(6184,'2015-01-06','NEXTCARD','Next','Miscellaneous',-27.73,'Align to statement total (6 JAN)',1,1,0),(6185,'2015-01-16','HXSAM','Amazon Marketplace','Miscellaneous',-2.84,'',1,0,0),(6215,'2015-01-20','HXSAM','Cash','Cash',-10.00,'',1,0,0),(6189,'2015-01-19','HXSAM','Thompson Holidays','Entertainment:Holidays',-150.00,'Deposit for Cape Verde',1,0,0),(6191,'2015-01-16','RAINYDAY','<HXSAM>','Transfer',-150.00,'Repay holiday deposit',1,0,6192),(6192,'2015-01-16','HXSAM','<RAINYDAY>','Transfer',150.00,'Repay holiday deposit',1,0,6191),(6193,'2015-06-22','RAINYDAY','Holiday','Entertainment:Holidays',-500.00,'Spends for Cape Verde ',0,1,0),(6194,'2015-01-19','HXSAM','Wh Smith','Gifts',-16.00,'iTunes voucher for Bethan',1,0,0),(6195,'2015-01-19','HXSAM','Jean Tonks','Household',-37.00,'Candles',1,0,0),(6197,'2015-01-22','FDMARK','2nd Brayton Guides','Hobbies',-29.00,'',1,0,0),(6199,'2015-01-19','HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',1,0,0),(6200,'2015-01-19','HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',1,0,0),(6201,'2015-01-19','HXSAM','Amazon','Gifts',-30.24,'??',1,0,0),(6220,'2015-01-23','HXSAM','Paypal','Other Income',15.00,'',1,0,0),(6202,'2015-01-19','FDCREDIT','Ticketmaster','Entertainment:Days Out',-154.04,'NFL Jets vs Dolphins',1,0,0),(6203,'2015-01-21','HXSAM','Amazon','Gifts',-29.62,'',1,0,0),(6205,'2015-01-20','FDMARK','<RAINYDAY>','Transfer',77.00,'Payment for NFL tickets',1,0,6204),(6206,'2015-01-20','FDMARK','<FDCREDIT>','Bills:Credit Card Payment',-77.00,'Mark\'s NFL ticket',1,0,6207),(6207,'2015-01-20','FDCREDIT','<FDMARK>','Bills:Credit Card Payment',77.00,'Mark\'s NFL ticket',1,0,6206),(6209,'2015-01-22','FDCREDIT','Frenchgate Car Park','Work:Expenses',-22.00,'',1,0,0),(6210,'2015-01-29','FDMARK','Aviva CS UK Ltd','Work:Expenses',266.02,'',1,0,0),(6211,'2015-01-29','FDMARK','<FDCREDIT>','Bills:Credit Card Payment',-266.02,'',1,0,6212),(6212,'2015-01-29','FDCREDIT','<FDMARK>','Bills:Credit Card Payment',266.02,'',1,0,6211),(6213,'2015-01-22','HXSAM','Market Lane Dental','Bills:Prescriptions',-37.00,'2x checkups',1,0,0),(6214,'2015-01-21','FDMARK','Morrisons','Food:Groceries',-18.01,'',1,0,0),(6216,'2015-01-20','HXSAM','Amazon EU','Entertainment:Books',-2.94,'',1,0,0),(6217,'2015-01-20','HXSAM','Cineworld','Entertainment:Days Out',-68.80,'',1,0,0),(6218,'2015-01-22','HXSAM','McDonalds','Food:Dining',-27.28,'',1,0,0),(6219,'2015-01-23','FDCREDIT','Nelson Inn','Food:Dining',-16.43,'',1,0,0),(6224,'2015-01-24','NEXTCARD','Next','Clothing',-75.00,'3x trousers, slogging blk tai, blk smoothing shorts',1,0,0),(6225,'2015-01-24','NEXTCARD','Next','Clothing',14.00,'Smoothing shorts ',1,0,0),(6226,'2015-01-24','NEXTCARD','Next','Clothing',-24.00,'Pyjamas x 2',1,0,0),(6227,'2015-01-24','NEXTCARD','Next','Clothing',24.00,'Pyjamas x 2',1,0,0),(6228,'2015-01-27','HXSAM','Weatherspoons','Food:Dining',-7.79,'',1,0,0),(6229,'2015-01-27','HXSAM','Weatherspoons','Food:Dining',-11.79,'',1,0,0),(6230,'2015-01-27','FDMARK','Tesco Garage','Bills:Motor',-43.03,'',1,0,0),(6231,'2015-01-27','FDMARK','Home Bargains','Food:Groceries',-31.92,'',1,0,0),(6233,'2015-01-27','FDMARK','Aviva','Salary',3946.00,'',1,0,0),(6234,'2015-01-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1000.00,'',1,0,6235),(6235,'2015-01-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',1000.00,'',1,0,6234),(6236,'2015-01-27','HXSAM','DGS/RPP DD','Bills:Insurance',-12.59,'',1,0,0),(6237,'2015-02-02','FDMARK','Tesco','Food:Groceries',-133.18,'Weekly shopping',1,0,0),(6238,'2015-01-30','HXSAM','Selby College','Salary',346.25,'',1,0,0),(6239,'2015-01-30','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(6240,'2015-02-01','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(6241,'2015-02-02','FDMARK','Animal Friends','Insurance Rufus',-4.36,'',1,0,0),(6242,'2015-02-02','FDMARK','Animal Friends','Insurance Gracie',-4.36,'',1,0,0),(6243,'2015-02-02','FDMARK','DGS/RPP DD','Insurance',-5.34,'',1,0,0),(6244,'2015-02-02','FDMARK','Halifax','Bills:Mortgage',-422.71,'',1,0,0),(6245,'2015-02-02','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(6246,'2015-02-02','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,6247),(6247,'2015-02-02','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,6246),(6248,'2015-02-02','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(6340,'2015-02-04','HXSAM','Tesco Express','Food:Groceries',-9.25,'',1,0,0),(6250,'2015-02-02','HXSAM','Direct Debit - TV Licence Mbp','Bills:TV',-12.12,'',1,0,0),(6251,'2015-01-30','FDMARK','H3G','Bills:Mobile Phones',-32.59,'Sam\'s phone',1,0,0),(6252,'2015-02-02','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,6253),(6253,'2015-02-02','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,6252),(6254,'2015-02-02','FDMARK','Legal & General','Bills:Insurance',-21.74,'',1,0,0),(6255,'2015-02-02','HXSAM','Pet Health Plan','Insurance',-18.98,'',1,0,0),(6256,'2015-02-02','FDMARK','Legal & General','Insurance',-37.85,'',1,0,0),(6257,'2015-02-02','HXSAM','DGS/RPP DD','Insurance',-6.74,'',1,0,0),(6258,'2015-02-04','FDMARK','Aviva Healthcare','Insurance',-65.14,'',1,0,0),(6259,'2015-02-05','FDMARK','Aviva Household','Insurance',-14.13,'',1,0,0),(6260,'2015-02-04','FDMARK','BT','Bills:Utilities',-51.10,'',1,0,0),(6261,'2015-02-09','FDMARK','Nationwide Banking Services','Bills:Loans',-371.82,'',1,0,0),(6262,'2015-01-27','FDMARK','Tesco Garage','Bills:Motor',-55.75,'BMW fillup',1,0,0),(6300,'2015-01-26','HXSAM','Kathryn Poynter','Other Income',8.60,'',1,0,0),(6264,'2015-02-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Cycle locker',1,0,0),(6265,'2015-02-16','FDMARK','Deezer','Entertainment:Music',-9.99,'',1,0,0),(6266,'2015-02-16','HXSAM','Web Hosting','Entertainment:Hobbies',-3.60,'Tonksdev.co.uk',1,0,0),(6267,'2015-02-19','HXSAM','Prime Instant Video','Entertainment:Hobbies',-5.99,'',1,0,0),(6268,'2015-02-19','HXSAM','Lovefilm.com','Entertainment:Hobbies',-7.28,'',1,0,0),(6269,'2015-02-23','FDMARK','H3G','Bills:Mobile Phones',-15.10,'',1,0,0),(6270,'2015-02-23','FDMARK','H3G','Bills:Mobile Phones',-10.00,'',1,0,0),(6271,'2015-02-23','HXSAM','Learnable','Entertainment:Hobbies',-5.87,'',1,0,0),(6272,'2015-02-23','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',1,0,0),(6273,'2015-02-23','HXSAM','Non-stg Trans Fee','Bills:Banking',-0.16,'',1,0,0),(6274,'2015-02-25','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(6398,'2015-02-24','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(6378,'2015-02-20','HXSAM','Tesco','Clothing',-129.90,'',1,0,0),(6379,'2015-02-18','HXSAM','Paypal','Miscellaneous',-4.00,'',1,0,0),(6328,'2015-02-02','HXSAM','Gap','Clothing',-19.38,'',1,0,0),(6329,'2015-02-02','HXSAM','Outfit','Clothing:Sam',-52.00,'',1,0,0),(6327,'2015-02-02','FDMARK','Tesco Express','Food:Groceries',-17.07,'',1,0,0),(6280,'2015-02-19','HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',1,0,0),(6281,'2015-02-19','HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',1,0,0),(6282,'2015-02-05','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(6354,'2015-02-11','FDMARK','ParentPay','Food:School Dinners',-10.00,'',1,0,0),(6348,'2015-02-07','FDMARK','Tesco Express','Food:Groceries',-15.33,'',1,0,0),(6347,'2015-02-10','HXSAM','CPC','Entertainment:Hobbies',-35.66,'Raspberry Pi 2',1,0,0),(6286,'2015-02-09','FDMARK','Tesco','Food:Groceries',-117.85,'Weekly shopping',1,0,0),(6287,'2015-02-23','FDMARK','Tesco Garage','Bills:Motor',-46.52,'BMW fillup',1,0,0),(6363,'2015-02-15','HXSAM','Tesco Express','Food:Groceries',-3.19,'',1,0,0),(6365,'2015-02-16','HXSAM','Olives & Grill','Food:Dining',-49.90,'',1,0,0),(6366,'2015-02-11','NEXTCARD','Next','Adjustment',-14.12,'Adjustment for bill',1,1,0),(6364,'2015-02-14','HXSAM','Cash','Cash',-20.00,'',1,0,0),(6292,'2015-02-16','FDMARK','Tesco','Food:Groceries',-131.47,'Weekly shopping',1,0,0),(6293,'2015-02-23','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(6294,'2015-02-16','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(6392,'2015-02-23','HXSAM','The Angel Hotel','Food:Dining',-20.56,'Weatherspoons in Whitby',1,0,0),(6393,'2015-02-23','HXSAM','Catnaps','Entertainment:Holidays',-45.00,'',1,0,0),(6297,'2015-02-23','FDMARK','Tesco','Food:Groceries',-132.03,'Weekly shopping',1,0,0),(6485,'2015-03-01','BILLSACC','<SAVACC>','Transfer',-200.00,'',1,0,6486),(6299,'2015-02-24','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(6301,'2015-01-26','HXSAM','Richard Longton','Other Income',8.60,'',1,0,0),(6302,'2015-01-26','HXSAM','N Clarkson-Banks','Other Income',8.60,'',1,0,0),(6303,'2015-01-26','HXSAM','A Taylor','Other Income',8.60,'',1,0,0),(6304,'2015-02-04','FDMARK','<NEXTCARD>','Clothing',-400.00,'',1,0,6305),(6305,'2015-02-04','NEXTCARD','<FDMARK>','Clothing',400.00,'',1,0,6304),(6306,'2015-01-26','FDCREDIT','TheTrainLine.com','Work:Expenses',-204.50,'Train to London',1,0,0),(6307,'2015-01-28','FDMARK','Pret A Manger','Food',-5.87,'',1,0,0),(6326,'2015-02-02','HXSAM','Cineworld','Entertainment:Days Out',-13.42,'Into the woods',1,0,0),(6310,'2015-01-28','HXSAM','Boots','Medical',-17.98,'',1,0,0),(6309,'2015-01-28','FDMARK','Morrisons','Food:Groceries',-16.91,'',1,0,0),(6311,'2015-01-28','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(6312,'2015-01-28','HXSAM','Paypal','Other Income',-3.84,'',1,0,0),(6313,'2015-01-28','HXSAM','Amazon','Gifts',-24.63,'Book & Printer Cartridges',1,0,0),(6314,'2015-01-28','NEXTCARD','Next','Clothing',-33.00,'More trousers for harvey',1,0,0),(6315,'2015-01-28','NEXTCARD','Next','Clothing',33.00,'More trousers for Harvey',1,0,0),(6316,'2015-01-29','FDMARK','Cheque','Entertainment:Hobbies',-20.00,'Aimee\'s drama lessons',1,0,0),(6317,'2015-02-09','FDMARK','Aviva CS UK Ltd','Work:Expenses',381.80,'',1,0,0),(6318,'2015-02-09','FDMARK','<FDCREDIT>','Bills:Credit Card Payment',-381.80,'',1,0,6319),(6319,'2015-02-09','FDCREDIT','<FDMARK>','Bills:Credit Card Payment',381.80,'',1,0,6318),(6320,'2015-02-02','HXSAM','Apple ITunes','Entertainment:Hobbies',-14.99,'Big Bang Theory Season 3',1,0,0),(6321,'2015-01-30','NEXTCARD','Next','Clothing',-33.00,'3x trousers for Harvey (bigger) ',1,0,0),(6322,'2015-01-30','NEXTCARD','Next','Clothing',-12.00,'',1,0,0),(6323,'2015-01-30','NEXTCARD','Next','Clothing',12.00,'',1,0,0),(6330,'2015-02-02','HXSAM','Wh Smith','Gifts',-3.99,'Pokemon cards for harvey',1,0,0),(6331,'2015-02-02','HXSAM','The Range','Household',-24.41,'',1,0,0),(6332,'2015-02-03','HXSAM','The Owl Hotel','Food:Dining',-52.95,'',1,0,0),(6333,'2015-02-04','FDCREDIT','TheTrainLine.com','Work:Expenses',-173.50,'',1,0,0),(6334,'2015-02-02','NEXTCARD','Next','Clothing',-26.50,'2x Jeans for Harvey',1,0,0),(6335,'2015-02-02','HXSAM','Discovery Accomodation','Entertainment:Holidays',-282.00,'2 nights in Whitby',1,0,0),(6336,'2015-02-02','FDMARK','<HXSAM>','Transfer',-300.00,'Transfer to cover Whitby holiday',1,0,6337),(6337,'2015-02-02','HXSAM','<FDMARK>','Transfer',300.00,'Transfer to cover Whitby holiday',1,0,6336),(6338,'2015-02-06','FDMARK','Cheque','Entertainment:Hobbies',-49.50,'Slimming world subs',1,0,0),(6389,'2015-02-19','HXSAM','Amazon','Miscellaneous',-12.75,'',1,0,0),(6341,'2015-02-04','HXSAM','Next','Clothing',-48.11,'',1,0,0),(6342,'2015-02-04','FDMARK','<HXSAM>','Transfer',-50.00,'',1,0,6343),(6343,'2015-02-04','HXSAM','<FDMARK>','Transfer',50.00,'',1,0,6342),(6344,'2015-01-31','FORTHEFUTURE','First Direct','Interest',0.35,'',1,0,0),(6345,'2015-02-06','FDMARK','Tesco Express','Food:Groceries',-8.99,'',1,0,0),(6346,'2015-02-06','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(6349,'2015-02-10','FDMARK','Home Bargains','Food:Groceries',-22.77,'',1,0,0),(6350,'2015-02-09','HXSAM','Gap','Clothing',-28.98,'',1,0,0),(6351,'2015-02-09','HXSAM','Amazon Digital Download','Entertainment:Kindle Books',-3.59,'',1,0,0),(6352,'2015-02-11','HXSAM','Amazon','Gifts',-7.39,'Micro SD card for the new Raspberry PI',1,0,0),(6353,'2015-02-10','HXSAM','Hotel Chocolat','Gifts',-12.00,'',1,0,0),(6355,'2015-02-11','HXSAM','Paypal','Miscellaneous',-9.00,'',1,0,0),(6356,'2015-02-11','HXSAM','Amazon','Gifts',-14.86,'Ben\'s birthday present',1,0,0),(6357,'2015-02-11','HXSAM','Amazon','Clothing : Harvey',-36.66,'Shoes for school',1,0,0),(6358,'2015-02-16','HXSAM','Amazon','Hobbies',-10.97,'Cycling light',1,0,0),(6359,'2015-02-16','FDCREDIT','TheTrainLine.com','Work:Expenses',-189.50,'',1,0,0),(6360,'2015-02-13','FDMARK','Cheque','Entertainment:Hobbies',-15.00,'',1,0,0),(6361,'2015-02-16','HXSAM','Sainsbury\'s','Gifts',-20.00,'Roses for Sam',1,0,0),(6362,'2015-02-13','HXSAM','LOYD MORR SELBY','Cash',-40.00,'',1,0,0),(6367,'2015-02-25','FDMARK','Aviva CS UK Ltd','Work:Expenses',193.30,'',1,0,0),(6368,'2015-02-27','FDMARK','<FDCREDIT>','Bills:Credit Card Payment',-193.30,'',1,0,6369),(6369,'2015-02-27','FDCREDIT','<FDMARK>','Bills:Credit Card Payment',193.30,'',1,0,6368),(6370,'2015-02-16','HXSAM','Love You Hair & Beauty','Beauty',-5.00,'',1,0,0),(6371,'2015-02-17','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(6372,'2015-02-18','HXSAM','Sainsbury\'s','Food:Groceries',-5.65,'Tea & Coffee',1,0,0),(6373,'2015-02-18','HXSAM','Mountain Warehouse','Clothing : Aimee',-17.98,'Clothes for school trip',1,0,0),(6374,'2015-02-18','FDMARK','Tesco Express','Food:Groceries',-20.24,'',1,0,0),(6375,'2015-02-18','HXSAM','Gap','Clothing : Harvey',-30.77,'',1,0,0),(6376,'2015-02-18','HXSAM','Trespass','Clothing : Aimee',-20.98,'',1,0,0),(6377,'2015-02-20','FDMARK','Tesco Garage','Bills:Motor',-45.50,'Golf Fillup',1,0,0),(6380,'2015-02-18','HXSAM','Paypal','Miscellaneous',-22.06,'',1,0,0),(6381,'2015-02-18','HXSAM','Amazon','Miscellaneous',-0.36,'',1,0,0),(6382,'2015-02-18','HXSAM','Amazon','Miscellaneous',-0.89,'',1,0,0),(6383,'2015-02-18','HXSAM','The Works','Gifts',-6.97,'',1,0,0),(6384,'2015-02-18','HXSAM','Amazon','Miscellaneous',-16.99,'',1,0,0),(6385,'2015-02-23','HXSAM','Trenchers','Food:Dining',-52.80,'',1,0,0),(6386,'2015-02-23','HXSAM','English Heritage','Entertainment:Days Out',-19.00,'',1,0,0),(6387,'2015-02-20','HXSAM','Cash','Cash',-50.00,'',1,0,0),(6388,'2015-02-20','HXSAM','Cash','Cash',-30.00,'',1,0,0),(6390,'2015-02-19','HXSAM','Amazon','Miscellaneous',-16.99,'',1,0,0),(6391,'2015-02-19','HXSAM','Tesco Clothing','Clothing',-25.50,'',1,0,0),(6394,'2015-02-23','HXSAM','Discovery Accomodation','Entertainment:Holidays',-9.00,'Swimming',1,0,0),(6399,'2015-02-25','HXSAM','Home Bargains','Food:Groceries',-21.44,'',1,0,0),(6396,'2015-02-23','HXSAM','Mountain Warehouse','Clothing : Aimee',-11.98,'Baselayers',1,0,0),(6397,'2015-02-23','HXSAM','Co-Op Group','Food:Groceries',-13.40,'',1,0,0),(6400,'2015-02-25','FDCREDIT','TheTrainLine.com','Work:Expenses',-165.00,'',1,0,0),(6401,'2015-02-27','FDMARK','Aviva','Salary',3946.00,'',1,0,0),(6402,'2015-02-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1000.00,'',1,0,6403),(6403,'2015-02-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',1000.00,'',1,0,6402),(6404,'2015-02-27','HXSAM','DGS/RPP DD','Bills:Insurance',-12.59,'',1,0,0),(6405,'2015-03-02','FDMARK','Tesco','Food:Groceries',-122.49,'Weekly shopping',1,0,0),(6406,'2015-02-27','HXSAM','Selby College','Salary',609.91,'',1,0,0),(6407,'2015-03-04','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(6408,'2015-03-03','HXSAM','Weekly Cash - Sam','Cash:Regular',-10.00,'',1,0,0),(6409,'2015-03-01','FDMARK','Animal Friends','Insurance Rufus',-4.36,'',1,0,0),(6410,'2015-03-01','FDMARK','Animal Friends','Insurance Gracie',-4.36,'',1,0,0),(6411,'2015-03-01','FDMARK','DGS/RPP DD','Insurance',-5.34,'',1,0,0),(6412,'2015-03-01','FDMARK','Halifax','Bills:Mortgage',-422.71,'',1,0,0),(6413,'2015-03-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(6414,'2015-03-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,6415),(6415,'2015-03-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,6414),(6416,'2015-03-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(6555,'2015-03-19','FDMARK','Tesco Express','Food:Groceries',-11.63,'',1,0,0),(6418,'2015-03-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:TV',-12.12,'',1,0,0),(6419,'2015-03-01','FDMARK','H3G','Bills:Mobile Phones',-33.38,'Sam\'s phone',1,0,0),(6420,'2015-03-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,6421),(6421,'2015-03-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,6420),(6422,'2015-03-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'',1,0,0),(6423,'2015-03-01','HXSAM','Pet Health Plan','Insurance',-18.98,'',1,0,0),(6424,'2015-03-01','FDMARK','Legal & General','Insurance',-37.85,'',1,0,0),(6425,'2015-03-02','HXSAM','DGS/RPP DD','Insurance',-7.99,'',1,0,0),(6426,'2015-03-04','FDMARK','Aviva Healthcare','Insurance',-65.14,'',1,0,0),(6427,'2015-03-05','FDMARK','Aviva Household','Insurance',-14.13,'',1,0,0),(6428,'2015-03-09','FDMARK','BT','Bills:Utilities',-49.23,'',1,0,0),(6429,'2015-03-09','FDMARK','Nationwide Banking Services','Bills:Loans',-371.82,'',1,0,0),(6430,'2015-03-16','FDMARK','Tesco Garage','Bills:Motor',-53.53,'BMW fillup',1,0,0),(6431,'2015-03-12','FDMARK','Tesco Garage','Bills:Motor',-61.33,'Golf fillup',1,0,0),(6432,'2015-03-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Cycle locker',1,0,0),(6433,'2015-03-17','FDMARK','Deezer','Entertainment:Music',-9.99,'',1,0,0),(6434,'2015-03-16','HXSAM','Web Hosting','Entertainment:Hobbies',-3.60,'Tonksdev.co.uk',1,0,0),(6556,'2015-03-20','HXSAM','Amazon','Computer',-14.99,'Powerline adapters',1,0,0),(6557,'2015-03-19','RAINYDAY','<HXSAM>','Entertainment:Holidays',-1628.00,'Pay balance of holiday',1,0,6558),(6437,'2015-03-22','FDMARK','H3G','Bills:Mobile Phones',-15.30,'',1,0,0),(6438,'2015-03-22','FDMARK','H3G','Bills:Mobile Phones',-10.00,'',1,0,0),(6439,'2015-03-23','HXSAM','Learnable','Entertainment:Hobbies',-6.13,'',1,0,0),(6440,'2015-03-23','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',1,0,0),(6441,'2015-03-23','HXSAM','Non-stg Trans Fee','Bills:Banking',-0.16,'',1,0,0),(6442,'2015-03-26','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(6587,'2015-03-26','NEXTCARD','Next','Clothing',-12.00,'Black trousers',1,0,0),(6586,'2015-03-26','HXSAM','Paypal','Gifts',-31.99,'',1,0,0),(6588,'2015-03-26','NEXTCARD','Next','Clothing',-87.00,'Misc',1,0,0),(6474,'2015-03-04','HXSAM','Paypal','Entertainment:Hobbies',-209.99,'New Laptop for Sam',1,0,0),(6475,'2015-03-02','HXSAM','Brantano','Clothing',-35.95,'Shoes for Aimee',1,0,0),(6448,'2015-03-19','HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',1,0,0),(6449,'2015-03-19','HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',1,0,0),(6522,'2015-03-09','FDMARK','Home Bargains','Food:Groceries',-12.13,'',1,0,0),(6521,'2015-03-09','HXSAM','Thompson Holidays','Entertainment:Holidays',-250.00,'Balance of holiday',1,0,0),(6452,'2015-03-09','FDMARK','Tesco','Food:Groceries',-152.02,'Weekly shopping',1,0,0),(6523,'2015-03-09','HXSAM','Amazon','Refund',4.30,'',1,0,0),(6454,'2015-03-08','HXSAM','Weekly Cash - Sam','Cash:Regular',-40.00,'',1,0,0),(6544,'2015-03-16','HXSAM','Paypal','Gifts',-5.25,'',1,0,0),(6545,'2015-03-16','HXSAM','Paypal','Gifts',-5.38,'',1,0,0),(6546,'2015-03-16','HXSAM','Paypal','Gifts',-12.80,'',1,0,0),(6457,'2015-03-16','FDMARK','Tesco','Food:Groceries',-118.66,'Weekly shopping',1,0,0),(6458,'2015-03-16','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(6459,'2015-03-19','HXSAM','Weekly Cash - Sam','Cash:Regular',-30.00,'',1,0,0),(6562,'2015-04-01','FDMARK','Bahnstormer','Bills:Motor',-275.00,'',1,0,0),(6565,'2015-03-21','NEXTCARD','Next','Clothing',77.00,'Pyjamas, boots, trainers',1,0,0),(6462,'2015-03-23','FDMARK','Tesco','Food:Groceries',-141.81,'Weekly shopping',1,0,0),(6463,'2015-03-26','HXSAM','Weekly Cash - Mark','Cash:Regular',-30.00,'',1,0,0),(6464,'2015-03-26','HXSAM','Weekly Cash - Sam','Cash:Regular',-10.00,'',1,0,0),(6465,'2015-03-03','FDMARK','Aviva CS UK Ltd','Work:Expenses',168.80,'',1,0,0),(6466,'2015-03-03','FDMARK','<FDCREDIT>','Bills:Credit Card Payment',-206.17,'',1,0,6467),(6467,'2015-03-03','FDCREDIT','<FDMARK>','Bills:Credit Card Payment',206.17,'',1,0,6466),(6554,'2015-03-18','NEXTCARD','Samantha Tonks','Savings',150.80,'',1,0,0),(6564,'2015-03-31','FDMARK','DVLA','Bills:Motor',-30.00,'TO PAY ON 31/03',1,0,0),(6563,'2015-03-27','HXSAM','Cash','Bills:Motor',-200.00,'Pay for car service & MOT',1,0,0),(6472,'2015-02-27','FDMARK','Martin Broadhead','Other Income',80.00,'Martin\'s NFL ticket',1,0,0),(6473,'2015-03-02','HXSAM','Ticketmaster','Entertainment:Days Out',-124.25,'Mark\'s birthday present',1,0,0),(6476,'2015-03-02','HXSAM','Hunters','Beauty:Haircut',-37.00,'Hair cut for Sam & Aimee',1,0,0),(6477,'2015-02-28','FDMARK','<HXSAM>','Transfer',-300.00,'Repay laptop & birthday present',1,0,6478),(6478,'2015-02-28','HXSAM','<FDMARK>','Transfer',300.00,'Repay laptop & birthday present',1,0,6477),(6479,'2015-03-02','HXSAM','Chiquitos','Food:Dining',-95.60,'',1,0,0),(6480,'2015-03-02','HXSAM','Gap','Clothing : Sam',-46.17,'',1,0,0),(6656,'2015-03-28','FDMARK','<HXSAM>','Savings',-150.00,'',1,0,6657),(6481,'2015-03-02','HXSAM','Cineworld','Entertainment:Days Out',-14.40,'',1,0,0),(6486,'2015-03-01','SAVACC','<BILLSACC>','Transfer',200.00,'',1,0,6485),(6484,'2015-03-01','BILLSACC','TEST Employer','Salary',1500.00,'',1,0,0),(6487,'2015-03-01','BILLSACC','<SPENDACC>','Transfer',-500.00,'',1,0,6488),(6488,'2015-03-01','SPENDACC','<BILLSACC>','Transfer',500.00,'',1,0,6487),(6489,'2015-03-01','CREDACC','Amazon','Gifts',-59.99,'',1,0,0),(6490,'2015-03-02','BILLSACC','E.On','Bills: Energy',-109.00,'',1,0,0),(6491,'2015-03-02','BILLSACC','British Telecom','Bills: Telephone',-53.39,'',1,0,0),(6492,'2015-03-02','SPENDACC','Amazon','Entertainment: Books',-4.99,'',1,0,0),(6493,'2015-03-03','SPENDACC','Amazon','Entertainment: DVDs',-14.99,'',1,0,0),(6494,'2015-03-02','HXSAM','Cash','Cash',-40.00,'',1,0,0),(6495,'2015-03-02','HXSAM','JustGiving','Charity',-10.00,'',1,0,0),(6496,'2015-03-02','HXSAM','Cineworld','Entertainment:Days Out',-13.42,'',1,0,0),(6497,'2015-03-03','HXSAM','Amazon','Miscellaneous',-14.00,'',1,0,0),(6498,'2015-03-03','HXSAM','Amazon','Miscellaneous',-18.74,'',1,0,0),(6499,'2015-02-24','RAINYDAY','Halifax','Interest',8.64,'',1,0,0),(6500,'2015-03-04','FDMARK','Aldi','Food:Groceries',-20.07,'',1,0,0),(6501,'2015-03-04','HXSAM','Paypal','Entertainment:Hobbies',-9.50,'',1,0,0),(6502,'2015-03-04','HXSAM','<NEXTCARD>','Clothing',-11.73,'',1,0,6503),(6503,'2015-03-04','NEXTCARD','<HXSAM>','Clothing',11.73,'',1,0,6502),(6504,'2015-03-05','HXSAM','Amazon','Miscellaneous',-2.99,'Book',1,0,0),(6505,'2015-03-05','HXSAM','Paypal','Gifts',-15.00,'',1,0,0),(6506,'2015-03-09','HXSAM','Amazon','Books',-30.88,'Architecture book',1,0,0),(6507,'2015-03-06','HXSAM','Paypal','Gifts',-10.74,'',1,0,0),(6508,'2015-03-06','SPENDACC','CPC','Entertainment: Hobbies',-46.99,'',1,0,0),(6509,'2015-03-06','SPENDACC','Amazon','Entertainment: Hobbies',-21.99,'',1,0,0),(6510,'2015-03-06','BILLSACC','Yorkshire Water','Bills: Water',-40.00,'',1,0,0),(6511,'2015-03-09','HXSAM','Homebase','Household',-69.97,'Washing basket, light bulbs, etc.',1,0,0),(6512,'2015-03-09','HXSAM','Tesco','Refund',24.00,'',1,0,0),(6513,'2015-03-09','FDMARK','Tesco','Food:Groceries',-7.25,'',1,0,0),(6534,'2015-03-16','FDMARK','Tesco Express','Food:Groceries',-5.50,'Selby times & flowers',1,0,0),(6515,'2015-03-06','NEXTACC','Next','Clothing',-12.99,'Trousers',1,0,0),(6516,'2015-03-06','NEXTACC','Next','Clothing',-14.99,'T Shirt',1,0,0),(6517,'2015-03-06','NEXTACC','Next','Clothing',14.99,'T Shirt',1,0,0),(6518,'2015-03-09','FDMARK','Aldi','Food:Groceries',-13.06,'',1,0,0),(6519,'2015-03-07','RAINYDAY','<HXSAM>','Entertainment:Holidays',-250.00,'Remaining balance for Cape Verde',1,0,6520),(6520,'2015-03-07','HXSAM','<RAINYDAY>','Entertainment:Holidays',250.00,'Remaining balance for Cape Verde',1,0,6519),(6529,'2015-03-11','FDMARK','Tesco Express','Food:Groceries',-6.97,'',1,0,0),(6524,'2015-03-09','HXSAM','Tesco','Food:Groceries',-4.34,'',1,0,0),(6525,'2015-03-09','HXSAM','Amazon','Books',-4.98,'',1,0,0),(6526,'2015-03-10','HXSAM','Sainsbury\'s','Gifts',-26.78,'',1,0,0),(6527,'2015-03-10','HXSAM','Amazon','Gifts',-67.54,'',1,0,0),(6530,'2015-03-11','HXSAM','Paypal','Gifts',-6.79,'',1,0,0),(6531,'2015-03-11','HXSAM','Paypal','Gifts',-4.38,'',1,0,0),(6532,'2015-03-13','HXSAM','Argos','Household',-42.92,'Aimee\'s headphones and hairdryer',1,0,0),(6533,'2015-03-13','HXSAM','Amazon','Gifts',-3.25,'',1,0,0),(6535,'2015-03-13','HXSAM','Paypal','Gifts',-4.09,'',1,0,0),(6536,'2015-03-13','HXSAM','Cash','Cash',-30.00,'Money for Sam\'s night out',1,0,0),(6537,'2015-03-16','HXSAM','ITunes.com','Entertainment:Hobbies',-13.10,'Mythbusters Season 6',1,0,0),(6538,'2015-03-16','HXSAM','Wh Smith','Gifts',-38.08,'',1,0,0),(6539,'2015-03-16','HXSAM','Sainsbury\'s','Gifts',-27.00,'',1,0,0),(6540,'2015-03-16','HXSAM','The Giant Bellflower','Food:Dining',-7.79,'',1,0,0),(6541,'2015-03-17','HXSAM','The Kings Head','Food:Dining',-102.35,'',1,0,0),(6542,'2015-03-13','FDCREDIT','TheTrainLine.com','Work:Expenses',-165.00,'',1,0,0),(6543,'2015-03-17','FDMARK','Apcoa','Work:Expenses',-3.80,'',1,0,0),(6547,'2015-03-16','HXSAM','Paypal','Gifts',-150.80,'',1,0,0),(6548,'2015-03-16','HXSAM','HALL JE&RH','Other Income',50.00,'Pay for dinner on mothers day',1,0,0),(6549,'2015-03-16','HXSAM','Amazon','Gifts',-2.94,'',1,0,0),(6550,'2015-03-16','HXSAM','Amazon','Gifts',-2.94,'',1,0,0),(6551,'2015-03-18','HXSAM','Microsoft Xbox Live','Entertainment:Games',-2.39,'',1,0,0),(6552,'2015-03-18','HXSAM','Microsoft Xbox Live','Entertainment:Games',-2.39,'',1,0,0),(6553,'2015-03-18','FDMARK','Tesco Express','Food:Groceries',-7.35,'',1,0,0),(6558,'2015-03-19','HXSAM','<RAINYDAY>','Entertainment:Holidays',1628.00,'Pay balance of holiday',1,0,6557),(6560,'2015-03-20','HXSAM','Amazon','Miscellaneous',-2.94,'',1,0,0),(6561,'2015-03-20','HXSAM','Jolleys Pet Food','Pets',-10.89,'',1,0,0),(6566,'2015-03-21','NEXTCARD','Next','Interest',-4.80,'',1,0,0),(6567,'2015-03-21','NEXTCARD','Next','Clothing',-28.00,'Charcoal Frill Top',1,0,0),(6568,'2015-03-21','NEXTCARD','Next','Clothing',-35.00,'Cardi',1,0,0),(6569,'2015-03-21','NEXTCARD','Next','Clothing',35.00,'Cardi',1,0,0),(6571,'2015-04-17','HXSAM','<NEXTCARD>','Clothing',-189.76,'Pay off the clothes from this month',1,0,6572),(6572,'2015-04-17','NEXTCARD','<HXSAM>','Clothing',189.76,'Pay off the clothes from this month',0,0,6571),(6573,'2015-03-21','FDMARK','Cash','Home:Furniture',-160.00,'2x new mattresses for kids',1,0,0),(6574,'2015-03-23','HXSAM','Cineworld','Entertainment:Days Out',-13.24,'',1,0,0),(6575,'2015-03-23','HXSAM','Cineworld','Entertainment:Days Out',-20.08,'',1,0,0),(6576,'2015-03-23','HXSAM','C Danks','Other Income',7.00,'',1,0,0),(6577,'2015-03-23','HXSAM','Cineworld','Refund',3.24,'',1,0,0),(6578,'2015-03-25','FDMARK','Pret A Manger','Food',-6.38,'',1,0,0),(6579,'2015-03-26','FDMARK','Pret A Manger','Food',-7.63,'',1,0,0),(6580,'2015-03-25','HXSAM','Apple ITunes','Entertainment:Hobbies',-11.06,'',1,0,0),(6581,'2015-03-25','HXSAM','Paypal','Gifts',-1.99,'',1,0,0),(6582,'2015-03-25','HXSAM','Paypal','Gifts',-3.79,'',1,0,0),(6583,'2015-03-25','FDCREDIT','TheTrainLine.com','Work:Expenses',-219.00,'',1,0,0),(6584,'2015-03-26','FDCREDIT','Travelodge','Work:Expenses',-144.00,'',1,0,0),(6585,'2015-03-26','FDCREDIT','Goodman\'s Field','Work:Expenses',-7.49,'',1,0,0),(6589,'2015-03-27','FDMARK','Aviva','Salary',13906.00,'',1,0,0),(6590,'2015-03-28','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1000.00,'',1,0,6591),(6591,'2015-03-28','HXSAM','<FDMARK>','Transfer:Monthly Spends',1000.00,'',1,0,6590),(6592,'2015-03-27','HXSAM','DGS/RPP DD','Bills:Insurance',-12.59,'',1,0,0),(6593,'2015-03-30','FDMARK','Tesco','Food:Groceries',-124.84,'Weekly shopping',1,0,0),(6594,'2015-03-31','HXSAM','Selby College','Salary',623.25,'',1,0,0),(6695,'2015-04-01','HXSAM','Amazon','Miscellaneous',-18.64,'',1,0,0),(6597,'2015-04-02','FDMARK','Animal Friends','Insurance Rufus',-4.36,'',1,0,0),(6598,'2015-04-02','FDMARK','Animal Friends','Insurance Gracie',-4.36,'',1,0,0),(6599,'2015-04-01','FDMARK','DGS/RPP DD','Insurance',-5.34,'',1,0,0),(6600,'2015-04-01','FDMARK','Halifax','Bills:Mortgage',-422.71,'',1,0,0),(6601,'2015-04-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(6602,'2015-04-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,6603),(6603,'2015-04-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,6602),(6604,'2015-04-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(6605,'2015-04-01','FDMARK','Direct Debit - Selby District Council','Bills:Tax',-157.60,'',1,0,0),(6606,'2015-04-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:TV',-12.12,'',1,0,0),(6607,'2015-03-30','FDMARK','H3G','Bills:Mobile Phones',-35.36,'Sam\'s phone',1,0,0),(6608,'2015-04-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,6609),(6609,'2015-04-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',1,0,6608),(6610,'2015-04-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'',1,0,0),(6611,'2015-04-01','HXSAM','Pet Health Plan','Insurance',-18.98,'',1,0,0),(6612,'2015-04-01','FDMARK','Legal & General','Insurance',-37.85,'',1,0,0),(6613,'2015-04-02','HXSAM','DGS/RPP DD','Insurance',-7.99,'',1,0,0),(6614,'2015-04-08','FDMARK','Aviva Healthcare','Insurance',-65.14,'',1,0,0),(6615,'2015-04-09','FDMARK','Aviva Household','Insurance',-14.13,'',1,0,0),(6616,'2015-04-07','FDMARK','BT','Bills:Utilities',-48.25,'',1,0,0),(6617,'2015-04-09','FDMARK','Nationwide Banking Services','Bills:Loans',-371.82,'',1,0,0),(6618,'2015-04-27','FDMARK','Tesco Garage','Bills:Motor',-54.03,'BMW fillup',1,0,0),(6619,'2015-04-07','FDMARK','Tesco Garage','Bills:Motor',-44.94,'Golf fillup',1,0,0),(6620,'2015-04-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Cycle locker',1,0,0),(6621,'2015-04-15','FDMARK','Deezer','Entertainment:Music',-9.99,'',1,0,0),(6622,'2015-04-14','HXSAM','Web Hosting','Entertainment:Hobbies',-3.60,'Tonksdev.co.uk',1,0,0),(6623,'2015-04-22','FDMARK','H3G','Bills:Mobile Phones',-15.10,'',1,0,0),(6624,'2015-04-22','FDMARK','H3G','Bills:Mobile Phones',-10.00,'',1,0,0),(6625,'2015-04-23','HXSAM','Learnable','Entertainment:Hobbies',-6.05,'',1,0,0),(6626,'2015-04-23','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',1,0,0),(6627,'2015-04-23','HXSAM','Non-stg Trans Fee','Bills:Banking',-0.16,'',1,0,0),(6628,'2015-04-27','FDMARK','Tesco','Delivery Charge',-6.00,'',1,0,0),(6850,'2015-04-27','HXSAM','Next','Clothing',-48.00,'',1,0,0),(6777,'2015-04-27','FDMARK','B&M bargains','Household',-22.86,'',1,0,0),(6778,'2015-04-27','FDMARK','Tesco Express','Food:Groceries',-13.51,'',1,0,0),(6659,'2015-03-27','FDMARK','<RAINYDAY>','Savings',-5000.00,'',1,0,6660),(6660,'2015-03-27','RAINYDAY','<FDMARK>','Savings',5000.00,'',1,0,6659),(6634,'2015-04-21','HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',1,0,0),(6635,'2015-04-21','HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',1,0,0),(6702,'2015-04-07','FDMARK','Flamingo Land','Entertainment:Days Out',-100.00,'',1,0,0),(6849,'2015-04-27','HXSAM','Next','Clothing',-35.00,'',1,0,0),(6703,'2015-04-07','HXSAM','Love You Hair & Beauty','Beauty',-27.00,'Sam\'s Nails',1,0,0),(6638,'2015-04-07','FDMARK','Tesco','Food:Groceries',-157.15,'Weekly shopping',1,0,0),(6736,'2015-04-13','HXSAM','Cineworld','Entertainment:Days Out',-9.37,'',1,0,0),(6729,'2015-04-13','HXSAM','The Wishing Well','Food:Dining',-8.25,'',1,0,0),(6730,'2015-04-13','HXSAM','Post Office Counters','Bills:Postage',-11.08,'',1,0,0),(6643,'2015-04-13','FDMARK','Tesco','Food:Groceries',-90.32,'Weekly shopping',1,0,0),(6644,'2015-04-15','HXSAM','Weekly Cash - Mark','Cash:Regular',-40.00,'',1,0,0),(6645,'2015-04-15','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(6764,'2015-04-20','FDMARK','Home Bargains','Food:Groceries',-20.54,'',1,0,0),(6763,'2015-04-20','HXSAM','Argos','Gifts',-19.99,'NERF gun for Harvey',1,0,0),(6648,'2015-04-20','FDMARK','Tesco','Food:Groceries',-131.88,'Weekly shopping',1,0,0),(6649,'2015-04-20','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',1,0,0),(6650,'2015-04-21','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(6779,'2015-04-27','HXSAM','B&M bargains','Household',-9.03,'',1,0,0),(6780,'2015-04-27','HXSAM','Halfords','Hobbies',-9.99,'Bike Service',1,0,0),(6781,'2015-04-27','HXSAM','Halfords','Hobbies',-19.99,'Bike Service Plan',1,0,0),(6653,'2015-03-28','FDMARK','<RAINYDAY>','Savings',-2500.00,'Bonus',1,0,6654),(6654,'2015-03-28','RAINYDAY','<FDMARK>','Savings',2500.00,'Bonus',1,0,6653),(6655,'2015-04-13','FDMARK','Tesco Garage','Bills:Motor',-41.56,'Captur fillup',1,0,0),(6657,'2015-03-28','HXSAM','<FDMARK>','Savings',150.00,'',1,0,6656),(6658,'2015-03-27','HXSAM','Paypal','Gifts',-16.00,'',1,0,0),(6661,'2015-04-14','HXSAM','Greenthumb','Garden',-17.00,'',1,0,0),(6662,'2015-03-28','NEXTCARD','Next','Clothing',-114.00,'Misc',0,0,0),(6663,'2015-03-28','NEXTCARD','Next','Clothing',84.00,'Misc',0,0,0),(6664,'2015-03-28','NEXTCARD','Next','Clothing',-70.00,'Misc',0,0,0),(6665,'2015-03-28','NEXTCARD','Next','Clothing',24.50,'MIsc',0,0,0),(6674,'2015-03-30','FDMARK','First Direct','Other Income',7000.00,'Personal Loan for car',1,0,0),(6668,'2015-03-30','HXSAM','Boots','Medical',-21.66,'',1,0,0),(6669,'2015-03-30','FDMARK','Home Bargains','Food:Groceries',-9.40,'',1,0,0),(6670,'2015-03-30','HXSAM','The Tree House','Food:Dining',-38.50,'',1,0,0),(6671,'2015-04-01','HXSAM','Amazon','Miscellaneous',-20.71,'Aimee\'s graphics tablet',1,0,0),(6672,'2015-04-13','HXSAM','Rachel Hall','Gifts',-20.00,'Pay for half of Mum\'s birthday present',1,0,0),(6673,'2015-03-31','FDMARK','Motordepot','Bills:Motor',-100.00,'Deposit for new car',1,0,0),(6675,'2015-04-04','RAINYDAY','<FDMARK>','Savings',-2500.00,'',1,0,6676),(6676,'2015-04-04','FDMARK','<RAINYDAY>','Savings',2500.00,'',1,0,6675),(6677,'2015-04-09','FDMARK','Motordepot','Bills:Motor',-12289.00,'Balance of car',1,0,0),(6678,'2015-03-30','FDMARK','Aviva CS UK Ltd','Work:Expenses',168.80,'',1,0,0),(6679,'2015-03-30','HXSAM','Paypal','Gifts',-5.49,'',1,0,0),(6680,'2015-03-30','HXSAM','Crunchyroll','Entertainment:Hobbies',-4.99,'Anime VOD',1,0,0),(6681,'2015-03-30','FDMARK','<FDCREDIT>','Bills:Credit Card Payment',-168.80,'',1,0,6682),(6682,'2015-03-30','FDCREDIT','<FDMARK>','Bills:Credit Card Payment',168.80,'',1,0,6681),(6683,'2015-03-30','FDCREDIT','Ticketmaster','Entertainment:Days Out',-58.95,'Sarah Millican tickets',1,0,0),(6684,'2015-04-02','FDMARK','Aviva CS UK Ltd','Work:Expenses',370.49,'',1,0,0),(6685,'2015-04-02','FDMARK','<FDCREDIT>','Work:Expenses',-370.49,'',1,0,6686),(6686,'2015-04-02','FDCREDIT','<FDMARK>','Work:Expenses',370.49,'',1,0,6685),(6687,'2015-03-31','HXSAM','Amazon','Miscellaneous',-5.50,'',1,0,0),(6688,'2015-03-31','HXSAM','Amazon','Miscellaneous',-11.99,'',1,0,0),(6689,'2015-04-07','FDMARK','Manchester Airport T1','Entertainment:Holidays',-40.08,'Car parking for Cape Verde',1,0,0),(6690,'2015-04-07','HXSAM','Partylite','Home',-77.90,'Four candles',1,0,0),(6691,'2015-04-01','HXSAM','Aimee\'s Savings','Savings',-10.00,'',1,0,0),(6692,'2015-04-01','HXSAM','Harvey\'s Savings','Savings',-10.00,'',1,0,0),(6693,'2015-04-01','HXSAM','Apple ITunes','Entertainment:Hobbies',-5.99,'Red Dwarf series 2',1,0,0),(6694,'2015-04-01','HXSAM','Paypal','Gifts',-5.90,'',1,0,0),(6696,'2015-04-02','RAINYDAY','<HXSAM>','Bills:Motor',-350.00,'Pay for car insurance',1,0,6697),(6697,'2015-04-02','HXSAM','<RAINYDAY>','Bills:Motor',350.00,'Pay for car insurance',1,0,6696),(6698,'2015-05-22','RAINYDAY','Stuart Barber','Other Income',3000.00,'Payment for Golf',0,0,0),(6699,'2015-04-07','HXSAM','Aviva Motor','Bills:Insurance',-350.81,'',1,0,0),(6700,'2015-04-07','HXSAM','The Wishing Well','Food:Dining',-47.11,'',1,0,0),(6701,'2015-04-02','HXSAM','Cineworld','Entertainment:Days Out',-5.72,'',1,0,0),(6704,'2015-04-07','HXSAM','Dorothy Perkins','Clothing:Sam',-30.00,'',1,0,0),(6705,'2015-04-07','FDMARK','B&M bargains','Household',-9.82,'',1,0,0),(6706,'2015-04-07','HXSAM','Flamingo Land','Food:Dining',-4.35,'Drinks ',1,0,0),(6707,'2015-04-05','HXSAM','Cash','Cash',-40.00,'Cash for Flamingo Land',1,0,0),(6708,'2015-04-07','HXSAM','Cash','Cash',-40.00,'',1,0,0),(6709,'2015-04-07','HXSAM','Amazon','Miscellaneous',-2.94,'',1,0,0),(6710,'2015-04-07','HXSAM','Amazon','Miscellaneous',-12.49,'',1,0,0),(6711,'2015-04-07','HXSAM','Amazon','Miscellaneous',-13.99,'',1,0,0),(6712,'2015-04-07','HXSAM','Amazon','Miscellaneous',-2.90,'',1,0,0),(6713,'2015-04-07','HXSAM','Amazon','Miscellaneous',-46.99,'',1,0,0),(6714,'2015-04-07','NEXTCARD','Next','Clothing',-10.00,'ANI GRY JERSEY SHORT',0,0,0),(6715,'2015-04-08','FDMARK','Tesco','Food:Groceries',-26.95,'',1,0,0),(6716,'2015-04-08','HXSAM','Paypal','Gifts',-17.42,'',1,0,0),(6717,'2015-04-09','FDMARK','Sainsbury\'s','Food:Groceries',-13.50,'',1,0,0),(6718,'2015-04-09','FDMARK','Tesco Express','Food:Groceries',-27.56,'',1,0,0),(6719,'2015-04-11','NEXTCARD','Next','Clothing',-6.50,'Navy Ditsy Cullotte\r\n',0,0,0),(6720,'2015-04-09','HXSAM','Paypal','Gifts',-9.99,'',1,0,0),(6721,'2015-04-09','HXSAM','Yorkshire Trading','Hobbies',-10.90,'',1,0,0),(6722,'2015-04-09','HXSAM','Wilkinsons','Food:Groceries',-16.00,'',1,0,0),(6723,'2015-04-09','HXSAM','Amazon','Miscellaneous',-23.46,'',1,0,0),(6724,'2015-04-09','HXSAM','Amazon','Miscellaneous',-29.95,'',1,0,0),(6725,'2015-04-09','HXSAM','Apple ITunes','Entertainment:Hobbies',-9.99,'',1,0,0),(6726,'2015-04-10','HXSAM','Paypal','Other Income',60.00,'',1,0,0),(6727,'2015-04-10','HXSAM','Cash','Cash',-50.00,'',1,0,0),(6728,'2015-04-10','HXSAM','Amazon','Miscellaneous',-2.94,' ',1,0,0),(6731,'2015-04-12','RAINYDAY','<HXSAM>','Gifts',-400.00,'Mark\'s birthday present',1,0,6732),(6732,'2015-04-12','HXSAM','<RAINYDAY>','Gifts',400.00,'Mark\'s birthday present',1,0,6731),(6733,'2015-04-12','HXSAM','Paypal','Other Income',30.00,'',1,0,0),(6734,'2015-04-13','NEXTCARD','Next','Clothing',-260.00,'',0,0,0),(6735,'2015-04-13','NEXTCARD','Next','Clothing',20.00,'White shirt (Mark)',0,0,0),(6737,'2015-04-13','HXSAM','Amazon','Miscellaneous',-439.99,'Mark\'s birthday present (I wonder what it is!!!)',1,0,0),(6738,'2015-04-13','HXSAM','Cineworld','Entertainment:Days Out',-13.24,'',1,0,0),(6739,'2015-04-13','FDMARK','Cheque','Entertainment:Hobbies',-27.00,'',1,0,0),(6740,'2015-04-13','FDCREDIT','TheTrainLine.com','Work:Expenses',-116.00,'',1,0,0),(6741,'2015-02-28','FORTHEFUTURE','First Direct','Interest',0.33,'',1,0,0),(6742,'2015-03-31','FORTHEFUTURE','First Direct','Interest',0.36,'',1,0,0),(6743,'2015-05-08','HXSAM','<NEXTCARD>','Clothing',-90.00,'',0,0,6744),(6744,'2015-05-08','NEXTCARD','<HXSAM>','Clothing',90.00,'',0,0,6743),(6745,'2015-04-15','FDMARK','Park & Ride','Bills:Transport',-10.00,'',1,0,0),(6746,'2015-04-16','FDMARK','Cheque','Entertainment:Hobbies',-25.00,'Aimee\'s Guides',1,0,0),(6747,'2015-04-17','FDMARK','Tesco Express','Food:Groceries',-6.55,'',1,0,0),(6748,'2015-04-15','HXSAM','Amazon','Miscellaneous',-3.49,'',1,0,0),(6749,'2015-04-15','HXSAM','Tesco Express','Food:Groceries',-7.84,'',1,0,0),(6750,'2015-04-15','HXSAM','Amazon','Miscellaneous',-11.87,'',1,0,0),(6751,'2015-04-15','HXSAM','Amazon','Miscellaneous',-14.99,'',1,0,0),(6752,'2015-04-15','HXSAM','Amazon','Miscellaneous',-22.94,'',1,0,0),(6753,'2015-04-15','HXSAM','Home Bargains','Food:Groceries',-11.75,'',1,0,0),(6754,'2015-04-15','HXSAM','Amazon','Miscellaneous',-11.95,'',1,0,0),(6755,'2015-04-16','HXSAM','Thorntons','Gifts',-8.00,'',1,0,0),(6756,'2015-04-16','HXSAM','Menkind','Gifts',-10.00,'',1,0,0),(6757,'2015-04-16','HXSAM','The Entertainer','Gifts',-11.00,'',1,0,0),(6758,'2015-04-16','HXSAM','Boots','Medical',-12.36,'',1,0,0),(6759,'2015-04-16','HXSAM','Menkind','Gifts',-19.98,'',1,0,0),(6760,'2015-04-16','HXSAM','Primark','Clothing',-20.00,'',1,0,0),(6761,'2015-04-16','HXSAM','Debenhams','Clothing',-24.00,'',1,0,0),(6762,'2015-04-16','HXSAM','Wh Smith','Gifts',-29.98,'',1,0,0),(6765,'2015-04-20','HXSAM','Love You Hair & Beauty','Beauty',-17.50,'',1,0,0),(6766,'2015-04-21','FDMARK','Tesco','Food:Groceries',-12.50,'',1,0,0),(6767,'2015-04-20','HXSAM','Snapfish','Gifts',-22.15,'',1,0,0),(6768,'2015-04-23','HXSAM','Amazon','Entertainment',-12.99,'Headphones',1,0,0),(6769,'2015-04-16','FDCREDIT','IHG Hotels','Work:Expenses',-159.60,'',1,0,0),(6770,'2015-04-23','FDMARK','Tesco Express','Food:Groceries',-6.72,'',1,0,0),(6771,'2015-04-30','FDMARK','Aviva CS UK Ltd','Work:Expenses',440.60,'',1,0,0),(6772,'2015-04-20','FDCREDIT','TheTrainLine.com','Work:Expenses',-165.00,'',1,0,0),(6773,'2015-04-30','FDMARK','<FDCREDIT>','Work:Expenses',-495.75,'',1,0,6774),(6774,'2015-04-30','FDCREDIT','<FDMARK>','Work:Expenses',495.75,'',0,0,6773),(6775,'2015-04-24','HXSAM','Ticketmaster','Entertainment:Days Out',-59.70,'Tickets for Alan Davies in November',1,0,0),(6776,'2015-04-27','FDMARK','Tesco','Food:Groceries',-154.49,'Weekly shopping',1,0,0),(6782,'2015-04-27','HXSAM','The Owl Hotel','Food:Dining',-48.70,'Lunch',1,0,0),(6783,'2015-04-26','HXSAM','Cash','Cash',-50.00,'',1,0,0),(6784,'2015-04-27','FDMARK','Aviva','Salary',4000.00,'',1,0,0),(6785,'2015-04-27','FDMARK','<HXSAM>','Transfer:Monthly Spends',-1000.00,'',1,0,6786),(6786,'2015-04-27','HXSAM','<FDMARK>','Transfer:Monthly Spends',1000.00,'',1,0,6785),(6787,'2015-04-27','HXSAM','DGS/RPP DD','Bills:Insurance',-12.59,'',1,0,0),(6788,'2015-05-05','FDMARK','Tesco','Food:Groceries',-110.45,'Weekly shopping',1,0,0),(6789,'2015-04-30','HXSAM','Selby College','Salary',467.10,'',1,0,0),(6791,'2015-04-30','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',1,0,0),(6792,'2015-05-05','FDMARK','Animal Friends','Insurance Rufus',-4.36,'',1,0,0),(6793,'2015-05-05','FDMARK','Animal Friends','Insurance Gracie',-4.36,'',1,0,0),(6794,'2015-05-01','FDMARK','DGS/RPP DD','Insurance',-5.34,'',1,0,0),(6795,'2015-05-01','FDMARK','Halifax','Bills:Mortgage',-422.71,'',1,0,0),(6796,'2015-05-01','FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',1,0,0),(6797,'2015-05-01','FDMARK','<RAINYDAY>','Savings',-50.00,'',1,0,6798),(6798,'2015-05-01','RAINYDAY','<FDMARK>','Savings',50.00,'',1,0,6797),(6799,'2015-05-01','FDMARK','E.On','Bills:Utilities',-140.00,'',1,0,0),(6800,'2015-05-01','FDMARK','Direct Debit - Selby District ','Bills:Tax',-157.00,'',1,0,0),(6801,'2015-05-01','HXSAM','Direct Debit - TV Licence Mbp','Bills:TV',-12.12,'',1,0,0),(6802,'2015-04-30','FDMARK','H3G','Bills:Mobile Phones',-34.38,'Sam\'s phone',1,0,0),(6803,'2015-05-01','HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',1,0,6804),(6804,'2015-05-01','FORTHEFUTURE','<HXSAM>','Savings',25.00,'',0,0,6803),(6805,'2015-05-01','FDMARK','Legal & General','Bills:Insurance',-21.74,'',1,0,0),(6806,'2015-05-01','HXSAM','Pet Health Plan','Insurance',-19.96,'',1,0,0),(6807,'2015-05-01','FDMARK','Legal & General','Insurance',-37.85,'',1,0,0),(6808,'2015-05-01','HXSAM','DGS/RPP DD','Insurance',-7.99,'',1,0,0),(6809,'2015-05-07','FDMARK','Aviva Healthcare','Insurance',-65.14,'',0,0,0),(6810,'2015-05-07','FDMARK','Aviva Household','Insurance',-14.13,'',0,0,0),(6811,'2015-05-06','FDMARK','BT','Bills:Utilities',-48.47,'',0,0,0),(6812,'2015-05-09','FDMARK','Nationwide Banking Services','Bills:Loans',-371.82,'',0,0,0),(6813,'2015-05-10','FDMARK','Tesco Garage','Bills:Motor',-66.00,'BMW fillup',0,0,0),(6814,'2015-05-17','FDMARK','Tesco Garage','Bills:Motor',-65.00,'Captur fillup',0,0,0),(6815,'2015-05-15','FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Cycle locker',0,0,0),(6816,'2015-05-15','FDMARK','Deezer','Entertainment:Music',-9.99,'',0,0,0),(6817,'2015-05-16','HXSAM','Web Hosting','Entertainment:Hobbies',-3.60,'Tonksdev.co.uk',0,0,0),(6818,'2015-05-01','FDMARK','First Direct','Bills:Loans',-127.15,'Captur repayment',1,0,0),(6819,'2015-04-29','HXSAM','Crunchyroll','Entertainment:Hobbies',-4.99,'Anime VOD',1,0,0),(6820,'2015-05-22','FDMARK','H3G','Bills:Mobile Phones',-15.10,'',0,0,0),(6821,'2015-05-22','FDMARK','H3G','Bills:Mobile Phones',-10.00,'',0,0,0),(6822,'2015-05-24','HXSAM','Learnable','Entertainment:Hobbies',-5.62,'',0,0,0),(6823,'2015-05-24','HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',0,0,0),(6824,'2015-05-24','HXSAM','Non-stg Trans Fee','Bills:Banking',-0.15,'',0,0,0),(6825,'2015-05-25','FDMARK','Tesco','Delivery Charge',-6.00,'',0,0,0),(6826,'2015-05-26','HXSAM','CONTRA - MARK SPENDS','Personal:Spends',-180.31,'',0,1,0),(6827,'2015-05-26','HXSAM','CONTRA - SAM SPENDS','Personal:Spends',-108.00,'',0,1,0),(6828,'2015-05-26','FDMARK','CONTRA - SHOPPING OVERSPENDS','Food:Groceries',-41.61,'Placeholder for extra shopping each month',0,1,0),(6874,'2015-05-01','HXSAM','Cash','Cash',-20.00,'',1,0,0),(6875,'2015-05-01','RAINYDAY','<HXSAM>','Home:Furniture',-160.00,'Pay for garden furniture',1,0,6876),(6876,'2015-05-01','HXSAM','<RAINYDAY>','Home:Furniture',160.00,'Pay for garden furniture',1,0,6875),(6831,'2015-05-18','HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',0,0,0),(6832,'2015-05-18','HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',0,0,0),(6833,'2015-05-05','HXSAM','The RAC','Bills:Motor',-127.67,'Breakdown cover',1,0,0),(6834,'2015-05-05','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.75,'',1,0,0),(6835,'2015-05-06','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',0,0,0),(6836,'2015-05-08','HXSAM','Aimee Pocket Money','Pocket Money',-5.00,'Aimee\'s weekly pocket money',0,0,0),(6837,'2015-05-08','HXSAM','Harvey Pocket Money','Pocket Money',-5.00,'Harvey\'s weekly pocket money',0,0,0),(6838,'2015-05-11','FDMARK','Tesco','Food:Groceries',-140.00,'Weekly shopping',0,0,0),(6839,'2015-05-13','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',0,0,0),(6840,'2015-05-13','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',0,0,0),(6841,'2015-05-15','HXSAM','Aimee Pocket Money','Pocket Money',-5.00,'Aimee\'s weekly pocket money',0,0,0),(6842,'2015-05-15','HXSAM','Harvey Pocket Money','Pocket Money',-5.00,'Harvey\'s weekly pocket money',0,0,0),(6843,'2015-05-18','FDMARK','Tesco','Food:Groceries',-140.00,'Weekly shopping',0,0,0),(6844,'2015-05-20','HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',0,0,0),(6845,'2015-05-20','HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',0,0,0),(6846,'2015-05-22','HXSAM','Aimee Pocket Money','Pocket Money',-5.00,'Aimee\'s weekly pocket money',0,0,0),(6847,'2015-05-22','HXSAM','Harvey Pocket Money','Pocket Money',-5.00,'Harvey\'s weekly pocket money',0,0,0),(6848,'2015-05-25','FDMARK','Tesco','Food:Groceries',-140.00,'Weekly shopping',0,0,0),(6851,'2015-04-27','HXSAM','The Range','Household',-62.88,'',1,0,0),(6852,'2015-04-27','FDMARK','Travel Insurance','Entertainment:Holidays',-65.45,'',1,0,0),(6853,'2015-04-27','HXSAM','Paypal','Miscellaneous',-7.53,'',1,0,0),(6854,'2015-04-27','HXSAM','Post Office Counters','Bills:Postage',-3.90,'',1,0,0),(6855,'2015-04-27','HXSAM','Tesco Express','Food:Groceries',-7.49,'',1,0,0),(6856,'2015-04-27','HXSAM','The Range','Household',-35.00,'',1,0,0),(6857,'2015-04-28','HXSAM','Amazon','Gifts',-2.99,'',1,0,0),(6858,'2015-04-28','HXSAM','Amazon','Gifts',-4.49,'',1,0,0),(6859,'2015-04-28','HXSAM','Amazon','Gifts',-6.61,'',1,0,0),(6860,'2015-04-28','HXSAM','Amazon','Gifts',-7.74,'',1,0,0),(6861,'2015-04-28','HXSAM','Amazon','Gifts',-8.53,'',1,0,0),(6862,'2015-04-28','HXSAM','Amazon','Gifts',-8.74,'',1,0,0),(6863,'2015-04-28','HXSAM','Paypal','Miscellaneous',-0.51,'',1,0,0),(6864,'2015-04-28','HXSAM','Amazon','Gifts',-9.93,'',1,0,0),(6865,'2015-04-29','HXSAM','6th Gear Experience','Gifts',-53.00,'',1,0,0),(6866,'2015-04-30','HXSAM','Imagine Publishing','Entertainment:Books',-25.15,'',1,0,0),(6867,'2015-04-30','HXSAM','Boots','Medical',-7.64,'',1,0,0),(6868,'2015-04-30','HXSAM','Wilkinsons','Food:Groceries',-7.75,'',1,0,0),(6869,'2015-04-30','HXSAM','Home Bargains','Food:Groceries',-10.19,'',1,0,0),(6870,'2015-05-01','FDMARK','Tesco Express','Food:Groceries',-9.55,'',1,0,0),(6871,'2015-05-05','HXSAM','Argos','Home:Furniture',-159.99,'Garden furniture',1,0,0),(6872,'2015-05-01','HXSAM','Aimee\'s Savings','Savings',-10.00,'',1,0,0),(6873,'2015-05-01','HXSAM','Harvey\'s Savings','Savings',-10.00,'',1,0,0),(6877,'2015-05-05','HXSAM','TGI Fridays','Food:Dining',-43.57,'',1,0,0),(6878,'2015-05-05','FDMARK','Tesco Express','Food:Groceries',-11.42,'',1,0,0),(6879,'2015-05-05','HXSAM','Tesco Express','Food:Groceries',-11.93,'',1,0,0),(6880,'2015-05-05','FDMARK','Tesco','Food:Groceries',-78.84,'',1,0,0),(6881,'2015-05-05','HXSAM','Cineworld','Entertainment:Days Out',-26.48,'',1,0,0),(6882,'2015-05-05','HXSAM','Cineworld','Entertainment:Days Out',-19.85,'',1,0,0),(6883,'2015-05-05','FDMARK','Netflix','Entertainment',-6.99,'',1,0,0),(6884,'2015-05-05','HXSAM','<NEXTCARD>','Clothing',-19.12,'',1,0,6885),(6885,'2015-05-05','NEXTCARD','<HXSAM>','Clothing',19.12,'',1,0,6884),(6886,'2015-05-05','HXSAM','Hunters','Beauty:Haircut',-54.00,'',1,0,0),(6887,'2015-05-05','HXSAM','Amazon','Gifts',-0.59,'',1,0,0),(6888,'2015-05-05','FDMARK','<HXSAM>','Transfer',-200.00,'Extra spends',1,0,6889),(6889,'2015-05-05','HXSAM','<FDMARK>','Transfer',200.00,'Extra spends',1,0,6888);
/*!40000 ALTER TABLE `entry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payee`
--

DROP TABLE IF EXISTS `payee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payee` (
  `payee` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `accountgroup` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`payee`,`accountgroup`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payee`
--

LOCK TABLES `payee` WRITE;
/*!40000 ALTER TABLE `payee` DISABLE KEYS */;
INSERT INTO `payee` VALUES ('','TEST'),('','TONKS'),('<Credit Card BARCLAYCARD>','TONKS'),('<Credit Card FIRST DIRECT>','TONKS'),('<Credit Card HALIFAX MARK>','TONKS'),('<Credit Card HALIFAX SAM>','TONKS'),('<Credit Card MBNA Sam>','TONKS'),('<Current Account MARK HALIFAX>','TONKS'),('<FDMARK>','TONKS'),('<FORTHEFUTURE>','TONKS'),('<HXSAM>','TONKS'),('<NEXTCARD>','TONKS'),('<RAINYDAY>','TONKS'),('<Savings FOR THE FUTURE>','TONKS'),('<Savings MARK ISA>','TONKS'),('<Savings PAY FOR IT>','TONKS'),('<TSTMARK>','TONKS'),('<TXFMARK>','TONKS'),('2nd Brayton Guides','TONKS'),('6th Gear Experience','TONKS'),('6th Selby Scouts','TONKS'),('A Taylor','TONKS'),('AA','TONKS'),('AAArdvark','TONKS'),('Adjustment','TONKS'),('Aimee Pocket Money','TONKS'),('Aimee Tonks','TONKS'),('Aimee\'s Savings','TONKS'),('Aldi','TONKS'),('Alex Crewe Limited','TONKS'),('Alexanders','TONKS'),('Alpha Lsg','TONKS'),('Amazon','TEST'),('Amazon','TONKS'),('Amazon Digital Download','TONKS'),('Amazon EU','TONKS'),('Amazon Marketplace','TONKS'),('Ambers','TONKS'),('Animal','TONKS'),('Animal Friends','TONKS'),('Anjoca C.-bluemoon','TONKS'),('Apcoa','TONKS'),('Apple ITunes','TONKS'),('Argos','TONKS'),('Asda','TONKS'),('Asda Filling Station','TONKS'),('ATG Tickets','TONKS'),('Aviva','TONKS'),('Aviva Accounts Rec','TONKS'),('Aviva CS UK Ltd','TONKS'),('Aviva Healthcare','TONKS'),('Aviva Household','TONKS'),('Aviva Motor','TONKS'),('B&M bargains','TONKS'),('Bags, Etc','TONKS'),('Bahnstormer','TONKS'),('Banardos','TONKS'),('Barclaycard','TONKS'),('Barratts','TONKS'),('Bhs','TONKS'),('Big Bus Tour','TONKS'),('Bill Gates','TONKS'),('Billy Bob Thornton','TONKS'),('Birchwood Farm','TONKS'),('Blackpool Pleasure Beach','TONKS'),('Blacksmiths Arms','TONKS'),('Boots','TONKS'),('Brantano','TONKS'),('Brayton High School','TONKS'),('British Telecom','TEST'),('BT','TONKS'),('Burgerking','TONKS'),('C Danks','TONKS'),('Cafe Del Amis','TONKS'),('Caffe Nero','TONKS'),('Card Factory','TONKS'),('Carpet Right','TONKS'),('Cash','TONKS'),('Catnaps','TONKS'),('Cattery','TONKS'),('Caxton Fx','TONKS'),('Cedar Court','TONKS'),('Centerparcs','TONKS'),('Centerparcs Ecom','TONKS'),('Centerparcs SF','TONKS'),('Centerparcs Sherw','TONKS'),('Chatsworth House','TONKS'),('Chelle\'s Dancing','TONKS'),('Cheque','TONKS'),('Child Benefit','TONKS'),('Chiquitos','TONKS'),('Cineworld','TONKS'),('Cineworld Unlimited','TONKS'),('Claire\'s Accessories','TONKS'),('Classroom Clothing','TONKS'),('Clintons','TONKS'),('Co-Op Group','TONKS'),('Coasters','TONKS'),('COE & Co','TONKS'),('Collectables','TONKS'),('CONTRA - AIMEE SPENDS','TONKS'),('CONTRA - HARVEY SPENDS','TONKS'),('CONTRA - MARK SPENDS','TONKS'),('CONTRA - SAM SPENDS','TONKS'),('CONTRA - SHOPPING OVERSPENDS','TONKS'),('Corner Pin','TONKS'),('Cosmic','TONKS'),('Cosmos Holidays','TONKS'),('CPC','TEST'),('CPC','TONKS'),('Crunchyroll','TONKS'),('D Fox Window Cleaner','TONKS'),('David Attenborough','TONKS'),('Debbie Martindale','TONKS'),('Debenhams','TONKS'),('Deezer','TONKS'),('Deposit','TONKS'),('DGS/RPP DD','TONKS'),('Dietchef','TONKS'),('Direct Debit - Camelot Group','TONKS'),('Direct Debit - Dgs/Rpp dd','TONKS'),('Direct Debit - Selby District Council','TONKS'),('Direct Debit - Sky Digital','TONKS'),('Direct Debit - TV Licence Mbp','TONKS'),('Direct Debit - Yorkshire Water','TONKS'),('Discovery Accomodation','TONKS'),('Dolphin Fish N Chips','TONKS'),('Dorothy Perkins','TONKS'),('Drax Sports Club','TONKS'),('Dreams','TONKS'),('DVLA','TONKS'),('DW Fitness','TONKS'),('E.On','TEST'),('E.On','TONKS'),('EC Mainline','TONKS'),('EE & T-Mobile','TONKS'),('English Heritage','TONKS'),('Euro Garages','TONKS'),('Expedia','TONKS'),('Fair Fx','TONKS'),('First Direct','TONKS'),('First/Keolis Trans','TONKS'),('Fit Camp ','TONKS'),('Flame Homeware','TONKS'),('Flamingo Land','TONKS'),('Flyers Group','TONKS'),('Foresters','TONKS'),('Frankie & Benny\'s','TONKS'),('Frenchgate Car Park','TONKS'),('G C Diggins','TONKS'),('Gap','TONKS'),('Goodman\'s Field','TONKS'),('Gosober.org','TONKS'),('Graze.com','TONKS'),('Greenthumb','TONKS'),('Guides','TONKS'),('H&M','TONKS'),('H3G','TONKS'),('Halfords','TONKS'),('Halifax','TONKS'),('HALL JE&RH','TONKS'),('Hallmark Cards','TONKS'),('Harrods','TONKS'),('Harvey Pocket Money','TONKS'),('Harvey Tonks','TONKS'),('Harvey\'s Savings','TONKS'),('Hawkins Bazaar','TONKS'),('Hearst Magazines Uk','TONKS'),('Heaven & Home','TONKS'),('Herbalife','TONKS'),('Hitachi Capital Lv','TONKS'),('Hmv','TONKS'),('Hobby Craft','TONKS'),('Holiday','TONKS'),('Holiday Inn Norwich','TONKS'),('Holland & Barrett','TONKS'),('Holmefield Vets','TONKS'),('Home Bargains','TONKS'),('Homebase','TONKS'),('Homesense','TONKS'),('Hostroute','TONKS'),('Hotel Chocolat','TONKS'),('Hunters','TONKS'),('Ibis','TONKS'),('IHG Hotels','TONKS'),('IKEA','TONKS'),('Imagine Publishing','TONKS'),('Insure & Go','TONKS'),('Int\'l ','TONKS'),('ITunes.com','TONKS'),('J D Sports','TONKS'),('J Martindale','TONKS'),('Jean Tonks','TONKS'),('John Alexander Cards','TONKS'),('John Greed Jewellery','TONKS'),('Jolleys Pet Food','TONKS'),('JustGiving','TONKS'),('Kathryn Poynter','TONKS'),('Kids Savings','TONKS'),('Lastminute.com','TONKS'),('Layerthorpe','TONKS'),('Learnable','TONKS'),('Legal & General','TONKS'),('Lindt','TONKS'),('Love You Hair & Beauty','TONKS'),('Lovefilm.com','TONKS'),('LOYD MORR SELBY','TONKS'),('LOYD Selby','TONKS'),('M&Co','TONKS'),('Madame Tussauds','TONKS'),('Manchester Airport T1','TONKS'),('MandMDirect.com','TONKS'),('Mark Tonks','TONKS'),('Market Lane Dental','TONKS'),('Marks & Spencer','TONKS'),('Martin Broadhead','TONKS'),('McDonalds','TONKS'),('Menkind','TONKS'),('Microsoft Xbox Live','TONKS'),('Minecraft','TONKS'),('Misc','TONKS'),('Monsoon','TONKS'),('Moonpig','TONKS'),('Morgan Freeman','TONKS'),('Morrisons','TONKS'),('Moss Bros','TONKS'),('Motordepot','TONKS'),('Motorpoint Arena Sheffield','TONKS'),('Mountain Warehouse','TONKS'),('Mrs Vicky Kelly','TONKS'),('N Clarkson-Banks','TONKS'),('National Lottery','TONKS'),('National Rail','TONKS'),('Nationwide Banking Services','TONKS'),('Nelson Inn','TONKS'),('Netflix','TONKS'),('Neulion/NFL','TONKS'),('New Look','TONKS'),('Next','TONKS'),('Nick Summerton','TONKS'),('Non-stg Purch Fee','TONKS'),('Non-stg Trans Fee','TONKS'),('None','TONKS'),('North Yorkshire County Council','TONKS'),('Nuance Group Uk','TONKS'),('O2','TONKS'),('Old Guys Rule','TONKS'),('Olives & Grill','TONKS'),('Outfit','TONKS'),('Owl Hotel','TONKS'),('Oyster','TONKS'),('Paperchase','TONKS'),('ParentPay','TONKS'),('Park & Ride','TONKS'),('Park & Ride Cycle Locker','TONKS'),('Partylite','TONKS'),('Patio Guy','TONKS'),('Paypal','TONKS'),('Pear Tree Farm','TONKS'),('Pet Health Plan','TONKS'),('Pet\'s Pad','TONKS'),('Pets At Home','TONKS'),('Pinn Insure Plc','TONKS'),('Pizza Express','TONKS'),('Pizza Hut','TONKS'),('Placeholder - Car Service','TONKS'),('Planned O/D Fee','TONKS'),('Post Office Counters','TONKS'),('Pret A Manger','TONKS'),('Primark','TONKS'),('Prime Instant Video','TONKS'),('Prize Payment ','TONKS'),('Pylones','TONKS'),('Rachel Hall','TONKS'),('Reconciled','TONKS'),('Returns','TONKS'),('Richard Longton','TONKS'),('River Island','TONKS'),('Rock One','TONKS'),('Rowlands Pharmacy','TONKS'),('Sainsbury\'s','TONKS'),('Sally Gregory','TONKS'),('Samantha Tonks','TONKS'),('Samaritans Purse','TONKS'),('Science Museum','TONKS'),('Selby Carpets','TONKS'),('Selby College','TONKS'),('Selby Garden Center','TONKS'),('Selby HWRC','TONKS'),('Selby Library','TONKS'),('Selby Superbowl','TONKS'),('Sheraton','TONKS'),('Sky','TONKS'),('Snapfish','TONKS'),('Sports Direct','TONKS'),('Standing Order - Halifax Mortgage','TONKS'),('Starbucks','TONKS'),('Stormfront York','TONKS'),('Strada Sherwood','TONKS'),('Stuart Barber','TONKS'),('Subway','TONKS'),('Superdrug','TONKS'),('Sweatshop','TONKS'),('T-Mobile','TONKS'),('Telefonica','TONKS'),('Tempest Photos','TONKS'),('Terry Testdata','TONKS'),('Tesco','TONKS'),('Tesco Clothing','TONKS'),('Tesco Direct','TONKS'),('Tesco Express','TONKS'),('Tesco Garage','TONKS'),('Tesco Mobile','TONKS'),('TEST Employer','TEST'),('TGI Fridays','TONKS'),('Thai Sushine','TONKS'),('That\'s Entertainment','TONKS'),('The Angel Hotel','TONKS'),('The Book People','TONKS'),('The Entertainer','TONKS'),('The Giant Bellflower','TONKS'),('The Kings Head','TONKS'),('The Oaks Golf Club','TONKS'),('The Outlet Brotherton','TONKS'),('The Owl Hotel','TONKS'),('The RAC','TONKS'),('The Range','TONKS'),('The Swan','TONKS'),('The Tree House','TONKS'),('The Wishing Well','TONKS'),('The Works','TONKS'),('The Wychwood Brewery','TONKS'),('The York Sweet Shop','TONKS'),('The Yorkshire Fryer','TONKS'),('TheTrainLine.com','TONKS'),('Thomas Cook','TONKS'),('Thompson Holidays','TONKS'),('Thorntons','TONKS'),('Three','TONKS'),('Ticketmaster','TONKS'),('Toby Carvery','TONKS'),('Tower Of London ','TONKS'),('Toys R Us','TONKS'),('Toyz+','TONKS'),('Tracey Harrison Personal Trainer','TONKS'),('Transport For London','TONKS'),('Travel Ins-ancile','TONKS'),('Travel Insurance','TONKS'),('Travel Money','TONKS'),('Travelodge','TONKS'),('Trenchers','TONKS'),('Trespass','TONKS'),('Tribute Funds','TONKS'),('TSL Clothing','TONKS'),('Vision Value','TONKS'),('Vom Fass Concessio','TONKS'),('Wallis','TONKS'),('Waterstones','TONKS'),('Weatherills','TONKS'),('Weatherspoons','TONKS'),('Web Hosting','TONKS'),('Weekly Cash - Mark','TONKS'),('Weekly Cash - Sam','TONKS'),('Wh Smith','TONKS'),('White Wholesale Lt','TONKS'),('Who Internet','TONKS'),('Wickes','TONKS'),('Wilkinsons','TONKS'),('York Grand Opera House','TONKS'),('York Marathon','TONKS'),('York Maze','TONKS'),('York Race Course','TONKS'),('York Teaching Hospital','TONKS'),('Yorkshire Trading','TONKS'),('Yorkshire Water','TEST');
/*!40000 ALTER TABLE `payee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `repeatingentry`
--

DROP TABLE IF EXISTS `repeatingentry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `repeatingentry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `accountid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `payee` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `category` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `amountcr` decimal(10,2) NOT NULL,
  `notes` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `isplaceholder` tinyint(1) DEFAULT '0',
  `nextdate` date DEFAULT NULL,
  `prevdate` date DEFAULT NULL,
  `endondate` date DEFAULT NULL,
  `frequencycode` char(1) COLLATE utf8_unicode_ci DEFAULT NULL COMMENT 'D, W, M, Y',
  `frequencyincrement` int(11) DEFAULT NULL,
  `accountgroup` varchar(30) COLLATE utf8_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `date` (`nextdate`,`accountid`,`payee`,`category`)
) ENGINE=MyISAM AUTO_INCREMENT=67 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `repeatingentry`
--

LOCK TABLES `repeatingentry` WRITE;
/*!40000 ALTER TABLE `repeatingentry` DISABLE KEYS */;
INSERT INTO `repeatingentry` VALUES (11,'FDMARK','Aviva','Salary',4000.00,'',0,'2015-05-27','2015-04-27','2019-12-27','M',1,'TONKS'),(53,'FDMARK','<HXSAM>','Transfer:Monthly Spends',-1000.00,'',0,'2015-05-27','2015-04-27','2019-12-27','M',1,'TONKS'),(13,'HXSAM','DGS/RPP DD','Bills:Insurance',-12.59,'',0,'2015-05-27','2015-04-27','2019-12-27','M',1,'TONKS'),(14,'FDMARK','Tesco','Food:Groceries',-140.00,'Weekly shopping',0,'2015-06-01','2015-05-25','2019-12-29','W',1,'TONKS'),(15,'HXSAM','Selby College','Salary',623.25,'',0,'2015-06-03','2015-05-03','2019-12-31','M',1,'TONKS'),(16,'HXSAM','Weekly Cash - Mark','Cash:Regular',-20.00,'',0,'2015-05-27','2015-05-20','2019-12-31','W',1,'TONKS'),(17,'HXSAM','Weekly Cash - Sam','Cash:Regular',-20.00,'',0,'2015-05-27','2015-05-20','2019-12-31','W',1,'TONKS'),(18,'FDMARK','Animal Friends','Insurance Rufus',-4.36,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(19,'FDMARK','Animal Friends','Insurance Gracie',-4.36,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(20,'FDMARK','DGS/RPP DD','Insurance',-5.34,'',0,'2015-06-01','2015-05-01','2015-12-01','M',1,'TONKS'),(21,'FDMARK','Halifax','Bills:Mortgage',-422.71,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(22,'FDMARK','Direct Debit - Yorkshire Water','Bills:Utilities',-38.00,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(23,'FDMARK','<RAINYDAY>','Savings',-50.00,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(24,'FDMARK','E.On','Bills:Utilities',-140.00,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(25,'FDMARK','Direct Debit - Selby District ','Bills:Tax',-157.00,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(26,'HXSAM','Direct Debit - TV Licence Mbp','Bills:TV',-12.12,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(27,'FDMARK','H3G','Bills:Mobile Phones',-32.00,'Sam\'s phone',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(28,'HXSAM','<FORTHEFUTURE>','Savings',-25.00,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(29,'FDMARK','Legal & General','Bills:Insurance',-21.74,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(30,'HXSAM','Pet Health Plan','Insurance',-19.96,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(31,'FDMARK','Legal & General','Insurance',-37.85,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(32,'HXSAM','DGS/RPP DD','Insurance',-7.99,'',0,'2015-06-02','2015-05-02','2019-12-02','M',1,'TONKS'),(34,'FDMARK','Aviva Healthcare','Insurance',-65.14,'',0,'2015-06-04','2015-05-04','2019-12-04','M',1,'TONKS'),(35,'FDMARK','Aviva Household','Insurance',-14.13,'',0,'2015-06-05','2015-05-05','2019-12-05','M',1,'TONKS'),(36,'FDMARK','BT','Bills:Utilities',-48.47,'',0,'2015-06-06','2015-05-06','2019-12-06','M',1,'TONKS'),(37,'FDMARK','Nationwide Banking Services','Bills:Loans',-371.82,'',0,'2015-06-09','2015-05-09','2019-12-09','M',1,'TONKS'),(38,'FDMARK','Tesco Garage','Bills:Motor',-66.00,'BMW fillup',0,'2015-06-10','2015-05-10','2019-12-10','M',1,'TONKS'),(39,'FDMARK','Tesco Garage','Bills:Motor',-65.00,'Captur fillup',0,'2015-06-07','2015-05-17','2019-12-12','W',3,'TONKS'),(40,'FDMARK','Park & Ride Cycle Locker','Bills:Transport',-10.00,'Cycle locker',0,'2015-06-15','2015-05-15','2019-12-15','M',1,'TONKS'),(41,'FDMARK','Deezer','Entertainment:Music',-9.99,'',0,'2015-06-15','2015-05-15','2019-12-15','M',1,'TONKS'),(42,'HXSAM','Web Hosting','Entertainment:Hobbies',-3.60,'Tonksdev.co.uk',0,'2015-06-16','2015-05-16','2019-12-16','M',1,'TONKS'),(62,'FDMARK','First Direct','Bills:Loans',-127.60,'Captur repayment',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(61,'HXSAM','Crunchyroll','Entertainment:Hobbies',-4.99,'Anime VOD',0,'2015-05-30','2015-04-30','2019-12-30','M',1,'TONKS'),(45,'FDMARK','H3G','Bills:Mobile Phones',-15.10,'',0,'2015-06-22','2015-05-22','2019-12-22','M',1,'TONKS'),(46,'FDMARK','H3G','Bills:Mobile Phones',-10.00,'',0,'2015-06-22','2015-05-22','2019-12-22','M',1,'TONKS'),(47,'HXSAM','Learnable','Entertainment:Hobbies',-5.62,'',0,'2015-06-24','2015-05-24','2019-12-24','M',1,'TONKS'),(48,'HXSAM','Non-stg Purch Fee','Bills:Banking',-1.50,'',0,'2015-06-24','2015-05-24','2019-12-24','M',1,'TONKS'),(49,'HXSAM','Non-stg Trans Fee','Bills:Banking',-0.15,'',0,'2015-06-24','2015-05-24','2019-12-24','M',1,'TONKS'),(50,'FDMARK','Tesco','Delivery Charge',-6.00,'',0,'2015-06-25','2015-05-25','2019-12-25','M',1,'TONKS'),(51,'HXSAM','CONTRA - MARK SPENDS','Personal:Spends',-150.00,'',1,'2015-06-26','2015-05-26','2019-12-26','M',1,'TONKS'),(52,'HXSAM','CONTRA - SAM SPENDS','Personal:Spends',-150.00,'',1,'2015-06-26','2015-05-26','2019-12-26','M',1,'TONKS'),(54,'FDMARK','CONTRA - SHOPPING OVERSPENDS','Food:Groceries',-120.00,'Placeholder for extra shopping each month',1,'2015-06-26','2015-05-26','2019-12-26','M',1,'TONKS'),(55,'HXSAM','Aimee Pocket Money','Pocket Money',-5.00,'Aimee\'s weekly pocket money',0,'2015-05-29','2015-05-22','2019-12-31','W',1,'TONKS'),(56,'HXSAM','Harvey Pocket Money','Pocket Money',-5.00,'Harvey\'s weekly pocket money',0,'2015-05-29','2015-05-22','2019-12-31','W',1,'TONKS'),(57,'HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',0,'2015-06-18','2015-05-18','2019-02-18','M',1,'TONKS'),(58,'HXSAM','Cineworld Unlimited','Entertainment:Days Out',-16.40,'',0,'2015-06-18','2015-05-18','2019-02-18','M',1,'TONKS'),(59,'BILLSACC','Yorkshire Water','Bills: Water',-40.00,'',0,'2015-04-06','2015-04-06','2019-12-06','M',1,'TEST'),(60,'BILLSACC','British Telecom','Bills: Energy',-35.00,'',0,'2015-03-03','2015-03-03','2019-12-03','M',1,'TEST'),(63,'FDMARK','The RAC','Bills:Motor',-126.00,'Breakdown cover',0,'2016-05-01','2015-05-01','2019-05-01','Y',1,'TONKS'),(64,'HXSAM','Aimee\'s Savings','Savings',-10.00,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(65,'HXSAM','Harvey\'s Savings','Savings',-10.00,'',0,'2015-06-01','2015-05-01','2019-12-01','M',1,'TONKS'),(66,'FDMARK','Netflix','Entertainment',-6.99,'',0,'2015-06-05','2015-05-05','2019-12-05','M',1,'TONKS');
/*!40000 ALTER TABLE `repeatingentry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `userid` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `series` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `token` char(64) COLLATE utf8_unicode_ci NOT NULL,
  `fingerprint` char(64) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`userid`,`token`,`fingerprint`,`series`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds keep-me-logged-in session ids';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('marktonks75','c2e4a3186adf90ab974c9bb346b4a64a3eed08b839de2495cd3cf9b030899489','0469a1c1403116e3804330b3c41a99c2e94a83546a6e01e8dc29691c3cc2ef44','074ce7f4907daf1a3db53df79ebebd258b8f3b6c0a535c6a2eff945569d5515c'),('marktonks75','befc4af4be6da8cd0c48474e65f27731a3fb1bf4423627c951bc710b04f22389','0d65d37db9acff2f95c6a3eab3453850839d0a11669a13ef233a5ab23a78f830','79f577a0cc2663072e8619d49607a479357aea6dd48b874fc1c76730e66ed3df'),('marktonks75','ebe31ce514ea6ebe9f3a19b1790e27704ef3dfe250ed499b3afd74bc41c34017','1add23316c292b95a67e18822534ae823c1ac6e82a1f07c4243500064289b1ff','1eb079b72a2fb287193e84bb24c341c6ee91fc9576c28a0c42978fb9cf216ef7'),('marktonks75','795112b9af37262458ca65ea5a8c426a325c800041c5200049030c78e08e0308','1fbd0a2213dd61e64d708d7b1fd57a08aa23a40d1874726cef299333d678b2c6','b431b4674b668e8f7e1a70dc4436e87cb5576c1c08cedc6d770c820deffa8627'),('marktonks75','947bd5e196baa156fead93c10417d2b7b2198ac7a196ea9d2b5e2f9e2e0c6d84','2e43aca5d50953a3283aca27933d32cfa21392b47d4a2653b728ae9ecb6ff330','2dd886af1b3cab00f6df0cd1c9863d6bcd0bc1dc3282001f72fcce23b8b07a6d'),('marktonks75','2a247a56b674c5cf753aeb4c0819dcf3eb4ed5cf7d39513901d1104adf09d78b','325cc5eb8b2764028dfa98c8906f7bc09369daa718463693125d7ac5c14edd9b','a2501b48a225ae106755afe5e7f0e656ffb867435bf76f4ea43725fe2472c92f'),('marktonks75','3c74701c14ea8fdfcb440aaf35cc7bdbf3ea0c6e44e22234a8e8d079f120220d','38f6548f8eba09041381728021fe9334b7a9c4fb8fbcdb4675674746eba245dd','c70920236ae78f4537da36dd9873d9adfe0d720a5cf78a9d7422141af0b36de6'),('marktonks75','8387f4dfa2a93cb6147375b6b9a24a4c25fa28138e8e13f91bc1d2c24c7bcc5c','4e81e4e7a0f9c0c4ae9652c962b9d1d017dc950044f8e2ff84081ffe838ba016','12b19c962fe4ca3b807547ffedd223e40466438a4d3a010d6f64e81ef59c9095'),('marktonks75','6e2e1ee14020a89a90687f06cba515d319a28f7177f75fdd45d1eb669251709b','7b849da1c22204b6a1d1dfc4a31dc7b4e2d584408e2549331781f2642e1c80f9','fb581405b21313898e47d8a46cb010dbf582433ae8cafe98758538517759d880'),('marktonks75','f6a827e0c02700973fd7aff40153195a5943bd030249669b514b03f0c7bda954','81910c7dbe3fcdb61f0c1b49359b12d6941800a5a8decd5a1141406a271a269e','8483c49921c412d37c75bef47fbf0a71fa0a8d899fa0837e0563627b5c1131e4'),('marktonks75','e9dff9184a9371d5c23bc9fc557b892ab8ed29b6ee77fd42e962c8c9c6d8852a','c1b094e151f850904af5f8ad05ed224b36eb727c93077e64bc5db930fa764cfd','4880c8ca8655c8d54e4f4a70753ba9fc500dc7579f006390562c27e86ce3709d'),('marktonks75','8cea5aa7dfb530a7842678f02b75e1d4bd3e6533eb70eb9d6f3c73303c89dc71','dc3379ce31e0868b52700b1802597ecf010b15542e138ecc7046a16f8d45989e','4880c8ca8655c8d54e4f4a70753ba9fc500dc7579f006390562c27e86ce3709d'),('samtonks75','5f5ca520dbcff649f06e64c1f4d236b9ff501104678ad7a737a7c0a8dac39e3a','54e810adfe2bf03f2184abd40135c47d359edf6b4ee5f6070a7badb4576efd7e','2dd886af1b3cab00f6df0cd1c9863d6bcd0bc1dc3282001f72fcce23b8b07a6d'),('samtonks75','fb9b44911e195c84a61688ed48f9375686ced12fbefb7991fcefc87ddf570025','96eb8fee774df144b69b1ecf42d1a73b4a2e5617a90d7dd5df3fd2421686551a','1358d39a03b6d38b38fa76a30abe3bc979aa3f8815d3906f6f150cd0cd82c071');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `id` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Primary key for user',
  `fullname` varchar(100) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Full name of the user',
  `Password` char(64) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Password of user',
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Holds the email address for the user',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds details of all users of myHappyPlace';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('marktonks75','Mark Tonks','389290b4e080a71c5b037f0be57749f14325d74437384a68f3fa261c7efd732f','marktonks75@gmail.com'),('Demo','Demonstration User','e6a253ca196e4fb7f057023f9aceeffe766ac1521efafc4122323ce29e0c928b','demo@tonksdev.co.uk'),('samtonks75','samtonks75','fbaf439f5552a511f9fd79eddd9e56580f83959934ebaa16d0fe9a377bfeab14','samtonks75@gmail.com'),('AimeeTonks','Aimee Tonks','cb59e3490082ed4d3beaa68d2e4b5c6fd397286bc6f59ed26eb20d9a547051a3','aimztonks@gmail.com');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usergroup`
--

DROP TABLE IF EXISTS `usergroup`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usergroup` (
  `userid` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Links to the user id',
  `groupid` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Links to the group id',
  `primarygroup` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`userid`,`groupid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds links between users and groups';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usergroup`
--

LOCK TABLES `usergroup` WRITE;
/*!40000 ALTER TABLE `usergroup` DISABLE KEYS */;
INSERT INTO `usergroup` VALUES ('marktonks75','TONKS',1),('Demo','TEST',1),('samtonks75','TONKS',1);
/*!40000 ALTER TABLE `usergroup` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userrole` (
  `userid` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'Links to the user id',
  `role` varchar(30) COLLATE utf8_unicode_ci NOT NULL COMMENT 'The role type',
  PRIMARY KEY (`userid`,`role`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Holds all user roles for all users';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userrole`
--

LOCK TABLES `userrole` WRITE;
/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'tonksdev_tcash'
--
/*!50003 DROP PROCEDURE IF EXISTS `addAccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `addAccount`(IN `t_id` VARCHAR(30),
								IN `t_name` VARCHAR(100),
								IN `t_type` VARCHAR(30),
								IN `t_accountgroup` VARCHAR(30))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN
 
INSERT
INTO	account
		(id, name, type, accountgroup)
VALUES  (t_id, t_name, t_type, t_accountgroup);


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addAccountGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `addAccountGroup`(IN `t_groupid` VARCHAR(30),
							IN `t_description` VARCHAR(100),
							IN `t_password` CHAR(64), 
							IN `t_owner` VARCHAR(255))
BEGIN

	INSERT 
	INTO	tonksdev_tcash.accountgroup
			(groupid, description, password, owner)
	VALUES	(t_groupid, t_description, t_password, t_owner);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addCategory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `addCategory`(IN `t_category` VARCHAR(255), IN `t_accountgroup` VARCHAR(30))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

INSERT	
INTO	category (id, accountgroup)
VALUES	(t_category, t_accountgroup);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addPayee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `addPayee`(IN `t_payee` VARCHAR(255), IN `t_accountgroup` VARCHAR(255))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

INSERT 
INTO	payee (payee, accountgroup)
VALUES	(t_payee, t_accountgroup);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addRepeating` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `addRepeating`(
	 IN `t_accountid` VARCHAR(30),
	 IN `t_payee` VARCHAR(30),
	 IN `t_category` VARCHAR(30),
	 IN `t_amountcr` DECIMAL(10, 2),
	 IN `t_notes` VARCHAR(255),
	 IN `t_isplaceholder` TINYINT(1),
	 IN `t_nextdate` date,
	 IN `t_endondate` date, 
	 IN `t_frequencycode` CHAR(1),
	 IN `t_frequencyincrement` INT(11),
	 IN `t_accountgroup` VARCHAR(30))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

	INSERT 
	INTO	repeatingentry
			(
			`accountid`,
			`payee`,
			`category`,
			`amountcr`,
			`notes`,
			`isplaceholder`,
			`nextdate`,
			`prevdate`,
			`endondate`,
			`frequencycode`,
			`frequencyincrement`,
			`accountgroup`
			)
	VALUES	(
			t_accountid,
			t_payee,
			t_category,
			t_amountcr,
			t_notes,
			t_isplaceholder,			
			t_nextdate,
			t_nextdate,
			t_endondate,
			t_frequencycode,
			t_frequencyincrement,
			t_accountgroup
			);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addSession` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `addSession`(IN `t_uid` VARCHAR(30),
								IN `t_series` CHAR(64),
								IN `t_token` CHAR(64),
								IN `t_fprint` CHAR(64))
BEGIN

	INSERT 	
	INTO	tonksdev_tcash.session
			(userid, series, token, fingerprint)
	VALUES	(t_uid, t_series, t_token, t_fprint);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addTxn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `addTxn`(IN `t_date` DATE, IN `t_accountid` VARCHAR(30) CHARSET utf8, IN `t_payee` VARCHAR(255) CHARSET utf8, IN `t_category` VARCHAR(255) CHARSET utf8, IN `t_amountcr` DECIMAL(10,2), IN `t_notes` VARCHAR(255) CHARSET utf8, IN `t_iscleared` TINYINT(1), IN `t_isplaceholder` TINYINT(1), IN `t_transfertxn` INT(11), IN `t_accgroup` VARCHAR(30))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

IF (convert(t_accountid using utf8) IN (SELECT convert(id using utf8) FROM account WHERE accountgroup = t_accgroup)) 
THEN

INSERT 
INTO	entry
	 	(date, accountid, payee, category, amountcr, 
    	notes, iscleared, isplaceholder, transfertxn)
VALUES 	(t_date, t_accountid, t_payee, t_category, t_amountcr, 
    	t_notes, t_iscleared, t_isplaceholder, t_transfertxn);


END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `addUser`(IN `t_userid` VARCHAR(30),
							IN `t_fullname` VARCHAR(100),
							IN `t_password` CHAR(64), 
							IN `t_email` VARCHAR(255))
BEGIN

	INSERT 
	INTO	tonksdev_tcash.user
			(id, fullname, password, email)
	VALUES	(t_userid, t_fullname, t_password, t_email);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `addUserGroupLink` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `addUserGroupLink`(IN `t_userid` VARCHAR(30),
							IN `t_groupid` VARCHAR(30),
							IN `t_primary` TINYINT(1))
BEGIN

	INSERT 
	INTO	tonksdev_tcash.usergroup
			(userid, groupid, primarygroup)
	VALUES	(t_userid, t_groupid, t_primary);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `adjustTransactionValue` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `adjustTransactionValue`(IN t_account VARCHAR(30),
										   IN t_txnid INT,
										   IN t_reduceamt float,
										   IN t_accgroup VARCHAR(30))
BEGIN

	UPDATE	entry e
			INNER JOIN account a
				ON a.id = e.accountid
	SET		amountcr = amountcr + t_reduceamt
	WHERE	a.id = t_account 
			AND a.accountgroup = t_accgroup
			AND e.id = t_txnid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `checkAccountGroupExists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `checkAccountGroupExists`(IN `t_accgroupid` VARCHAR(30))
BEGIN

SELECT 	groupid, 
		description, 
		password, 
		owner 
FROM 	tonksdev_tcash.accountgroup
WHERE 	groupid = t_accgroupid
LIMIT   1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `checkUserExists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `checkUserExists`(IN `t_userid` VARCHAR(30))
BEGIN

SELECT 	id, 
		fullname, 
		password, 
		email 
FROM 	tonksdev_tcash.user
WHERE 	id = t_userid
LIMIT   1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `checkUserGroupLinkExists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `checkUserGroupLinkExists`(IN `t_userid` VARCHAR(30), IN `t_groupid` VARCHAR(30))
BEGIN

SELECT 	userid, 
		groupid 
FROM 	tonksdev_tcash.usergroup
WHERE 	userid = t_userid
		AND groupid = t_groupid
LIMIT   1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAccGroupOwner` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getAccGroupOwner`(IN `t_accgroup` VARCHAR(30))
BEGIN
	SELECT 	owner
	FROM	accountgroup
	WHERE 	groupid = t_accgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getAccount`(IN `t_accgroup` VARCHAR(30), 
														 IN `t_id` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
SELECT 	id,
		name,
		type, 
		bank,
		icon,
		accountgroup
FROM	account
WHERE 	accountgroup = t_accgroup
		AND id = t_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAccountList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getAccountList`(IN `t_accgroup` VARCHAR(30), IN `t_acctype` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
SELECT 	id,
		name,
		type, 
		bank,
		icon,
		accountgroup
FROM	account
WHERE 	accountgroup = t_accgroup
		AND type LIKE t_acctype;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAccountTypeBank` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getAccountTypeBank`(IN `t_accgroup` VARCHAR(30), IN `t_acctype` VARCHAR(30), IN `t_accbank` VARCHAR(30))
BEGIN
SELECT 	id,
		name,
		type, 
		bank,
		icon,
		accountgroup
FROM	account
WHERE 	accountgroup = t_accgroup
		AND type = t_acctype
		AND bank = t_accbank;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllBalances` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getAllBalances`(IN `t_accgroup` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

SELECT	a.id,
		a.name,
		a.type,
		SUM(e.amountcr) AS balance
FROM	account a
		LEFT JOIN entry e
			ON e.accountid = a.id 
WHERE	a.accountgroup = t_accgroup
GROUP BY a.id
ORDER BY a.id;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllPlaceholderForAcct` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getAllPlaceholderForAcct`(IN `t_accountid` VARCHAR(30), IN `t_accountgroup` VARCHAR(30))
BEGIN

	SELECT 	e.payee, 
			e.id,
			e.amountcr
	FROM 	entry e
			INNER JOIN account a
				ON a.id = e.accountid
	WHERE 	e.accountid = t_accountid 
			AND e.isplaceholder 
			AND a.accountgroup = t_accountgroup
			AND e.transfertxn = 0;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllRepeating` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getAllRepeating`(IN `t_accountgroup` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

	SELECT	`id`,
			`accountid`,
			`payee`,
			`category`,
			`amountcr`,
			`notes`,
			`isplaceholder`,
			`nextdate`,
			`prevdate`,
			`endondate`
	FROM	repeatingentry
	WHERE 	accountgroup = t_accountgroup
	ORDER BY `nextdate` ASC, `amountcr` ASC;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getAllTxnForAcct` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getAllTxnForAcct`(IN `acct` VARCHAR(30), IN `res_limit` INT, IN `t_accgroup` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

SELECT	e.id,
		e.date,
		e.accountid,
		e.payee,
		e.category,
		e.amountcr,
		e.notes,
		e.iscleared,
		e.isplaceholder
FROM	entry e
		INNER JOIN account a
			on a.id = e.accountid
WHERE	e.accountid = acct
		AND a.accountgroup = t_accgroup
ORDER BY date DESC, id DESC LIMIT res_limit;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getBalance` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getBalance`(IN `tAccount` VARCHAR(30), IN `t_accgroup` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
	SELECT 	SUM(e.amountcr) AS balance
	FROM	entry e
			INNER JOIN account a
				ON a.id = e.accountid 
	WHERE 	e.accountid = tAccount
			AND a.accountgroup = t_accgroup;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getCategory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getCategory`(IN `t_category` VARCHAR(255), IN `t_accountgroup` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

SELECT	id
FROM	category
WHERE	id = t_category
		AND accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getCategoryList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getCategoryList`(IN `t_accountgroup` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN
SELECT	id
FROM	category
WHERE 	accountgroup = t_accountgroup
ORDER BY id;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getGroupsForUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getGroupsForUser`(IN `t_userid` VARCHAR(30))
BEGIN

SELECT 	groupid, 
		primarygroup
FROM	usergroup
WHERE	userid = t_userid
ORDER by groupid;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getPayee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getPayee`(IN `t_payee` VARCHAR(255), IN `t_accountgroup` VARCHAR(255))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

SELECT	payee
FROM	payee
WHERE	payee = t_payee
		AND accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getPayeeList` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getPayeeList`(IN `t_accgroup` VARCHAR(30), IN `t_payeetype` CHAR(1))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

CASE t_payeetype
	WHEN "P" THEN 
		SELECT	
		DISTINCT	payee
		FROM		payee 
		WHERE		accountgroup = t_accgroup
					AND payee.payee NOT LIKE "<%" 
		ORDER BY	payee;

	WHEN "A" THEN
		SELECT	
		DISTINCT	payee
		FROM		payee 
		WHERE		accountgroup = t_accgroup
					AND payee.payee LIKE "<%"
		ORDER BY	payee;

	ELSE
		SELECT	
		DISTINCT	payee
		FROM		payee 
		WHERE		accountgroup = t_accgroup
		ORDER BY	payee;
END CASE;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getRecentTxnDets` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getRecentTxnDets`(IN `t_accgroup` VARCHAR(30), IN `t_payee` VARCHAR(255))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

SELECT	e.payee,
		e.category,
		e.amountcr
FROM	entry e
		INNER JOIN account a
			ON a.id = e.accountid
WHERE	e.payee = t_payee
		AND a.accountgroup = t_accgroup
ORDER BY e.date DESC, e.id DESC LIMIT 1;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getRepeating` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getRepeating`(IN `t_id` INT(11), IN `t_accountgroup` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

	SELECT	`id`,
			`accountid`,
			`payee`,
			`category`,
			`amountcr`,
			`notes`,
			`isplaceholder`,
			`nextdate`,
			`prevdate`,
			`endondate`,
			`frequencycode`,
			`frequencyincrement`
	FROM	repeatingentry
	WHERE 	id = t_id
			AND accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getRepeatingDay` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getRepeatingDay`(IN `t_date` date, IN `t_accountgroup` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

	SELECT	`id`,
			`accountid`,
			`payee`,
			`category`,
			`amountcr`,
			`notes`,
			`isplaceholder`,
			`nextdate`,
			`prevdate`,
			`endondate`,
			`frequencycode`,
			`frequencyincrement`
	FROM	repeatingentry
	WHERE 	nextdate = t_date
			AND endondate > nextdate
			AND accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getRepeatingToDate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getRepeatingToDate`(IN `t_date` date, IN `t_accountgroup` VARCHAR(30))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

	SELECT	`id`,
			`accountid`,
			`payee`,
			`category`,
			`amountcr`,
			`notes`,
			`isplaceholder`,
			`nextdate`,
			`prevdate`,
			`endondate`,
			`frequencycode`,
			`frequencyincrement`
	FROM	repeatingentry
	WHERE 	nextdate <= t_date
			AND endondate > nextdate  
			AND accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getTxn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getTxn`(IN `t_id` INT(11))
    READS SQL DATA
    SQL SECURITY INVOKER
BEGIN

	SELECT 	id, date, accountid, payee, category,
			amountcr, notes, iscleared, isplaceholder,
			transfertxn
	FROM	entry
	WHERE 	id = t_id;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getUserFromId` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getUserFromId`(IN `t_userid` VARCHAR(30))
BEGIN

SELECT	id, 
		fullname,
		email
FROM	user
WHERE	id = t_userid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `getUsersForGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `getUsersForGroup`(IN `t_accgroup` VARCHAR(30))
BEGIN

SELECT 	userid, 
		primarygroup
FROM	usergroup
WHERE	groupid = t_accgroup
ORDER by userid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `matchSession` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `matchSession`(IN `t_uid` VARCHAR(30),
								IN `t_series` CHAR(64),
								IN `t_token` CHAR(64),
								IN `t_fprint` CHAR(64))
BEGIN

	DECLARE CheckExists int;
	SET CheckExists = 0;

	SELECT COUNT(*) INTO CheckExists
	FROM	tonksdev_tcash.session
	WHERE	userid = t_uid 
			AND series = t_series 
			AND token = t_token
			AND fingerprint = t_fprint;

	IF (CheckExists > 0) THEN
		SELECT	userid, series, token, fingerprint 	
		FROM	tonksdev_tcash.session
		WHERE	userid = t_uid 
				AND series = t_series 
				AND token = t_token
				AND fingerprint = t_fprint;
	ELSE
		SELECT	userid, series, "HIJACK" AS token, "HIJACK" AS fingerprint 	
		FROM	tonksdev_tcash.session
		WHERE	userid = t_uid 
				AND series = t_series;

		DELETE	
		FROM 	tonksdev_tcash.session
		WHERE	userid = t_uid 
				AND series = t_series;

	END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `procedureTest` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `procedureTest`()
BEGIN
  SELECT amountcr FROM entry;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `removeAccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `removeAccount`(IN `t_id` VARCHAR(30),
								IN `t_accountgroup` VARCHAR(30))
BEGIN

DELETE
FROM  	tonksdev_tcash.account
WHERE	id = t_id
		and accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `removeAccountGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `removeAccountGroup`(IN `t_groupid` VARCHAR(30),
							IN `t_password` CHAR(64),
							IN `t_owner` VARCHAR(255))
BEGIN
	
	DELETE
	FROM	tonksdev_tcash.accountgroup
	WHERE	(groupid = t_groupid
			and password = t_password
			and owner = t_owner);

	DELETE
	FROM	tonksdev_tcash.usergroup
	WHERE	groupid = t_groupid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `removeRepeating` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `removeRepeating`(IN `t_id` INT(11), 
	 IN `t_accountgroup` VARCHAR(30))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

	DELETE
	FROM 	repeatingentry
	WHERE 	id = t_id
			AND accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `removeSession` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `removeSession`(IN `t_uid` VARCHAR(30),
								IN `t_series` CHAR(64),
								IN `t_token` CHAR(64),
								IN `t_fprint` CHAR(64))
BEGIN

	DELETE
	FROM	tonksdev_tcash.session
	WHERE	userid = t_uid 
			AND series = t_series;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `removeTxn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `removeTxn`(IN `t_id` INT(11), IN `t_accgroup` VARCHAR(30))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

IF (convert(t_id using utf8) 
	IN (
		SELECT convert(e.id using utf8) 
		FROM entry e
				INNER JOIN account a
				ON a.id = e.accountid
		WHERE 	e.id = t_id
				AND a.accountgroup = t_accgroup
	)
) 
THEN

	SELECT 	transfertxn
	INTO	@txn2
	FROM	entry
	WHERE	id = t_id;

	DELETE 	
	FROM	entry
	WHERE	id = t_id;

	IF @txn2 > 0 THEN
		DELETE
		FROM	entry
		WHERE 	id = @txn2;
	END IF;

END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `removeUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `removeUser`(IN `t_userid` VARCHAR(30),
							IN `t_password` CHAR(64))
BEGIN

	DELETE
	FROM	tonksdev_tcash.user
	WHERE	id = t_userid
			AND password = t_password;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `removeUserGroupLink` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `removeUserGroupLink`(IN `t_userid` VARCHAR(30),
							IN `t_groupid` VARCHAR(30))
BEGIN

	DELETE 
	FROM	tonksdev_tcash.usergroup
	WHERE	(userid = t_userid
			and groupid = t_groupid);

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `replaceSessionToken` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `replaceSessionToken`(IN `t_uid` VARCHAR(30),
								IN `t_series` CHAR(64),
								IN `t_token` CHAR(64),
								IN `t_fprint` CHAR(64))
BEGIN

	UPDATE	tonksdev_tcash.session
	SET		token = t_token
	WHERE	userid = t_uid 
			AND series = t_series 
			AND fingerprint = t_fprint;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rpt_spendingbycat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `rpt_spendingbycat`(IN `t_accgroup` VARCHAR(30),
									  IN `t_datefrom` DATE,
									  IN `t_dateto` DATE,
									  IN `t_accountid` VARCHAR(255))
BEGIN

select  e.category, 
		sum(e.amountcr) as total_spend
from	entry e
		inner join account a
			on a.id = e.accountid
			and a.accountgroup = t_accgroup
		inner join category c
			on c.id = e.category
			and c.accountgroup = t_accgroup
where 	amountcr < 0
		and e.date between t_datefrom and t_dateto
		and if(t_accountid = "", 1, find_in_set(a.id, t_accountid) > 0)
group by e.category
order by total_spend asc;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rpt_spendingbypayee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `rpt_spendingbypayee`(IN `t_accgroup` VARCHAR(30),
									  IN `t_datefrom` DATE,
									  IN `t_dateto` DATE,
									  IN `t_accountid` VARCHAR(255))
BEGIN

select  e.payee, 
		sum(e.amountcr) as total_spend
from	entry e
		inner join account a
			on a.id = e.accountid
			and a.accountgroup = t_accgroup
		inner join category c
			on c.id = e.category
			and c.accountgroup = t_accgroup
where 	amountcr < 0
		and e.date between t_datefrom and t_dateto
		and if(t_accountid = "", 1, find_in_set(a.id, t_accountid) > 0)
group by e.payee
order by total_spend asc;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `rpt_transbycat` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `rpt_transbycat`(IN `t_accgroup` VARCHAR(30),
									  IN `t_datefrom` DATE,
									  IN `t_dateto` DATE,
									  IN `t_accountid` VARCHAR(255),
									  IN `t_category` VARCHAR(255))
BEGIN

select  e.date,
		e.accountid,
		e.payee,
		e.category,
		e.amountcr
from	entry e
		inner join account a
			on a.id = e.accountid
			and a.accountgroup = t_accgroup
		inner join category c
			on c.id = e.category
			and c.accountgroup = t_accgroup
where 	e.date between t_datefrom and t_dateto
		and amountcr < 0
		and if(t_accountid = "", 1, find_in_set(a.id, t_accountid) > 0)
		and if(t_category = "", 1, find_in_set(e.category, t_category) > 0)
order by e.category, e.date asc, e.id asc;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `transferTxn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `transferTxn`(IN `t_date` DATE, IN `t_accountid` VARCHAR(30) CHARSET utf8, IN `t_payee` VARCHAR(255) CHARSET utf8, IN `t_category` VARCHAR(255) CHARSET utf8, IN `t_amountcr` DECIMAL(11,2), IN `t_notes` VARCHAR(255) CHARSET utf8, IN `t_iscleared` TINYINT(1), IN `t_isplaceholder` TINYINT(1), IN `t_accgroup` VARCHAR(30))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

IF (convert(t_accountid using utf8) IN (SELECT convert(id using utf8) FROM account WHERE accountgroup = t_accgroup)) 
THEN

	CALL addTxn (t_date, t_accountid, t_payee, t_category, t_amountcr, 
			t_notes, t_iscleared, t_isplaceholder, 0, t_accgroup);

	SET @txn1 = LAST_INSERT_ID();

	CALL addTxn (t_date, substring(t_payee, 2, length(t_payee)-2), 
				 concat('<', t_accountid, '>'), t_category, (t_amountcr * -1), 
				 t_notes, t_iscleared, t_isplaceholder, @txn1, t_accgroup);

	SET @txn2 = LAST_INSERT_ID();

	UPDATE entry SET transfertxn = @txn2 WHERE id = @txn1;

END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateAccount` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `updateAccount`(IN `t_id` VARCHAR(30),
								IN `t_name` VARCHAR(100),
								IN `t_type` VARCHAR(30),
								IN `t_accountgroup` VARCHAR(30))
BEGIN

UPDATE  tonksdev_tcash.account
SET		name = t_name, 
		type = t_type 
WHERE	id = t_id
		AND accountgroup = t_accountgroup;


END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateAccountGroup` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `updateAccountGroup`(IN `t_groupid` VARCHAR(30),
							IN `t_description` VARCHAR(100),
							IN `t_password` CHAR(64), 
							IN `t_owner` VARCHAR(255))
BEGIN

	UPDATE  tonksdev_tcash.accountgroup
	SET		description = t_description 
	WHERE	groupid = t_groupid
			AND password = t_password
			AND owner = t_owner;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateCategory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `updateCategory`(IN `t_category` VARCHAR(255), IN `t_accountgroup` VARCHAR(30), IN `t_newcategory` VARCHAR(255))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

UPDATE	category
SET		id = t_newcategory
WHERE	id = t_category
		AND accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateIsCleared` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `updateIsCleared`(IN `t_txnid` int, 
		 IN `t_accountgroup` varchar(255),
		 IN `t_iscleared` tinyint(1))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

UPDATE  entry e
		INNER JOIN account a 
			ON a.id = e.accountid
SET		e.iscleared = t_iscleared
WHERE	e.id = t_txnid
		AND a.accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updatePayee` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_AUTO_VALUE_ON_ZERO' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `updatePayee`(IN `t_payee` VARCHAR(255), IN `t_accountgroup` VARCHAR(255), IN `t_newpayee` VARCHAR(255))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

UPDATE	payee
SET		payee = t_newpayee
WHERE	payee = t_payee
		AND accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateRepeating` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `updateRepeating`(IN `t_id` INT(11), 
	 IN `t_accountid` VARCHAR(30),
	 IN `t_payee` VARCHAR(30),
	 IN `t_category` VARCHAR(30),
	 IN `t_amountcr` DECIMAL(10, 2),
	 IN `t_notes` VARCHAR(255),
	 IN `t_isplaceholder` TINYINT(1),
	 IN `t_nextdate` date,
	 IN `t_endondate` date, 
	 IN `t_frequencycode` CHAR(1),
	 IN `t_frequencyincrement` int(11),
	 IN `t_accountgroup` VARCHAR(30))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

	UPDATE  repeatingentry
	SET		`accountid` = t_accountid,
			`payee` = t_payee,
			`category` = t_category,
			`amountcr` = t_amountcr,
			`notes` = t_notes,
			`isplaceholder` = t_isplaceholder,			
			`nextdate` = t_nextdate,
			`endondate` = t_endondate,
			`frequencycode` = t_frequencycode,
			`frequencyincrement` = t_frequencyincrement
	WHERE 	id = t_id
			AND accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateRepeatingNextDate` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `updateRepeatingNextDate`(IN `t_id` INT(11), IN `t_nextdate` datetime, IN `t_prevdate` datetime, IN `t_accountgroup` VARCHAR(30))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

	UPDATE  repeatingentry
	SET		`nextdate` = t_nextdate,
			`prevdate` = t_prevdate
	WHERE 	id = t_id
			AND accountgroup = t_accountgroup;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateTxn` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `updateTxn`(IN `t_date` DATE, IN `t_accountid` VARCHAR(30) CHARSET utf8, IN `t_payee` VARCHAR(255) CHARSET utf8, IN `t_category` VARCHAR(255) CHARSET utf8, IN `t_amountcr` DECIMAL(10,2), IN `t_notes` VARCHAR(255) CHARSET utf8, IN `t_iscleared` TINYINT(1), IN `t_isplaceholder` TINYINT(1), IN `t_id` INT(11), IN `t_accgroup` VARCHAR(30))
    MODIFIES SQL DATA
    SQL SECURITY INVOKER
BEGIN

IF (convert(t_accountid using utf8) IN (SELECT convert(id using utf8) FROM account WHERE accountgroup = t_accgroup)) 
THEN

	SELECT 	transfertxn
	INTO	@txn2
	FROM	entry
	WHERE	id = t_id;

	UPDATE 	entry
	SET 	date = t_date,
			accountid = t_accountid, 
			payee = t_payee,
			category = t_category, 
			amountcr = t_amountcr,
			notes = t_notes, 
			iscleared = t_iscleared, 
			isplaceholder = t_isplaceholder
	WHERE	id = t_id;

	IF @txn2 > 0 THEN

		UPDATE 	entry
		SET 	date = t_date,
				accountid = substring(t_payee, 2, length(t_payee)-2), 
				payee = concat('<', t_accountid, '>'),
				category = t_category, 
				amountcr = (t_amountcr * -1),
				notes = t_notes, 
				iscleared = t_iscleared, 
				isplaceholder = t_isplaceholder
		WHERE	id = @txn2;

	END IF;

END IF;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `updateUser`(IN `t_userid` VARCHAR(30),
							IN `t_fullname` VARCHAR(100),
							IN `t_password` CHAR(64), 
							IN `t_email` VARCHAR(255),
							IN `t_newpassword` CHAR(64))
BEGIN

	UPDATE	tonksdev_tcash.user
	SET		fullname = t_fullname,
			email = t_email,
			password = t_newpassword
	WHERE	id = t_userid
			AND password = t_password;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `updateUserGroupLink` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `updateUserGroupLink`(IN `t_userid` VARCHAR(30),
							IN `t_groupid` VARCHAR(30),
							IN `t_primary` TINYINT(1))
BEGIN

	UPDATE	tonksdev_tcash.usergroup
	SET		primarygroup = t_primary
	WHERE	userid = t_userid
			AND groupid = t_groupid;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `validateUser` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8 */ ;
/*!50003 SET character_set_results = utf8 */ ;
/*!50003 SET collation_connection  = utf8_general_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = '' */ ;
DELIMITER ;;
CREATE DEFINER=`tonksdev_tcash`@`%` PROCEDURE `validateUser`(IN `t_id` VARCHAR(30), IN `t_password` CHAR(64))
BEGIN

	SELECT	id, fullname, email
	FROM	user
	WHERE	id = t_id
			AND password = t_password;

END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-05-07  7:45:12
